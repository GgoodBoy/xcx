<template>
    <view class="video-pluge"> 
        <view class="video-box">
            <view v-if="videoFirst">
                <video 
                    id="myVideo" 
                    class="myVideoCss" 
                    :controls="videoControls" 
                    x5-video-player-type="h5" 
                    @error="videoErrorCallback" 
                    :src="src" 
                    :enable-play-gesture='true' 
                    :autoplay='autoplays' 
                    :poster="imgPoster" 
                    @progress="videoProgress" 
                    @fullscreenchange="screenChange" 
                    @ended='endedEven'
                    @play="playEven" 
                    @pause="pauseEven" 
                    @timeupdate='timeupdateEven' 
                    show-center-play-btn ></video>
            </view>  
            <view class="video-img" v-if="!videoFirst">
                <image class="video-img-one" :src="imgPoster" />
                <view class="video-img-two"  @click="playOrPauseIconEven" v-if="lookOrPick">
                    <image :src="player_btn" webp lazy-load/>
                </view>
            </view>
            <view class="video-layout" v-if="(Number(periodObg.isTrySee)==0&&Number(objs.isVip)==0)&&objs.isBuy==0&&objs.timeLimitType!=0&&objs.isFree==0">
                <image :src="player_lock" />    
            </view>   
        </view>      
        <view class="uni-btn-v">
            <view class="textCourse">
                <view style="padding: 30rpx;background:#fff;">
                    <text class="courseTitle"> 
                        {{objs.title||''}}     
                    </text>
                    <view class="userBox">
                        <view class="textInfo">
                            <!-- <view class="titleRow1">
                                {{nameListArrays}}
                            </view> -->
                            <view class="courseIntro">
                                {{objs.intro||''}}
                            </view>                        
                            <view class="titleRow2">
                                <view class="titleRow2Next">
                                    <image :src="eyes"></image>
                                    <!-- toFixed(2) -->
                                    <view class="texts">{{(objs.courseBrowsCount>9999?Math.floor((objs.courseBrowsCount/10000) * 100) / 100+'W':objs.courseBrowsCount)||0}}人学习</view></view>
                                <view>
                                <text>更新至{{objs.actualPeriodNum||0}}节</text>
                                <text>|</text>
                                <text>共{{objs.planPeriodNum||0}}节</text>                                
                                </view>  
                            </view>
                        </view>                   
                        <!-- <view class="moneyCourse" v-if="unserIsLogenType">
                            <view class="moneyBut" v-if="Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0" @click="purchaseCourse">购买({{objs.timeLimitType==2?objs.spikePrice:objs.sellingPrice}}币)</view>
                        </view>
                        <view class="moneyCourse" v-if="!unserIsLogenType">
                            <button class="moneyBut" open-type="getPhoneNumber" @getphonenumber="decryptPhoneNumber" v-if="Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0">购买({{objs.timeLimitType==2?objs.spikePrice:objs.sellingPrice}}币)</button>
                        </view>                     -->
                    </view>
                    <view class="moneyCourse" v-if="unserIsLogenType&&(Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0)">
                        <view class="moneyBut" @click="purchaseCourse" v-if="iosOrAndroid=='Android'">
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span> 
                        </view>
                        <view class="moneyBut" @click="iosDegilogs" v-else>
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span> 
                        </view>                    
                    </view>
                    <view class="moneyCourse" v-if="!unserIsLogenType&&(Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0)">
                        <button v-if="iosOrAndroid=='Android'" class="moneyBut" open-type="getPhoneNumber" @getphonenumber="decryptPhoneNumber">
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>                        
                        </button>
                        <button v-else class="moneyBut" @click="iosDegilogs">
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>                        
                        </button>                    
                    </view>                 
                    <v-limit :timeObj='limitObj' :timeHideOrShow='timeHideOrShow'></v-limit>
                </view>
                <view class="teacherImgs">
                    <view class="teacherBoxName">
                        <view>授课老师</view>
                    </view>                    
                    <view class="scroll_box"> 
                        <scroll-view scroll-x>
                            <view class="item_list" v-for="(item,index) in objs.lectureTeacherList" :key="index" @tap="chooseSecond(item)">
                                <image :src="item.avatar"></image>
                                <view class="teacherName">
                                    <view>{{item.name.slice(0,5)}}</view>
                                    <view v-if='item.name.length>5'>{{item.name.slice(5)}}</view>
                                </view>
                            </view>                
                        </scroll-view>
                    </view>                                     
                </view>                              
                <view>
                </view>                
            </view> 
        </view>               
    </view>
</template>

<script> 
import player_lock from '../../static/courseDetail/player_lock.png';
import player_btn from '../../static/courseDetail/player_btn.png'
import limittime_l from './limitedTime.vue';//限时购组件 
import eyes from '../../static/eyes.png'
import {mapState,mapActions} from 'vuex'
export default {

    data() {
        return {
            player_lock:player_lock,//锁
            player_btn:player_btn,
            eyes:eyes,
            title: 'video',
            videoContext:'',
            src:'',
            autoplays:false,
            openType:false,//是否开启自动播放属性
            studyPoint:[],//学习时间点 1,2,3...
            lastStudyPoint:0,//暂停，退出，播放结束的进度条所在位置的时间；
            learnRate:0,//学习时长
            endVideoTime:0,//视频播放结束时的时间值
            realTimeData:'',//进度条最新实时数据
            periodId:'',
            timeDuration:'',//总时长
            changeDuration:0,//播放状态的时候的时间；
            playerIsNo:false,//表示课程节是否可以观看；
            playEndState:false,//播放结束
            unserIsLogenType:false,//当前用户是否已绑定电话号码
            userinfos:'',//缓存
            // nameListArrays:'',
            videoControls:true,//视频是否可以不放
            periodIdState:true,//检查视频播放路径有没有变化
            imgPoster:'',
            videoFirst:false,
            pathChangeType:false,
            pathChangeTypeOther:false,
            phoneTypeInfo:'',
            lookOrPick:true,
            //增加视频自动播放属性
            //当前选中的课程index
            courseIndex:-1
        }
    },
    props:['objs','periodObg','imgUrls','datalist','limitObj','timeHideOrShow','iosOrAndroid','changeDataMoney','exitFullScreenType'],
    onReady: function (res) {
        //this这个参数必须传递，表示当前实例；
        this.videoContext = uni.createVideoContext('myVideo',this);
        this.userinfos = JSON.parse(wx.getStorageSync('userInfo'));
    },
    components:{
        'v-limit':limittime_l
    },    
    created(){
        this.getUserInfoEven();
        this.getMobilePhoneInfo();
        // this.tteacherNameList();
        this.imgPoster = this.objs.surfacePlot;
    },
    watch:{
        periodObg:{
            handler(newVal, oldVal) {
                if(newVal.firstTouch){
                    if(newVal.periodId&&newVal.periodId!=oldVal.periodId){
                        this.periodIdState=true;
                        this.openType = newVal.newPath;
                        this.periodId = newVal.periodId;
                        if((Number(newVal.isTrySee)==0&&Number(this.objs.isVip)==0)&&this.objs.isBuy==0&&this.objs.timeLimitType!=0&&this.objs.isFree==0){
                                this.lookOrPick = false;
                        }
                    }
                }else{
                    if(this.objs.courseId!=''){
                        if(this.phoneType.indexOf(this.phoneTypeInfo)!=-1){
                            this.pathChangeType = false;
                        }else{
                            this.pathChangeTypeOther = false;
                        }
                        this.periodIdState=true;
                        this.openType = newVal.newPath;
                        this.periodId = newVal.periodId;                        
                        if(!this.videoFirst){
                            this.videoFirst = true;
                            this.getCoursePath(newVal);
                        }else{
                            this.getCoursePath(newVal);
                        }
                    }
                }
            },        
            immediate:true,    
            deep:true
        },
        exitFullScreenType(news,olds){
            if(news){
                this.videoContext.exitFullScreen();
            }
        },         
        'videoData.statusCourseVidChoose': {
            handler(news,olds) {
                let data = this.datalist[news];
                if(data){
                    this.$emit('toVideoEven',{id:data.id,courseId:data.courseId,targetDuration:data.targetDuration,courseId:data.courseId,isTry:data.isTry,lastStudyPoint:data.lastStudyPoint});
                }             
            }
        },
        changeDataMoney(news,olds){
            if(news){
                if(news==1){
                    this.purchaseCourse();
                }else{
                    this.decryptPhoneNumber(news);
                }
            }
        },         
        pathChangeType(newVal, oldVal){
            if(newVal){
                this.videoContext.pause();
                if(this.periodObg.targetDuration-this.periodObg.lastStudyPoint<1){
                    this.videoContext.seek(2);
                }else{
                    this.videoContext.seek(this.periodObg.lastStudyPoint);
                }                
                setTimeout(()=>{
                    this.videoContext.play();
                },1500);
            }
        }       
    },
    computed:{
        ...mapState(['audioData','timeArry','videoData','phoneType']),
    },    
    methods: {
        ...mapActions(['setPlayCourseState','setAudioData','setStatusCourseChoose','setCourseaudioListInfoData','setLocalaudioListInfoData','setVideoDateEven','setTimeArryData']),
        chooseSecond(data){
            uni.navigateTo({
                url: `/pages/search/index?teacherName=${data.name}`
            });              
        },       
       //查看手机机型
        getMobilePhoneInfo(){
            var self = this;
            wx.getSystemInfo({
                success (res) {
                    self.phoneTypeInfo = res.model;
                }
            })				
        },    
        iosDegilogs(){
            wx.showToast({
                title: '由于相关规范，IOS功能暂不可用！',
                icon: 'none',
                mask:false,
                duration: 1500//持续的时间
            })            
        },
        screenChange(e){
            let fullScreen = e.detail.fullScreen; //值true为进入全屏，false为退出全屏
            if (fullScreen ){ //退出全屏
                console.log("进入全屏");
            }else{ //进入全屏
                if(this.exitFullScreenType){
                    this.$emit('priceDialog',{type:true});         
                }
            }
        },     
        //第一次进入详情
        playOrPauseIconEven(){
            var self = this;
            this.videoFirst = true;
            var indexUnm =-1;
            if(self.videoData.catalogList){
                self.videoData.catalogList.forEach((element,index)=>{
                    if(element.periodId==self.periodId){
                        indexUnm = index;
                    }
                });
            }         
            this.courseIndex = indexUnm;
            let temp = Object.assign({},this.videoData,{playCourseVideState:true,statusCourseVidChoose:indexUnm})
            this.setVideoDateEven(temp);
        },
        //是否加载一小段信息；
        videoProgress(){

        },
        //验证是否可以
        //拼接老师名字长度
        // tteacherNameList(){
        //     let stringLists = ''
        //     this.objs.lectureTeacherList.forEach((element,index) => {
        //         if((index+1)!=this.objs.lectureTeacherList.length){
        //             stringLists = stringLists+element.name+' | ';
        //         }else{
        //             stringLists = stringLists+element.name;
        //         }
        //     });
        //     this.nameListArrays = stringLists;
        // },       
        //获取用户信息
        getUserInfoEven(){
            var userInfo = JSON.parse(wx.getStorageSync('userInfo')); 
            if(userInfo.cellphone){
                this.unserIsLogenType = true;
            }else{
                this.unserIsLogenType = false;
            }
        },         
        //通过绑定手机号登录
        decryptPhoneNumber: function (e) {
            var self = this;
            if(this.audioData.playerCreat){
                wx.getNetworkType({
                    success (res) {                
                        //暂停，切换页面调用接口；
                        const backgroundAudioManager = wx.getBackgroundAudioManager();
                        //暂停，切换页面调用接口；
                        var realLearnRatelong = self.$store.state.timeArry;               
                        backgroundAudioManager.stop();                                 
                        let data = self.audioData;
                        let query = {
                            periodId:data.periodId,//课时id 
                            courseId:data.courseId,
                            learnRate:realLearnRatelong[realLearnRatelong.length-1],
                            realLearnRate:realLearnRatelong.length,
                            studyPoint:realLearnRatelong.toString(),
                            lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1]
                        };
                        if (res.networkType == 'wifi'){
                            query['netType'] = 2;
                        }else{
                            query['netType'] = 1;
                        } 
                        self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(resInfo=>{
                            if(resInfo.data.status==200){
                                self.setAudioData({
                                    title:'',//标题
                                    cur:'00:00',//当前播放时间
                                    total:'20:00',//总时间
                                    surfacePlot:'',//课程封面
                                    courseId: '',//课程ID
                                    show:false,//音频播放条是否存在
                                    playFlag: false,//是否在播放中
                                    periodId: '',//课时id;
                                    playerCreat:false
                                });
                                self.setStatusCourseChoose(-1);
                                self.setPlayCourseState(false);
                                self.$store.commit('SETTimeARRYS',[])
                                self.setCourseaudioListInfoData([]);
                                self.setLocalaudioListInfoData([]);
                                setTimeout(()=>{
                                    var ivObj = e.detail.iv
                                    var telObj = e.detail.encryptedData
                                    var codeObj = "";
                                    //---------登录有效期检查
                                    wx.checkSession({
                                        success: function () {
                                            //session_key 未过期，并且在本生命周期一直有效
                                            if (e.detail.errMsg == "getPhoneNumber:ok") { // 同意授权
                                                wx.showLoading();
                                                wx.login({
                                                    success (res) {
                                                        if (res.code) {
                                                            var objs = {
                                                                encryptedData:telObj,
                                                                iv:ivObj,
                                                                code:res.code
                                                            }
                                                            self.getDecryptCellphone(objs); 
                                                        } 
                                                    }
                                                })
                                            }else{
                                                // 拒绝手机号授权
                                                uni.showToast({
                                                    title: '手机号授权失败！',
                                                    icon: 'none'
                                                });
                                            }
                                        },
                                        fail: function () {
                                        // session_key 已经失效，需要重新执行登录流程
                                        
                                        }
                                    });
                                },200);
                            }
                        });   
                    }
                });                          
            }else{
                var ivObj = e.detail.iv
                var telObj = e.detail.encryptedData
                var codeObj = "";
                //---------登录有效期检查
                wx.checkSession({
                    success: function () {
                        //session_key 未过期，并且在本生命周期一直有效
                        if (e.detail.errMsg == "getPhoneNumber:ok") { // 同意授权
                            wx.showLoading();
                            wx.login({
                                success (res) {
                                    if (res.code) {
                                        var objs = {
                                            encryptedData:telObj,
                                            iv:ivObj,
                                            code:res.code
                                        }
                                        self.getDecryptCellphone(objs); 
                                    } 
                                }
                            })
                        }else{
                            // 拒绝手机号授权
                            uni.showToast({
                                title: '手机号授权失败！',
                                icon: 'none'
                            });
                        }
                    },
                    fail: function () {
                    // session_key 已经失效，需要重新执行登录流程
                    
                    }
                });                
            }
        },       
        //获取电话号绑定用户电话
        setCellphoneEven(data){
                //调用绑定电话号码的接口；
                var self = this;
                let query = {
                    openId:this.userinfos.userId,//第三方登录的系统用户id
                    tokenType: 2,//访问端类型 1 ios_app 2 android_app 3 web_app 4第三方 5pc端
                    cellphone: data.cellphone,//手机号
                    origin: 14 //14.微信小程序
                };
                this.$http.post(this.$server.setWeChatBindCellphone,query).then(res=>{
                    if(res.data.status==200){
                        //返回的数据；
                        var objs = {
                            nickname:self.userinfos.nickname,
                            cellphone:res.data.content.cellphone,
                            userId:res.data.content.id,
                            isVip:self.userinfos.isVip,
                            token:self.userinfos.token,
                            avatar:self.userinfos.avatar,
                            openId:self.userinfos.openId
                        };
                        wx.removeStorageSync('userInfo')
                        self.userinfos = wx.getStorageSync('userInfo');
                        wx.setStorageSync('userInfo',JSON.stringify(objs));
                        wx.hideLoading();
                        var moneySpikePrice=this.objs.timeLimitType==2?this.objs.spikePrice:this.objs.sellingPrice;
                        wx.redirectTo({
                            url: '../investMoney/index?id='+Number(self.objs.courseId)+"&buyType="+self.objs.buyType+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice
                        })
                    }
                });
        },
        //获取解密接口
        getDecryptCellphone(data){
            //调用绑定电话号码的接口；
            // var openids = wx.getStorageSync('openId');
            // var code = wx.getStorageSync('code');
            let query = {
                encryptedData: data.encryptedData,
                iv: data.iv,
                code:data.code,
                type:2
            };
            wx.setStorageSync('code',data.code);
            this.$http.post(this.$server.getLoginWeChatUserPhone,query).then(res=>{
                if(res.data.status==200){
                    var objs = {
                        cellphone:res.data.content
                    };
                    this.setCellphoneEven(objs);
                }
            });
        },         
        //进度条前进事件
        timeupdateEven(data){
            var self= this;
                this.realTimeData = data.detail;
                var times = Math.floor(data.detail.currentTime);
                if(times!=this.studyPoint[this.studyPoint.length-1]){
                    this.studyPoint.push(times);
                }                
            let temp = Object.assign({},self.videoData,{studyPoint:self.studyPoint,periodId:this.periodId})
            this.setVideoDateEven(temp);
        },        
        //暂停事件
        pauseEven(data){
            var self = this;    
            var objs = {
                    periodId:self.periodId,//课时id 
                    learnRate:self.studyPoint.length>0?self.studyPoint[self.studyPoint.length-1]:0,
                    studyPoint:self.studyPoint,
                    lastStudyPoint:self.studyPoint.length>0?self.studyPoint[self.studyPoint.length-1]:0                
            }       
            self.studyPoint =[];    
            this.$emit('setDataToHttp',objs);   
        },
        //播放事件
        playEven(){
            var self = this;     
                if(!self.periodIdState){
                    this.$emit('setIntervalVarEven',{'bools':false});
                }else{
                    this.$emit('setIntervalVarEven',{'bools':true});
                }
                var indexUnm =-1;
                if(self.videoData.catalogList){
                    self.videoData.catalogList.forEach((element,index)=>{
                        if(element.periodId==this.periodId){
                            indexUnm = index;
                        }
                    });
                }                  
                this.courseIndex = indexUnm;
                let temp = Object.assign({},self.videoData,{playCourseVideState:true,statusCourseVidChoose:indexUnm})
                this.setVideoDateEven(temp);  
            // }
            if(this.phoneType.indexOf(this.phoneTypeInfo)!=-1){
                if(!this.pathChangeType){
                    this.pathChangeType = true;
                }
            }else{
                if(!this.pathChangeTypeOther){
                    this.pathChangeTypeOther = true;
                    if(this.periodObg.targetDuration-this.periodObg.lastStudyPoint<1){
                        this.videoContext.seek(2);
                    }else{
                        this.videoContext.seek(this.periodObg.lastStudyPoint);
                    }
                }               
            }
        },
        //播放结束事件
        endedEven(data){
            var self =this;
            self.playEndState = true;
            self.periodIdState = false;
            var objs = {
                    periodId:self.periodId,//课时id 
                    learnRate:self.studyPoint.length>0?self.studyPoint[self.studyPoint.length-1]:0,
                    studyPoint:self.studyPoint,
                    lastStudyPoint:self.studyPoint.length>0?self.studyPoint[self.studyPoint.length-1]:0            
            }
            this.$emit('setDataToHttp',objs);
            setTimeout(()=>{
                console.log("开始全屏");		
                self.$emit('setNextDataToHttp',{indexProp:self.courseIndex});
            },200);
            this.studyPoint =[];     
            let temp = Object.assign({},self.videoData,{playCourseVideState:false,studyPoint:[]})
            this.setVideoDateEven(temp);               
        },
        videoErrorCallback: function (e) {
            console.log(e.target.errMsg)
        },

        getCoursePath(newVal){
            var self = this;
                let query = {
                    definitionType: 1,
                    periodId: Number(newVal.periodId),//课时id 
                    courseId: this.objs.courseId
                }
                this.timeDuration = newVal.targetDuration;
                if(Number(this.objs.isFree)==1||Number(this.objs.isVip)==1||this.objs.isBuy==1||this.objs.timeLimitType==0||newVal.isTrySee==1){
                    if(this.audioData.playerCreat){
                        wx.getNetworkType({
                            success (res) {                
                                //暂停，切换页面调用接口；
                                const backgroundAudioManager = wx.getBackgroundAudioManager();
                                //暂停，切换页面调用接口；
                                var realLearnRatelong = self.$store.state.timeArry;     
                                let data = self.audioData;
                                let queryOther = {
                                    periodId:data.periodId,//课时id 
                                    courseId:data.courseId,
                                    learnRate:realLearnRatelong[realLearnRatelong.length-1],
                                    realLearnRate:realLearnRatelong.length,
                                    studyPoint:realLearnRatelong.toString(),
                                    lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1]
                                };
                                if (res.networkType == 'wifi'){
                                    queryOther['netType'] = 2;
                                }else{
                                    queryOther['netType'] = 1;
                                }                        
                                self.$http.post(self.$server.savePeriodStudyRecordsUser,queryOther).then(resInfo=>{
                                    self.$store.commit('SETTimeARRYS', []);
                                    if(resInfo.data.status==200){
                                        self.setAudioData({
                                            title:'',//标题
                                            cur:'00:00',//当前播放时间
                                            total:'20:00',//总时间
                                            surfacePlot:'',//课程封面
                                            courseId: '',//课程ID
                                            show:false,//音频播放条是否存在
                                            playFlag: false,//是否在播放中
                                            periodId: '',//课时id;
                                            playerCreat:false
                                        });
                                        self.setStatusCourseChoose(-1);
                                        self.setPlayCourseState(false);
                                        self.setCourseaudioListInfoData([]);
                                        self.setCourseaudioListInfoData([]);  
                                        backgroundAudioManager.stop();   
                                        if(!self.periodIdState){
                                            self.$emit('setIntervalVarEven',{'bools':false});
                                        }else{
                                            self.$emit('setIntervalVarEven',{'bools':true});
                                        }
                                        wx.getNetworkType({
                                            success (res) {                    
                                                if (res.networkType == 'wifi'){
                                                        query['netType'] = 2;
                                                    }else{
                                                        query['netType'] = 1;
                                                    }                     
                                                    self.$http.post(self.$server.getResoursePlayUrl,query).then(resInfo=>{
                                                        if(resInfo.data.status==200){
                                                            self.src = resInfo.data.content;
                                                            if(self.openType){
                                                                //控制自动播放；
                                                                self.autoplays = true;
                                                            }
                                                        }
                                                    });
                                                }
                                        });                     
                                    }
                                });  
                            }
                        });                           
                    }else{
                        wx.getNetworkType({
                            success (res) {                    
                                if (res.networkType == 'wifi'){
                                        query['netType'] = 2;
                                    }else{
                                        query['netType'] = 1;
                                    }                     
                                    self.$http.post(self.$server.getResoursePlayUrl,query).then(resInfo=>{
                                        if(resInfo.data.status==200){
                                            self.src = resInfo.data.content;
                                            if(self.openType){
                                                //控制自动播放；
                                                self.autoplays = true;
                                            }
                                        }
                                    });
                                }
                        }); 
                    }                   
                }else{
                    this.src = '';
                    // uni.showToast({
                    //     title: '尚未购买该课时',
                    //     duration: 2000,
                    //     icon: 'none'
                    // });                    
                }

        },        
        purchaseCourse(){
            var self = this;
            if(this.audioData.playerCreat){
                wx.getNetworkType({
                    success (res) {
                        //暂停，切换页面调用接口；
                        const backgroundAudioManager = wx.getBackgroundAudioManager();
                        //暂停，切换页面调用接口；
                        var realLearnRatelong = self.$store.state.timeArry;                
                        backgroundAudioManager.stop();                
                        let data = self.audioData;      
                        let query = {
                            periodId:data.periodId,//课时id 
                            courseId:data.courseId,
                            learnRate:realLearnRatelong[realLearnRatelong.length-1],
                            realLearnRate:realLearnRatelong.length,
                            studyPoint:realLearnRatelong.toString(),
                            lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1]
                        };                                          
                        if (res.networkType == 'wifi'){
                            query['netType'] = 2;
                        }else{
                            query['netType'] = 1;
                        }
                        self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(resInfo=>{
                            if(resInfo.data.status==200){
                                self.$store.commit('SETTimeARRYS',[]);
                                self.setAudioData({
                                    title:'',//标题
                                    cur:'00:00',//当前播放时间
                                    total:'20:00',//总时间
                                    surfacePlot:'',//课程封面
                                    courseId: '',//课程ID
                                    show:false,//音频播放条是否存在
                                    playFlag: false,//是否在播放中
                                    periodId: '',//课时id;
                                    playerCreat:false
                                });
                                self.setStatusCourseChoose(-1);
                                self.setPlayCourseState(false);
                                self.setCourseaudioListInfoData([]);
                                self.setLocalaudioListInfoData([]);
                                var moneySpikePrice=self.objs.timeLimitType==2?self.objs.spikePrice:self.objs.sellingPrice;
                                wx.redirectTo({
                                    url: '../investMoney/index?id='+Number(self.objs.courseId)+"&buyType="+self.objs.buyType+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice
                                });                        
                            }
                        }); 
                    }
                })
            }else{
                var moneySpikePrice=this.objs.timeLimitType==2?this.objs.spikePrice:this.objs.sellingPrice;
                wx.redirectTo({
                    url: '../investMoney/index?id='+Number(self.objs.courseId)+"&buyType="+self.objs.buyType+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice,
                    animationDuration:'500',
                    success: res => {},
                    fail: () => {},
                    complete: () => {}
                });                 
            }
        }     
    }
        
}


</script>

<style lang="scss">
.video-pluge{
    // background: #fff;
    // padding: 0 0 29rpx 0;  
    .video-box{
        position: relative;
        .myVideoCss{
            width:750rpx !important;
            height: 421rpx;
        }
        .video-img{
            width:750rpx !important;
            height: 421rpx;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            .video-img-one{
                display: block;
                width:100%;    
                height: 100%;         
            }
            .video-img-two{
                position: absolute;
                z-index: 10;
                top: 0;
                left: 0;
                height: 421rpx;
                right: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                image{
                    width:102rpx;
                    height: 102rpx;
                }
            } 
        }        
        .video-layout{
            position: absolute;
            z-index: 10;
            top: 0;
            left: 0;
            bottom: 10rpx;
            right: 0;
            background: rgba(0,0,0,0.4);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            image{
                width:102rpx;
                height: 102rpx;
            }
        }
    }
    .uni-btn-v{
        .textCourse{
            // padding: 30rpx 30rpx 0;
            .userBox{
                // display: flex;
                // flex-direction: row;
                // justify-content:space-between;
                // align-items: flex-end;
                .textInfo{        
                    .courseIntro{
                        font-size: 30rpx;
                        color: #666666;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        -webkit-line-clamp:2;
                        -webkit-box-orient: vertical;                         
                    }                               
                    text{
                        margin-left: 10rpx;
                    }
                    // .titleRow1{
                    //     margin-top: 20rpx;
                    //     font-size: 28rpx;
                    //     color: #666666FF;
                    //     width: 500rpx;
                    //     overflow:hidden; //超出一行文字自动隐藏
                    //     text-overflow:ellipsis;//文字隐藏后添加省略号
                    //     white-space:nowrap;                             
                    // }
                    .titleRow2{
                        display: flex;
                        flex-direction: row;
                        justify-content:space-between;
                        align-items: center;                         
                        margin-top: 20rpx;
                        font-size: 26rpx;
                        color: #999999;
                        .titleRow2Next{
                            display: flex;
                            flex-direction: row;
                            justify-content: start;
                            align-items: center;
                            image{
                                width: 36rpx;
                                height: 36rpx;
                            }
                            .texts{
                                padding: 0 10rpx;
                                height: 36rpx;
                                line-height: 36rpx;
                                line-height: 36rpx;
                                font-size: 28rpx;
                                color: #999999;
                            }
                        }
                    }                    
                }
                // .moneyCourse{
                //     width: 270rpx;
                //     height: 66rpx;
                //     .moneyBut{
                //         border-radius: 66rpx;
                //         color: #fff;
                //         background-color: #C81229;                        
                //         width: 100%;
                //         height: 66rpx;
                //         line-height: 66rpx;
                //         text-align: center;
                //         font-size: 27rpx;
                //     }
                // }
            }
            .moneyCourse{
                width: 680rpx;
                height: 80rpx;
                margin: 30rpx auto 0;
                .moneyBut{
                    border-radius: 80rpx;
                    color: #fff;
                    background-image: linear-gradient(to left,#C30D23, #EC354B);                     
                    width: 100%;
                    height: 80rpx;
                    line-height: 80rpx;
                    text-align: center;
                    font-size: 30rpx;
                }
            }   
            .teacherImgs{   
                padding: 1rpx 30rpx 10rpx;
                background: #fff;
                margin-top: 20rpx;                
                .teacherBoxName{
                    font-size:30rpx;
                    font-weight:800;
                    position: relative;
                    margin: 40rpx 0;
                    view{
                        height: 40rpx;
                        line-height: 40rpx;
                        padding: 0 30rpx;
                        font-size: 36rpx;
                        color: #333;
                        font-weight: 500;            
                    }
                }
                .teacherBoxName:before{
                        content:'';
                        height: 40rpx;
                        width: 8rpx;
                        bottom: 0;
                        left: 10rpx;                
                        display: block;   
                        position: absolute;
                        background: #C30D23;
                }         
                .scroll_box{
                    width: 680rpx;
                    margin: 0 auto;
                    overflow: hidden;
                    white-space: nowrap;
                    height: 240rpx;
                    // padding: 20rpx 0;
                    scroll-view{
                        height: 100%;
                        width: auto;
                        overflow:hidden;
                        .item_list{
                            text-align: center;
                            display: inline-block;
                            margin-right: 17rpx;
                            color:#333;
                            background: #fff;
                            width:160rpx;
                            border-radius: 6rpx;
                            position: relative;
                            height: 240rpx;
                            image{
                                height: 140rpx;
                                width: 140rpx;
                                border-radius: 50%;
                                position: absolute;
                                top: 0;
                                left: 10rpx;
                            } 
                            .teacherName{
                                width: 150rpx;
                                font-size: 28rpx;
                                text-align: center;
                                position: absolute;
                                left: 5rpx;
                                top:150rpx;
                            }                   
                        }                
                    }            
                }           

            }               
            .courseTitle{
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp:2;
                -webkit-box-orient: vertical;              
                font-size: 34rpx;
                font-weight: 700;
                color: #333;
            }
        }
    }
}
</style>
<style>
::-webkit-scrollbar {
    width: 0;
    height: 0;
    color: transparent;
}
</style>