<template>
    <view class="audio-pluge">    
        <view class="audio-box">
            <view class="copy_audio">
                <image :src="objs.surfacePlot" @touchmove='touchmoveEven($event,1)' @touchstart="touchstartEven($event,1)" @touchend='touchendEven($event,1)'/>
                <view class="audio-layout" v-if="(Number(periodObg.isTrySee)==0&&Number(objs.isVip)==0)&&objs.isBuy==0&&objs.timeLimitType==1&&objs.isFree==0&&objs.isTrySee==0">
                    <image :src="player_lock" webp lazy-load/>    
                </view>   
                <view class="londing_xcx" v-if="londUrlBool">
                    <view class="contentinfo">
                        加载中...
                    </view>
                </view>
                <view class="audio-layout" v-if="(Number(periodObg.isTrySee)==1||Number(objs.isVip)==1||objs.isBuy==1||objs.timeLimitType==0||objs.isTrySee==1)&&showHideTypeOne&&periodObg.targetDuration!=0&&!playerIsNo&&!londUrlBool&&audioClickFirst">
                    <image :src="pauseImg" @click="playOrPauseIconEven" v-if="playFlag"/>
                    <image :src="player_btn" @click="playOrPauseIconEven" v-else/>                     
                </view>                 
            </view>
            <view v-show="getDurations&&!londUrlBool" class="progressBox" @touchmove='touchmoveEven($event,2)' @touchstart="touchstartEven($event,2)" @touchend='touchendEven($event,2)'>
                <view class="progressBox2">
                    <v-progress :playFlag='playFlag' :duration="timeDuration" :currentTime='changeDuration' @pressClickEvenEmit='pressClickEvenEmit' @onDragEven='onDragEven' @setDataToHttp='setDataToHttp'/>
                </view>
            </view>     
        </view>
        <view class="uni-btn-v">
            <view class="textCourse">
                <view style="padding: 30rpx;background:#fff;">
                    <text class="courseTitle"> 
                        {{objs.title||''}}     
                    </text>
                    <view class="userBox">
                        <view class="textInfo">
                            <!-- <view class="titleRow1">
                                {{nameListArrays}}
                            </view> -->                        
                            <view class="courseIntro">
                                {{objs.intro||''}}
                            </view>
                            <view class="titleRow2">
                                <view class="titleRow2Next">
                                    <image :src="eyes"></image>
                                    <view class="texts">{{(objs.courseBrowsCount>9999?Math.floor((objs.courseBrowsCount/10000) * 100) / 100+'W':objs.courseBrowsCount)||0}}人学习</view>
                                </view>
                                <view>
                                    <text>更新至{{objs.actualPeriodNum||0}}节</text>
                                    <text>|</text>
                                    <text>共{{objs.planPeriodNum||0}}节</text>                                
                                </view>
                            </view>
                        </view>
                    </view>
                    <view class="moneyCourse" v-if="unserIsLogenType&&(Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0)">
                        <view class="moneyBut" @click="purchaseCourse" v-if="iosOrAndroid=='Android'">
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>   
                        </view>
                        <view class="moneyBut" @click="iosDegilogs" v-else>
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>   
                        </view>                    
                    </view>       
                    <view class="moneyCourse" v-if="!unserIsLogenType&&(Number(objs.isFree)!=1&&Number(objs.isVip)!=1&&objs.isBuy!=1&&objs.timeLimitType!=0)">
                        <button class="moneyBut" open-type="getPhoneNumber" @getphonenumber="decryptPhoneNumber" v-if="iosOrAndroid=='Android'"> 
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>                        
                        </button>
                        <button class="moneyBut" @click="iosDegilogs" v-else>
                            <span v-if="objs.timeLimitType==2">
                                {{objs.spikePrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else-if="objs.timeLimitType==1">
                                {{objs.sellingPrice}}币<span style="text-decoration:line-through;padding:0 10rpx">(原价{{objs.basicPrice}}币)</span>
                            </span>
                            <span v-else>
                                购买({{objs.sellingPrice}}币)
                            </span>                        
                        </button>                    
                    </view> 
                    <v-limit :timeObj='limitObj' :timeHideOrShow='timeHideOrShow'></v-limit>
                </view>
                <view class="teacherImgs">
                    <view class="teacherBoxName">
                        <view>授课老师</view>
                    </view>                    
                    <view class="scroll_box"> 
                        <scroll-view scroll-x>
                            <view class="item_list" v-for="(item,index) in objs.lectureTeacherList" :key="index" @tap="chooseSecond(item)">
                                <image :src="item.avatar"></image>
                                <view class="teacherName">
                                    <view>{{item.name.slice(0,5)}}</view>
                                    <view v-if='item.name.length>5'>{{item.name.slice(5)}}</view>
                                </view>
                            </view>                
                        </scroll-view>
                    </view>                                     
                </view>                                 
            <view>
            </view>                
        </view> 
    </view> 

    </view>
</template>

<script> 
import player_lock from '../../static/courseDetail/player_lock.png' 
// import home_audio from '../../static/courseDetail/audio.jpg'
import pauseImg from '../../static/courseDetail/pause.png' 
import player_btn from '../../static/courseDetail/player_btn.png'
import eyes from '../../static/eyes.png'
import c_progress from './cProgress.vue';//视频播器组件
import limittime_l from './limitedTime.vue';//限时购组件 
import {mapState,mapActions} from 'vuex'
function compareVersion(v1, v2) {
  v1 = v1.split('.')
  v2 = v2.split('.')
  const len = Math.max(v1.length, v2.length)
  while (v1.length < len) {
    v1.push('0')
  }
  while (v2.length < len) {
    v2.push('0')
  }
  for (let i = 0; i < len; i++) {
    const num1 = parseInt(v1[i])
    const num2 = parseInt(v2[i])
    if (num1 > num2) {
      return 1
    } else if (num1 < num2) {
      return -1
    }
  }
  return 0
}
export default {

    data() {
        return {
            player_lock:player_lock,//锁
            home_audio:'',
            pauseImg:pauseImg,//播放icon
            player_btn:player_btn,//暂停icon
            eyes:eyes,
            title: 'audio',
            audioContext:'',
            src:'',
            autoplays:false,
            openType:false,//是否开启自动播放属性
            progressType:true,//进度条手动拖动还是自动前进的状态判断，自动前进为true，手动拖动为false
            studyPoint:[],//学习时间点 1,2,3...
            saveObjs:{
                lastStudyPoint:0,//暂停，退出，播放结束的进度条所在位置的时间；
                studyPoint:[],
                learnRate:0,//学习时长
                periodId:''
            },
            firstAutoplays:false,//刚进入详情页是否处于播放状态
            endAudioTime:0,//视频播放结束时的时间值
            realTimeData:'',//进度条最新实时数据
            lockNum:0,//表示当前进度的对比时间值
            periodId:'',
            timeupdatBool:false,//是否执行了滚动条变化事件
            getDurations:false,//第一播放，进度条显示隐藏；
            timeDuration:0,//总时长
            changeDuration:0,//播放状态的时候的时间；
            showHideTypeOne:true,  //遮罩可播放播放状态的隐藏变量（根据定时器改变，只有在播放切遮罩出现的时候才会触发）
            playOrPauseIcon:false,//播放和暂停的Icon的切换
            playOrPauseType:false,//当前播放器是播放还是暂停状态
            onDragType:false,//滚动条拖拽过成中的状态
            maskType:0,//表示当前手指触摸的是哪一层；
            playerIsNo:false,//表示课程节是否可以观看；
            touchVar:false,//当前手指是处于按下还是抬起状态
            unserIsLogenType:true,//判断当前用户是否绑定手机号
            playFlag:false,
            player:'',
            userinfos:'',
            loading:false,
            londUrlBool:false,
            londUrlBoolTow:false,
            // nameListArrays:'',
            timeDurationIsover:-1,
            courseEveryTime:0,
            backgrCurrentTime:0,
            isOkPlay:false,
            phoneTypeInfo:'',
            courseIds:'',
            isNewPageType:true,
            audioClickFirst:true
        }
    },
    props:['objs','periodObg','imgUrls','changeDurationNew','versionType','datalist','limitObj','timeHideOrShow','iosOrAndroid','changeDataMoney'],
    components:{
        'v-progress':c_progress,
        'v-limit':limittime_l
    },
    onReady: function (res) {
        //this这个参数必须传递，表示当前实例；
        this.userinfos = JSON.parse(wx.getStorageSync('userInfo'));
        this.audioContext = uni.createVideoContext('myAudio',this);
    },
    created(){
        this.getUserInfoEven();
        this.getMobilePhoneInfo();
    },
    computed:{
        ...mapState(['audioData','courseaudioListInfo','audioOrVideo','timeArry','localaudioListInfo','videoData','statusCourseChoose','phoneType'])
    },
    watch:{
        changeDurationNew(newVal, oldVal){
            if(newVal!=oldVal){
                if(newVal>1){
                    this.londUrlBool = false;
                    if(!this.londUrlBoolTow){
                        setTimeout(()=>{
                            this.londUrlBoolTow = true;
                        },2000);
                    }
                }
                this.changeDuration=Number(newVal);
            }
        },
        statusCourseChoose(news,olds){
            if(news!=-1&&news!=olds){
                let data = this.datalist[news];
                this.$emit('toVideoEven',{id:data.id,courseId:data.courseId,targetDuration:data.targetDuration,courseId:data.courseId,isTry:data.isTry,lastStudyPoint:data.lastStudyPoint});
            }
        },    
        changeDataMoney(news,olds){
            if(news){
                if(news==1){
                    this.purchaseCourse();
                }else{
                    this.decryptPhoneNumber(news);
                }
            }
        },    
        periodObg:{
            handler(newVal, oldVal) {
                if(newVal.firstTouch){
                    if(newVal.periodId&&newVal.periodId!=oldVal.periodId){
                        this.openType = newVal.newPath;
                        this.periodId = newVal.periodId;
                        this.courseIds = newVal.courseId;
                        this.timeDuration = Number(newVal.targetDuration);
                    }
                }else{
                    this.openType = newVal.newPath;
                    this.periodId = newVal.periodId;
                    if(this.objs.courseId!=''){
                        if(this.versionType){
                            if(!this.audioData.playerCreat){
                                let temp = Object.assign({},this.videoData,{studyPoint:[]});          
                                console.log("temp1",temp);                        
                                this.setVideoDateEven(temp);            
                                this.getCoursePath(newVal.periodId,newVal);
                            }else{      
                                if(newVal.newPath){
                                    this.londUrlBool=true; 
                                    this.londUrlBoolTow = false;
                                }else{
                                    this.londUrlBool=false; 
                                }                                    
                                if(this.player==''){
                                    this.player = wx.getBackgroundAudioManager();
                                }                                  
                                let temp = Object.assign({},this.videoData,{studyPoint:[]})
                                console.log("temp2",temp);
                                this.setVideoDateEven(temp);               
                                this.changeDuration = 1;       
                                var subsectionCourse = {
                                    periodId:newVal.periodId,
                                    targetDuration:newVal.targetDuration,
                                    newPath:newVal.newPath,
                                    isTrySee:newVal.isTrySee,
                                    courseId:newVal.courseId,
                                    lastStudyPoint:newVal.lastStudyPoint
                                };                                        
                                this.getAuthCoursePath(this.player,subsectionCourse);
                            }
                        }
                    }
                }
            },        
            immediate:true,    
            deep:true
        },
        playOrPauseIcon(cur,old){
            if(cur!=old){
                if(cur){
                    setTimeout(()=>{
                        this.showHideTypeOne = false;
                    },2000);
                }else{
                    this.showHideTypeOne = true;
                }
            }
        },
        objs(cur,old){
            // if(JSON.stringify(cur)!=JSON.stringify(old)){
            //     this.tteacherNameList();
            // }
            if(Number(cur.courseId)==Number(this.audioData.courseId)){
                if(this.audioData.playFlag){
                    this.playOrPauseIcon = true;
                    this.playFlag = true;
                    this.getDurations = true;
                    // cons 
                }else{
                    this.playOrPauseIcon = false;
                    this.playFlag = false;
                    this.getDurations = false; 
                }    
            }else{
                this.playOrPauseIcon = false;
                this.playFlag = false;
                this.getDurations = false;                
            }
        }
    },     
    mounted(){
    },    
    methods: {
        ...mapActions(['setPlayCourseState','setAudioData','setStatusCourseChoose','setCourseaudioListInfoData','setTimeArryData','setLessonListNums','setLocalaudioListInfoData','setVideoDateEven']),
        chooseSecond(data){
            uni.navigateTo({
                url: `/pages/search/index?teacherName=${data.name}`
            });              
        },
        iosDegilogs(){
            wx.showToast({
                title: '由于相关规范，IOS功能暂不可用！',
                icon: 'none',
                mask:false,
                duration: 1500//持续的时间
            })              
        },
        pressClickEvenEmit(){
            console.log("asddasdasdas");
            this.playOrPauseIconEven();
        },
        //查看手机机型
        getMobilePhoneInfo(){
            var self = this;
            wx.getSystemInfo({
                success (res) {
                    self.phoneTypeInfo = res.model;
                }
            })				
        },        
        // tteacherNameList(){
        //         let stringLists = '';
        //         if(this.objs.lectureTeacherList){
        //             this.objs.lectureTeacherList.forEach((element,index) => {
        //                 if((index+1)!=this.objs.lectureTeacherList.length){
        //                     stringLists = stringLists+element.name+' | ';
        //                 }else{
        //                     stringLists = stringLists+element.name;
        //                 }
        //             });
        //             this.nameListArrays = stringLists;
        //         }
        // },                
        //创建音频播放器
        creatBackAudioObject(src,lastTimes){
            var self =this;
            const version = wx.getSystemInfoSync().SDKVersion;
            if (compareVersion(version, '1.9.94') >= 0){
                        console.log('从新创建新的');
                        const backgroundAudioManager = wx.getBackgroundAudioManager()
                        backgroundAudioManager.title = this.objs.title
                        backgroundAudioManager.epname = ''
                        backgroundAudioManager.singer = this.objs.lectureTeacherList[0].name
                        backgroundAudioManager.src = src;
                        if(this.phoneType.indexOf(this.phoneTypeInfo)!=-1){
                            setTimeout(()=>{
                                backgroundAudioManager.pause();
                                backgroundAudioManager.seek(lastTimes+2);
                                backgroundAudioManager.play();
                            },1000);
                        }
                        backgroundAudioManager.startTime=lastTimes;
                        backgroundAudioManager.protocol = 'hls';
                        backgroundAudioManager.playbackRate= 1;                      
                        backgroundAudioManager.onCanplay(()=>{
                            console.log("可以播放了");
                            this.londUrlBool = false;
                            this.playFlag=true;
                        });  
                        backgroundAudioManager.onTimeUpdate(()=>{
                            this.backgrCurrentTime = backgroundAudioManager.currentTime;
                        })                           
                        //监听背景音乐播放；
                        backgroundAudioManager.onPlay(()=>{
                            console.log('我播放了');     
                            this.audioClickFirst = false; 
                            var realLearnRatelong = self.$store.state.timeArry;
                            if(realLearnRatelong.length>0){
                                self.$store.commit('SETTimeARRYS',[]);
                            }                                                   
                            setTimeout(()=>{
                                if(this.courseEveryTime==0){
                                    this.courseEveryTime = backgroundAudioManager.duration;
                                } 
                            },4000);
                            //播放的时候进行进度条事件通知;
                            this.playOrPauseType = true;
                            this.playOrPauseIcon = true;
                            this.timeDurationIsover = -1;
                            this.playFlag=true;
                            this.$emit('progressEmit',{type:false,objs:backgroundAudioManager});                           
                            //第一次创建的时候就保存状态
                            if(!this.isOkPlay){
                                this.isOkPlay = true;
                                let audioDataLet = this.$store.state.audioData;
                                let copyAudioDataLet = this.$store.state.copyAudioData;
                                let temp ={}; 
                                let tempTwo = {};
                                if(this.isNewPageType){
                                    temp = Object.assign({},audioDataLet,{
                                        title:this.objs.title,
                                        surfacePlot:this.objs.surfacePlot,
                                        total:this.$formatSeconds(this.timeDuration),
                                        courseId:this.objs.courseId,
                                        playerCreat:true,
                                        playFlag:true,
                                        periodId:self.periodId,
                                        show:false
                                    });
                                    tempTwo = Object.assign({},copyAudioDataLet,{
                                        title:this.objs.title,
                                        surfacePlot:this.objs.surfacePlot,
                                        total:this.$formatSeconds(this.timeDuration),
                                        courseId:this.objs.courseId,
                                        show:false
                                    });
                                    this.$store.commit('SETCOPYAUDIODATA',tempTwo);
                                }else{
                                    temp = Object.assign({},audioDataLet,{
                                        title:copyAudioDataLet.title,
                                        surfacePlot:copyAudioDataLet.surfacePlot,
                                        total:this.$formatSeconds(this.timeDuration),
                                        courseId:copyAudioDataLet.courseId,
                                        playerCreat:true,
                                        playFlag:true,
                                        periodId:self.periodId,
                                        show:true
                                    });
                                    tempTwo = Object.assign({},copyAudioDataLet,{
                                        show:true
                                    });    
                                    this.$store.commit('SETCOPYAUDIODATA',tempTwo);                                
                                }
                                this.$store.commit('SETAUDIODATA',temp)
                            }  
                            this.setPlayCourseState(true);              
                        });                 
                        //监听背景音乐暂停
                        backgroundAudioManager.onPause(()=>{
                            console.log('我暂停了');
                            var audioDataLet = this.$store.state.audioData;
                            var pageStores = this.$store.state.audioOrVideo;
                            this.playOrPauseType = false;
                            this.playOrPauseIcon = true; 
                            this.playFlag = false;
                            let temp = Object.assign({},audioDataLet,{playFlag:false});
                            this.$store.commit('SETAUDIODATA',temp);
                            this.setPlayCourseState(false); 
                            self.$emit('progressEmit',{type:true,objs:backgroundAudioManager});
                            if((pageStores=='video'||pageStores=='other')||(pageStores=='audio'&&audioDataLet.courseId!=this.courseIds)){
                                console.log("没进来了");
                            }else{
                                console.log("进来了"); 
                                this.getListValToTimeEven(audioDataLet);
                            }
                        });
                        backgroundAudioManager.onEnded(()=>{
                            console.log("播放结束")    
                            this.isOkPlay = false;                    
                            if(this.timeDurationIsover==-1){
                                this.timeDurationIsover = this.periodId;
                               //自动下一首播放
                                if(!this.getDurations){
                                    this.getDurations = true;
                                }                               
                                this.changeIndexForEnen(false);
                            }
                        });             
                        //监听背景音频停止事件
                        backgroundAudioManager.onStop(()=>{
                            console.log('我停止了');                            
                            this.playFlag = false;
                            this.isOkPlay = false;
                            this.playOrPauseType = false;   
                            this.playOrPauseIcon = true; 
                            var audioDataLet = this.$store.state.audioData;    
                            var timeArryLet = this.$store.state.timeArry;                   
                            self.$emit('progressEmit',{type:true,objs:backgroundAudioManager});
                            if(Number(audioDataLet.courseId)>0&&timeArryLet.length>0){
                                console.log('从这里进入的？');
                                this.getListValToTimeEven(audioDataLet);
                                this.tabRemoveLocalInfo();
                            }
                            if(this.timeDurationIsover!=this.periodId&&this.courseEveryTime>=this.timeDuration&&(this.courseEveryTime-this.backgrCurrentTime<1)){
                                this.timeDurationIsover = this.periodId;
                                this.courseEveryTime=0;
                                //自动下一首播放
                                if(!this.getDurations){
                                    this.getDurations = true;
                                }                                
                                this.changeIndexForEnen(false);
                            }                            
                        });                    
                        this.player = backgroundAudioManager
            }
        },
        //获取用户信息
        getUserInfoEven(){
            var userInfo = JSON.parse(wx.getStorageSync('userInfo')); 
            if(userInfo.cellphone){
                this.unserIsLogenType = true;
            }else{
                this.unserIsLogenType = false;
            }
        },
        //浮动按钮删除
        tabRemoveLocalInfo(){                                                   
                   var temp = {
                        title:'',//标题
                        cur:'00:00',//当前播放时间
                        total:'20:00',//总时间
                        surfacePlot:'',//课程封面
                        courseId: '',//课程ID
                        show:false,//音频播放条是否存在
                        playFlag: false,//是否在播放中
                        periodId: '',//课时id;
                        playerCreat:false
                    };
                    console.log("同手音频删除");
                    this.$store.commit('SETAUDIODATA',temp)                    
                    this.$store.commit('SETTimeARRYS',[])         
        },
        getListValToTimeEven(data){
			//暂停，切换页面调用接口；
                var self = this;
                    wx.getNetworkType({
                        success (res) {                
                        var realLearnRatelong = self.$store.state.timeArry;
                        let query = {
                            periodId:data.periodId,//课时id 
                            courseId:data.courseId,
                            learnRate:self.changeDuration,
                            realLearnRate:realLearnRatelong.length,
                            studyPoint:realLearnRatelong.toString(),
                            lastStudyPoint:self.changeDuration
                        };
                        if (res.networkType == 'wifi'){
                            query['netType'] = 2;
                        }else{
                            query['netType'] = 1;
                        }                        
                        self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(res=>{
                            if(res.data.status==200){
                                console.log('成功了删除');
                                self.$store.commit('SETTimeARRYS', [])
                            }
                        });
                    }
                });                          
        },        
        //拖拽过程中触发事件
        onDragEven(data){
            if(data.type){
                if(!this.onDragType){
                    this.onDragType = true;
                }
            }else{
                setTimeout(()=>{
                    this.onDragType = false;
                },300);
            }
        },
        //滚动条拖动定位播放
        setDataToHttp(data){
            if(!this.versionType){
                // this.touchSeekEven(data.timeInfo);
                // this.play();
            }else{ 
                this.$emit('lockNumEmit',{lockNum:0});
                this.player = wx.getBackgroundAudioManager();
                this.player.seek(Number(data.timeInfo));
                this.playFlag = true;
                let temp = Object.assign({},this.audioData,{playFlag:this.playFlag})
                this.setAudioData(temp);                           
            }
        },
        //自动下一首播放
        //全屏 
        requestFullScreen(){
             this.audioContext.requestFullScreen();
        },
        //退出全屏
        exitFullScreen(){
             this.audioContext.exitFullScreen();
        },    
        //点击按钮是否播放
        //type:1停止;2播放;
        playOrPauseIconEven(){
                var self = this;
                var audioDataLet = this.$store.state.audioData;
                if(!audioDataLet.show){
                    //点击播放当全局唯一音频对象不存在时，走创建流程
                    if(!audioDataLet.playerCreat){                    
                        //打开进度条和播放按钮
                        if(!this.getDurations){
                            this.getDurations = true;
                            this.changeIndexForEnen(true);
                        }else{
                            this.getCoursePath(this.periodObg.periodId,this.periodObg);
                        } 
                        
                    }else{
                        //当前全局音频对象存在时，将音频对象赋值
                        this.player = wx.getBackgroundAudioManager();
                        //再根据状态控制播放场景1.正在播放,就暂停
                        if(this.objs.courseId==audioDataLet.courseId){
                            if(this.playFlag){
                                this.playFlag = false;
                                this.playOrPauseIcon = false;
                                this.player.pause();
                            }else{
                                this.player.play();
                                this.playFlag = true;   
                                this.playOrPauseIcon = true;                                  
                            }
                        }
                        let temp = Object.assign({},audioDataLet,{playFlag:this.playFlag})
                        this.setAudioData(temp)                        
                    }
                }else{
                    wx.getNetworkType({
                        success (res) {                     
                            if(!self.player){
                                self.player = wx.getBackgroundAudioManager();
                            }
                            //暂停，切换页面调用接口；
                            var realLearnRatelong = self.$store.state.timeArry;          
                            var data = audioDataLet;
                            let query = {
                                periodId:data.periodId,//课时id 
                                courseId:data.courseId,
                                learnRate:realLearnRatelong[realLearnRatelong.length-1],
                                realLearnRate:realLearnRatelong.length,
                                studyPoint:realLearnRatelong.toString(),
                                lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1]
                            };
							if (res.networkType == 'wifi'){
								query['netType'] = 2;
							}else{
								query['netType'] = 1;
                            }                            
                            self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(res=>{
                                if(res.data.status==200){ 
                                    self.$store.commit('SETCOURSEAUDIOLISTINFO',self.$store.state.localaudioListInfo);
                                    self.$store.commit('SETLOCALAUDIOLISTINFO',[]);
                                    self.$store.commit('SETTimeARRYS',[]);
                                    if(audioDataLet.courseId!=self.courseIds){
                                        self.setStatusCourseChoose(-1);
                                        setTimeout(()=>{
                                            if(!self.getDurations){
                                                self.getDurations = true;
                                            }
                                            self.changeIndexForEnen(true);
                                        },1000);
                                    }
                                }
                            });
                    }
                }); 
            }
        },  

        //拖动播放
        // touchSeekEven(unms){
        //     this.audioContext.seek(Number(unms));
        // },
        //手指按下事件
        touchstartEven(data,type){
            if(type==2){
                this.touchVar = true;
            }
        },
        touchmoveEven(data,type){
        },
        //手指抬起事件
        touchendEven(data,type){
            var self = this
            this.touchVar = false;
            this.maskType = type; 
            if(type==1){
                if(this.playOrPauseType&&!this.onDragType){
                    this.showHideTypeOne = true;
                    setTimeout(()=>{
                        if(self.playOrPauseType){
                            this.showHideTypeOne = false;
                        }
                    },2000);
                }
                if(!this.playOrPauseType){
                    this.showHideTypeOne = true;
                }                
            }
        },
        audioErrorCallback: function (e) {
            console.log(e.target.errMsg)
        },
        //新版本音频使用;        
        getAuthCoursePath(player,subsectionCourse){
                var self = this;        
                let query = {
                    definitionType: 0,
                    periodId: Number(subsectionCourse.periodId),//课时id 
                    courseId: subsectionCourse.courseId
                }
                this.periodId = Number(subsectionCourse.periodId);
                if(subsectionCourse.isTrySee==1||self.objs.isVip==1||self.objs.isBuy==1||self.objs.timeLimitType==0||self.objs.isFree==1){
                    this.timeDuration = Number(subsectionCourse.targetDuration);
                    this.changeDuration= subsectionCourse.lastStudyPoint;  
                    wx.getNetworkType({
                        success (res) {               
							if (res.networkType == 'wifi'){
								query['netType'] = 2;
							}else{
								query['netType'] = 1;
							}                                 
                            self.$http.post(self.$server.getResoursePlayUrl,query).then(resInfo=>{
                                if(resInfo.data.status==200){
                                    self.playerIsNo = false;
                                    self.src = resInfo.data.content; 
                                    if(subsectionCourse.newPath){
                                        var lastTimes = 0;
                                        if(self.timeDuration-subsectionCourse.lastStudyPoint<1){
                                            lastTimes = 0;
                                        }else{
                                            lastTimes = subsectionCourse.lastStudyPoint;
                                        }
                                        if(!self.getDurations){
                                            self.getDurations = true;
                                        }                                
                                        self.creatBackAudioObject(resInfo.data.content,lastTimes);                              
                                    }
                                }
                            }); 
                        }
                    });                     
                }else{
                        if(this.audioData.playerCreat){
                            this.player = wx.getBackgroundAudioManager();
                            this.player.stop();
                        }
                        this.playerIsNo = true;
                        self.playOrPauseIcon = false;
                        self.playFlag =false;                   
                        // uni.showToast({
                        //     title: '未购买课程',
                        //     icon:'none',
                        //     duration: 2000
                        // }); 
                }
        },
        getUrlToBackgroundAudio(dataObj){
            var self = this;
                self.periodId = dataObj.periodId;
                self.timeDuration = Number(dataObj.targetDuration);            
            wx.getNetworkType({
                success (res) {       
                    let query = {
                        courseId:self.courseIds,
                        periodId:dataObj.periodId,
                        definitionType:0
                    };        
                    if (res.networkType == 'wifi'){
                        query['netType'] = 2;
                    }else{
                        query['netType'] = 1;
                    }                                 
                    self.$http.post(self.$server.getResoursePlayUrl,query).then(resInfo=>{
                        if(resInfo.data.status==200){
                            self.player = wx.getBackgroundAudioManager();
                            self.playerIsNo = false;
                            self.src = resInfo.data.content; 
                            self.player.src=resInfo.data.content;
                            self.player.seek(0);
                        }
                    }); 
                }
            });
        },
        //根据小标切换视频
        changeIndexForEnen(type){
            var self = this;      
            let audioCoursetList =  []; 
            var pageTypes = this.$store.state.audioOrVideo;
            var audioDataLet = this.$store.state.audioData;
            var copyAudioDataLet = this.$store.state.copyAudioData;
            var list1 = this.$store.state.courseaudioListInfo;
            var list2 = this.$store.state.localaudioListInfo;
            if(pageTypes=='video'||pageTypes=='other'||(pageTypes=='audio'&&copyAudioDataLet.show)||!list2.length){
                audioCoursetList = list1;
            }else{
                audioCoursetList = list2;
            }     
            function checkAdult(element){
                if(element.isTrySee==1||self.objs.isVip==1||self.objs.isBuy==1||self.objs.timeLimitType==0){
                    return  element;
                }
            }  
            this.setLastTimeToStort(self.periodId);
            let newArray = audioCoursetList.map(element=>{return element.periodId});
            let indexsId = newArray.indexOf(self.periodId); 
            if(type){
                this.isNewPageType = true;
                this.setStatusCourseChoose(indexsId);
            }else{
                var isokInfoArry =audioCoursetList.slice(indexsId+1);
                var isTryCourse = isokInfoArry.filter(checkAdult);               
                if(indexsId!=newArray.length-1){
                    if(newArray&&isTryCourse.length>0){
                        newArray.forEach((element,index)=>{
                            if(element==isTryCourse[0].periodId){
                                if(pageTypes=='video'||pageTypes=='other'||(pageTypes=='audio'&&copyAudioDataLet.show)){
                                    //获取url从新赋值；
                                    this.isNewPageType = false;
                                    this.getUrlToBackgroundAudio(isTryCourse[0]);
                                }else{
                                    this.isNewPageType = true;
                                    this.setStatusCourseChoose(index);
                                }
                            }
                        });
                    }else{
                        this.playFlag=false;
                        this.playOrPauseType = false;
                        this.playOrPauseIcon = false;
                        let temp = Object.assign({},audioDataLet,{playFlag:false});
                        this.setAudioData(temp);
                        this.$store.commit('SETAUDIODATA',temp)
                        self.$emit('progressEmit',{type:true,objs:backgroundAudioManager});
                        console.log('没有课程目录了');                        
                    }
                }else{
                    console.log('没有课程目录了');
                    this.playFlag = false;
                    this.playOrPauseType = false;
                    this.playOrPauseIcon = false;
                    let temp = Object.assign({},audioDataLet,{playFlag:this.playFlag});
                    this.setAudioData(temp);
                    this.$store.commit('SETAUDIODATA',temp)
                }
            } 
        },
        //切换存储数组最后的值；
        setLastTimeToStort(periodId){
            //取出存储的路径播放数组；
            var self= this;
            let audioCoursetList =  this.$store.state.courseaudioListInfo; 
            //获取数据存储的最后值；
            var realLearnRatelong = self.$store.state.timeArry; 
            if(realLearnRatelong.length){
                var lastVals = realLearnRatelong[realLearnRatelong.length-1];
                audioCoursetList.forEach((element,index)=>{
                    if(element.periodId==periodId){
                        element.lastStudyPoint = lastVals;
                    }
                });
                this.setLessonListNums(audioCoursetList.length);
            }
        },
        //老版本音频兼容
        getCoursePath(ids,newVal){
                var self = this;              
                let query = {
                    definitionType: 0,
                    periodId: Number(ids),//课时id 
                    courseId: this.objs.courseId
                }
                this.timeDuration = Number(newVal.targetDuration);
                if(Number(this.objs.isFree)==1||Number(this.objs.isVip)==1||this.objs.isBuy==1||this.objs.timeLimitType==0||newVal.isTrySee==1){
                    wx.getNetworkType({
                        success (res) {               
							if (res.networkType == 'wifi'){
								query['netType'] = 2;
							}else{
								query['netType'] = 1;
							}                     
                            self.$http.post(self.$server.getResoursePlayUrl,query).then(resInfo=>{
                                if(resInfo.data.status==200){
                                    self.playerIsNo = false;
                                    self.src = resInfo.data.content;  
                                    if(newVal.newPath){
                                        self.openType = newVal.newPath;
                                        var lastTimes = 0;
                                        if(newVal.targetDuration-newVal.lastStudyPoint<1){
                                            lastTimes = 0;
                                        }else{
                                            lastTimes = newVal.lastStudyPoint;
                                        }             
                                        if(!self.getDurations){
                                            self.getDurations = true;
                                        }                                             
                                        self.creatBackAudioObject(resInfo.data.content,lastTimes);
                                    }                   
                                }else{
                                    self.playerIsNo = true;
                                    if(self.audioData.playerCreat){
                                        self.player = wx.getBackgroundAudioManager();
                                        self.player.stop();
                                        self.src = '';
                                    }                    
                                }
                            });
                        }
                    });                    
                }else{
                    // uni.showToast({
                    //     title: '还未购买该课程',
                    //     icon: 'none'
                    // });                                     
                }

        },        
        //通过绑定手机号登录
        decryptPhoneNumber(e) {
            var self = this;
            if(this.audioData.playerCreat){
                wx.getNetworkType({
                    success (res) {                 
                        if(!self.player){
                            self.player = wx.getBackgroundAudioManager();
                        }
                        //暂停，切换页面调用接口；
                        var realLearnRatelong = self.$store.state.timeArry;           
                        let data = self.audioData;
                        let query = {
                            periodId:data.periodId,//课时id 
                            courseId:data.courseId,
                            learnRate:realLearnRatelong[realLearnRatelong.length-1],
                            realLearnRate:realLearnRatelong.length,
                            studyPoint:realLearnRatelong.toString(),
                            lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1]
                        };
                        if (res.networkType == 'wifi'){
                            query['netType'] = 2;
                        }else{
                            query['netType'] = 1;
                        }
                        self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(res=>{
                            if(res.data.status==200){
                                self.$store.commit('SETTimeARRYS',[]);
                                self.player.stop();
                            setTimeout(()=>{
                                    var ivObj = e.detail.iv
                                    var telObj = e.detail.encryptedData
                                    var codeObj = "";
                                    //---------登录有效期检查
                                    wx.checkSession({
                                        success: function () {
                                            //session_key 未过期，并且在本生命周期一直有效
                                            if (e.detail.errMsg == "getPhoneNumber:ok") { // 同意授权
                                                wx.showLoading();
                                                wx.login({
                                                    success (res) {
                                                        if (res.code) {
                                                            var objs = {
                                                                encryptedData:telObj,
                                                                iv:ivObj,
                                                                code:res.code
                                                            }
                                                            self.getDecryptCellphone(objs); 
                                                        } 
                                                    }
                                                })
                                            }else{
                                                console.log("code有过期");
                                                // 拒绝手机号授权
                                                uni.showToast({
                                                    title: '手机号授权失败！',
                                                    icon: 'none'
                                                });
                                            }
                                        },
                                        fail: function () {
                                        // session_key 已经失效，需要重新执行登录流程
                                        }
                                    });
                            },200);
                            }
                        });  
                    }
                });                            
            }else{
                var ivObj = e.detail.iv
                var telObj = e.detail.encryptedData
                var codeObj = "";
                //---------登录有效期检查
                wx.checkSession({
                    success: function () {
                        //session_key 未过期，并且在本生命周期一直有效
                        if (e.detail.errMsg == "getPhoneNumber:ok") { // 同意授权
                            wx.showLoading();
                            wx.login({
                                success (res) {
                                    if (res.code) {
                                        var objs = {
                                            encryptedData:telObj,
                                            iv:ivObj,
                                            code:res.code
                                        }
                                        self.getDecryptCellphone(objs); 
                                    } 
                                }
                            }) 
                        }else{
                            // 拒绝手机号授权
                            uni.showToast({
                                title: '手机号授权失败！',
                                icon: 'none'
                            });
                        }
                    },
                    fail: function () {
                    // session_key 已经失效，需要重新执行登录流程
                    }
                });                
            }
        },      
        //获取电话号绑定用户电话
        setCellphoneEven(data){
                //调用绑定电话号码的接口；
                var self = this;
                let query = {
                    openId:this.userinfos.userId,//第三方登录的系统用户id
                    tokenType: 2,//访问端类型 1 ios_app 2 android_app 3 web_app 4第三方 5pc端
                    cellphone: data.cellphone,//手机号
                    origin: 14 //14.微信小程序
                };
                this.$http.post(this.$server.setWeChatBindCellphone,query).then(res=>{
                    if(res.data.status==200){
                        //返回的数据；
                        var objs = {
                            nickname:self.userinfos.nickname,
                            cellphone:res.data.content.cellphone,
                            userId:res.data.content.id,
                            isVip:self.userinfos.isVip,
                            token:self.userinfos.token,
                            avatar:self.userinfos.avatar,
                            openId:self.userinfos.openId
                        }
                        wx.removeStorageSync('userInfo')
                        self.userinfos = wx.getStorageSync('userInfo');
                        wx.setStorageSync('userInfo',JSON.stringify(objs));
                        wx.hideLoading();
                        var moneySpikePrice=this.objs.timeLimitType==2?this.objs.spikePrice:this.objs.sellingPrice;
                        wx.redirectTo({
                            url: '../investMoney/index?id='+Number(self.objs.courseId)+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice
                        })
                    }
                });
        },
        //获取解密接口
        getDecryptCellphone(data){
            //调用绑定电话号码的接口；
            let query = {
                encryptedData: data.encryptedData,
                iv: data.iv,
                code:data.code,
                type:2
            };
            wx.setStorageSync('code',data.code);
            this.$http.post(this.$server.getLoginWeChatUserPhone,query).then(res=>{
                if(res.data.status==200){
                    var objs = {
                        cellphone:res.data.content,
                    };
                    this.setCellphoneEven(objs);
                }
            });
        },
        purchaseCourse(){
            var self = this;
            if(this.audioData.playerCreat){
                wx.getNetworkType({
                    success (res) { 
                        if(!self.player){
                            self.player = wx.getBackgroundAudioManager();
                            self.player.stop(); 
                        }else{
                            self.player.stop();
                        }
                        //暂停，切换页面调用接口；
                        var realLearnRatelong = self.$store.state.timeArry;           
                        let data = self.audioData;
                        let query = {
                            periodId:data.periodId,//课时id 
                            courseId:data.courseId,
                            learnRate:realLearnRatelong[realLearnRatelong.length-1],
                            realLearnRate:realLearnRatelong.length,
                            studyPoint:realLearnRatelong.toString(),
                            lastStudyPoint:realLearnRatelong[realLearnRatelong.length-1],
                            show:false
                        };
                        if (res.networkType == 'wifi'){
                            query['netType'] = 2;
                        }else{
                            query['netType'] = 1;
                        }
                        self.$http.post(self.$server.savePeriodStudyRecordsUser,query).then(res=>{
                            if(res.data.status==200){
                                self.$store.commit('SETTimeARRYS',[])
                                self.setAudioData({
                                    title:'',//标题
                                    cur:'00:00',//当前播放时间
                                    total:'20:00',//总时间
                                    surfacePlot:'',//课程封面
                                    courseId: '',//课程ID
                                    show:false,//音频播放条是否存在
                                    playFlag: false,//是否在播放中
                                    periodId: '',//课时id;
                                    playerCreat:false
                                });
                                self.setStatusCourseChoose(-1);
                                self.setPlayCourseState(false);
                                self.setCourseaudioListInfoData([]);
                                setTimeout(()=>{
                                    var moneySpikePrice=self.objs.timeLimitType==2?self.objs.spikePrice:self.objs.sellingPrice;
                                    wx.redirectTo({
                                        url: '../investMoney/index?id='+Number(self.objs.courseId)+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice
                                    });
                                },200);
                            }
                        });  
                    }
                });                           
            }else{
                var moneySpikePrice=this.objs.timeLimitType==2?this.objs.spikePrice:this.objs.sellingPrice;
                wx.redirectTo({
                    url: '../investMoney/index?id='+Number(self.objs.courseId)+"&timeLimitType="+self.objs.timeLimitType+"&spikePrice="+moneySpikePrice,
                    animationDuration:'500',
                    success: res => {},
                    fail: () => {},
                    complete: () => {}
                });                
            }
        }

    }
        
}


</script>

<style lang="scss">
.audio-pluge{
    // background: #fff;
    // padding: 0 0 29rpx 0;     
    .audio-box{
        position: relative;
        .shareCss{
            position: absolute;
            z-index: 99999;
            top: 10rpx;
            right: 10rpx;
            width: 50px;
            height: 20px;
            border-radius: 20px;
            font-size: 24rpx;
            background: rgba(217,10,10,0.3);
            color: #fff;
            text-align: center;
            line-height: 20px;
        }
        .audioImgBox{
            width: 100%;
            height: 100%;
            .audioImg{
                width: 100%;
                height: 100%;                
            }
        }
        .myAudioCss{
            width:100% !important;
            height: 480rpx;
        }
        .copy_audio{
            width:100% !important;
            height: 422rpx;   
            position: relative;
            .londing_xcx{ 
                position: absolute;
                top:0;
                width:100% !important;
                height: 422rpx;    
                display: flex;    
                flex-direction: column;
                align-items: center;
                justify-content: center;
                background: rgba(0,0,0,0.5);
                .contentinfo{
                    color:#fff;
                    font-size: 30rpx;
                }                                   
            }
            image{
                width: 100%;
                height: 100%;
            }  
            .player-btn{
                position: absolute;
                top:50%;
                left: 50%;
                transform: translate(-50%,-50%);
                z-index: 10;
                font-size: 30rpx;
                color:red;
            }
            .audio-layout{
                position: absolute;
                z-index: 10;
                top: 0;
                left: 0;
                bottom: 0rpx;
                right: 0;
                background: rgba(0,0,0,0.4);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                image{
                    width:102rpx;
                    height: 102rpx;
                }
            }                   
        }
    }
    .progressBox{
        position: absolute;
        bottom: 0rpx;
        left: 0rpx;
        right: 0rpx;
        top: 0;
        background: rgba(0,0,0,0.3);
        .progressBox2{
            width: 100%;
            position: absolute;
            bottom: 33rpx;
        }
    }
    .uni-btn-v{
        .textCourse{
            // padding: 30rpx 30rpx 0;
            .userBox{
                // display: flex;
                // flex-direction: row;
                // justify-content:space-between;
                // align-items: flex-end;
                .textInfo{
                    .courseIntro{
                        font-size: 30rpx;
                        color: #666666;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        -webkit-line-clamp:2;
                        -webkit-box-orient: vertical;                         
                    }
                    text{
                        margin-left: 10rpx;
                    }
                    // .titleRow1{
                    //     margin-top: 20rpx;
                    //     font-size: 28rpx;
                    //     color: #666666FF;
                    //     width: 500rpx;
                    //     overflow:hidden; //超出一行文字自动隐藏
                    //     text-overflow:ellipsis;//文字隐藏后添加省略号
                    //     white-space:nowrap; 
                    // }
                    .titleRow2{
                        display: flex;
                        flex-direction: row;
                        justify-content:space-between;
                        align-items: center;                         
                        margin-top: 20rpx;
                        font-size: 26rpx;
                        color: #999999;
                        .titleRow2Next{
                            display: flex;
                            flex-direction: row;
                            justify-content: start;
                            align-items: center;
                            image{
                                width: 36rpx;
                                height: 36rpx;
                            }
                            .texts{
                                padding: 0 10rpx;
                                height: 36rpx;
                                line-height: 36rpx;
                                line-height: 36rpx;
                                font-size: 28rpx;
                                color: #999999;
                            }                            
                        }
                    }                    
                }
            }
            .moneyCourse{
                width: 680rpx;
                height: 80rpx;
                margin: 30rpx auto 0;
                .moneyBut{
                    width: 100%;
                    height: 80rpx;
                    line-height: 80rpx;
                    text-align: center;
                    font-size: 30rpx;
                    border-radius: 80rpx;
                    color: #fff;
                    // background-color: #C81229; 
                    background-image: linear-gradient(to left,#C30D23, #EC354B);                       
                }
            }  
            .teacherImgs{   
                padding: 1rpx 30rpx 10rpx;
                background: #fff;
                margin-top: 20rpx;
                .teacherBoxName{
                    font-size:40rpx;
                    font-weight:800;
                    position: relative;
                    margin: 30rpx 0;
                    view{
                        height: 40rpx;
                        line-height: 40rpx;
                        padding: 0 30rpx;
                        font-size: 36rpx;
                        color: #333;
                        font-weight: 500;            
                    }
                }
                .teacherBoxName:before{
                        content:'';
                        height: 40rpx;
                        width: 8rpx;
                        bottom: 0;
                        left: 10rpx;                
                        display: block;   
                        position: absolute;
                        background: #C30D23;
                }         
                .scroll_box{
                    width: 680rpx;
                    margin: 0 auto;
                    overflow: hidden;
                    white-space: nowrap;
                    height: 240rpx;
                    // padding: 20rpx 0;
                    scroll-view{
                        height: 100%;
                        width: auto;
                        overflow:hidden;
                        .item_list{
                            text-align: center;
                            display: inline-block;
                            margin-right: 17rpx;
                            color:#333;
                            background: #fff;
                            width:160rpx;
                            border-radius: 6rpx;
                            position: relative;
                            height: 240rpx;
                            image{
                                height: 140rpx;
                                width: 140rpx;
                                border-radius: 50%;
                                position: absolute;
                                top: 0;
                                left: 10rpx;
                            } 
                            .teacherName{
                                width: 150rpx;
                                font-size: 28rpx;
                                text-align: center;
                                position: absolute;
                                left: 5rpx;
                                top:150rpx;
                            }                   
                        }                
                    }            
                }           

            }                       
            .courseTitle{
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp:2;
                -webkit-box-orient: vertical;              
                font-size: 34rpx;
                font-weight: 700;
                color: #333333;
            }
        }
    }
}
</style>
<style>
::-webkit-scrollbar {
    width: 0;
    height: 0;
    color: transparent;
}
</style>