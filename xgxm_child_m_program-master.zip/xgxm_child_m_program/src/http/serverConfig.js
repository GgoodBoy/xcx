export default {
    getHomePageInfo: '/home/getPageInfo',
    getResoursePlayUrl:'/courses/getWechatResoursePlayUrl',   //xcx获取音视频播放地址
    // getResoursePlayUrl: '/courses/getResoursePlayUrl',
    getCourseInfoCourses: '/courses/getWechatCourseInfo',  // xcx根据课程ID查询课程详情
    // getCourseInfoCourses: '/courses/getCourseInfo',
    getPeriodsListByCourseIdCourses:'/courses/getWechatPeriodsListByCourseId',   //xcx根据课程ID查询课时信息列表
    // getPeriodsListByCourseIdCourses: '/courses/getPeriodsListByCourseId',
    // 获取我的优惠券列表
    getWechatUserCouponsListForBuyCourse: '/user/getWechatUserCouponsListForBuyCourse',
    // 购买课程
    getCourseWechatBuyCourse: '/courses/wechatBuyCourse',
    //微信支付回调地址
    getUserWechatNotifyUrl: '/user/wechatNotifyUrl',
    //绑定手机(验证手机号码是否注册)
    setWeChatBindCellphone:'/user/weChatBindCellphone',
    //微信JSAPI支付获取openId
    getWechatAppletOpenIdCommon: '/common/getWechatAppletOpenId',
    //获取登录用户电话号码
    getLoginWeChatUserPhone: '/login/getWeChatUserPhone',
    //查询课程下单页面数据
    getWechatOrderForCourseInfoCourses:'/courses/getWechatOrderForCourseInfo',
    savePeriodStudyRecordsUser: '/user/savePeriodStudyRecords',
    getOrderForCourseInfo: '/courses/getOrderForCourseInfo',
    loginForWeChat:'/login/loginForWeChat',//小程序登录
    loginWeChatGetUserInfo:'/login/loginWeChatGetUserInfo',//根据openID获取授权/登录用户信息
    getWechatHomeInfo:'/home/getWechatHomeInfo',//获取小程序首页数据
    getWechatColumnList:'/home/getWechatColumnList',//获取首页栏目列表
    getWechatAllClassify:'/classify/getWechatAllClassify',//课程分类
    getWechatListByNavigation:'/courses/getWechatListByNavigation',//分类导航根据分类id查询课程列表
    getWechatList:'/timeLimitedDiscount/getWechatList',//获取限时购列表
    getWechatFreeList:'/courses/getWechatFreeList',//查询免费课程列表
    getWechatHotList:'/courses/getWechatHotList',//获取热门课程列表
    getWechatListByClassifyIdLabelId:'/courses/getWechatListByClassifyIdLabelId',//根据标签id或分类id查询课程列表
    getWechatHotWordList:'/home/getWechatHotWordList',//获取热词列表
    getWechatDefaultHotWords:'/home/getWechatDefaultHotWords',//获取默认词
    searchWechatCourseList:'/courses/searchWechatCourseList',//课程搜索
    getWechatPurchasedCourseList:'/courses/getWechatPurchasedCourseList',//查询用户课程列表
    getWechatCourseOrderList: '/user/getWechatCourseOrderList',//查询用户订单列表
    //小程序少儿版
    getSearchChildCourseList: '/courses/searchWechatChildCourseList',
    getUserChildrenInfo:'/user/getWechatUserInfoById'//少儿查询用户详情
}