module.exports = {
  root: true,
  env: {
    node: true,
    es6:true,
    browser:true,
  },
  'extends': [
    'plugin:vue/essential',
    'eslint:recommended',
    '@vue/typescript/recommended',
  ],
  parserOptions: {
    ecmaVersion: 2020
  },
  ignorePatterns: ['node_modules/'],
  rules: {
    '@typescript-eslint/ban-ts-ignore':0,
    /*忽略any类型注解 */
    '@typescript-eslint/no-explicit-any': 'off',
    /*类型批注周围需要一致的间距 */
    '@typescript-eslint/type-annotation-spacing':0,
    /*禁止给一个初始化时直接赋值为number、string或boolean的变量显式的指定类型 */
    '@typescript-eslint/no-inferrable-types':0,
    /*禁止使用require来引入模块 */
    '@typescript-eslint/no-var-requires':'error',
    /*该规则禁止词法声明（let，const，function和class在）case/default*/
    'no-case-declarations':0,
    /*不允许使用var关键字*/
    'no-var': 'error',
    /*不允许使用that = this来定义指向对象*/
    'consistent-this': ['error', '$vue'],
    /*字符串只能使用单引号或者反引号*/
    'quotes': ['error', 'single', { 'allowTemplateLiterals': true }],
    /* 禁止在条件表达式中使用赋值语句, 禁止出现= */
    'no-cond-assign': 'error',
    /* 强制驼峰法命名 */
    'camelcase':'error',
    /* 禁止在正则表达式中使用控制字符 ：new RegExp('\x1f')*/
    'no-control-regex': 'error',
    /* ES6推荐对象或者数组，多行模式必须带逗号，单行模式不能带逗号 */
    'comma-dangle': [0, 'always-multiline'],
    /* 禁止重复的 case 标签*/
    'no-duplicate-case':'error',
     /* 禁止空语句块,{}或者函数必须有主体*/
    'no-empty':['error', { 'allowEmptyCatch': true }],
    /* 禁止 if 语句中有 return 之后有 else*/
    'no-else-return': [0,{'allowElseIf':true}],
    /* 强制数组方括号中使用一致的空格 */
    'array-bracket-spacing': ['error', 'never'],
    /* 函数末尾不必须return */
    'consistent-return':0,
    /*可以使用arguments*/
    'prefer-rest-params': 0,
    /*允许if return 之后有else,方便调试 */
    'no-unreachable':0,
    'no-useless-escape':0
  },
  overrides: [
    {
      files: [
        '**/__tests__/*.{j,t}s?(x)',
        '**/tests/unit/**/*.spec.{j,t}s?(x)'
      ],
      env: {
        mocha: true
      },
    }
  ]
}
