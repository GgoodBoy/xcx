const path = require('path');
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin')
const webpack = require('webpack')
const sourceMap = process.env.NODE_ENV === 'development';
const IS_PROD = ['production'].includes(process.env.NODE_ENV)
module.exports = {
  // 基本路径
  publicPath: '/platform/',
  // 输出文件目录
  outputDir: 'platform',
  // eslint-loader 是否在保存的时候检查
  lintOnSave: 'error',
  // webpack配置
  chainWebpack: (config) => {
    config.plugins.delete('preload');
    config.plugins.delete('prefetch');
    config.resolve.symlinks(true);
    config.module
      .rule('images')
      .use('url-loader')
      .loader('url-loader')
      .tap(options => Object.assign(options, { limit: 20000 }));
    config.plugin('provide').use(webpack.ProvidePlugin, [{
      'window.Quill': 'quill'
    }])
  },
  configureWebpack: config => {
    config.resolve = {
      extensions: ['.js', '.vue', '.json', '.ts', '.tsx'],
      alias: {
        vue$: 'vue/dist/vue.js',
        '@': path.resolve(__dirname, './src'),
      }
    }
    config.plugins.push(
      new webpack.DllReferencePlugin({
        context: process.cwd(),
        manifest: require('./public/vendor/vendor-manifest.json')
      })
    )
    config.plugins.push(
      new AddAssetHtmlPlugin({
        filepath: path.resolve(__dirname, './public/vendor/*.js'),
        publicPath: '/platform/vendor',
        outputPath: './vendor'
      })
    )
    if(process.env.NODE_ENV !== 'production'){
      config.devtool = 'source-map'
    }
  },
  // 生产环境是否生成 sourceMap 文件
  productionSourceMap: sourceMap,
  // css相关配置
  css: {
    // 是否使用css分离插件 ExtractTextPlugin
    extract: IS_PROD,
    // 开启 CSS source maps?
    sourceMap: false,
    // css预设器配置项
    loaderOptions: {},
    // 启用 CSS modules for all css / pre-processor files.
    requireModuleExtension: true
  },
  // use thread-loader for babel & TS in production build
  // enabled by default if the machine has more than 1 cores
  parallel: require('os').cpus().length > 1,
  // PWA 插件相关配置
  pwa: {},
  // webpack-dev-server 相关配置
  devServer: {
    open: process.platform === 'darwin',
    host: '0.0.0.0',
    port: 8080, //8080,
    https: false,
    hotOnly: false,
    before: app => {},
  },
  // 第三方插件配置
  pluginOptions: {
    // ...
  }
};
