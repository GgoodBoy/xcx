import { RouteConfig } from 'vue-router'

const dynamicRoutes: Array<RouteConfig> = [
    {
        path:'/index',
        name: 'index',
        component: () => import(/* webpackChunkName: "index" */ '../views/index/index.vue'),
        children:[
            {
                path:'',
                meta:{
                    name:'首页',
                    role:'menu',
                    iconClassName:'data-icon',
                    index:'0',
                    child:[
                        {path:'/index/home',name:'首页'},
                    ]
                }
            },
            {
                path:'',
                meta:{
                    name:'资源库',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index:'1',
                    child:[
                        {path:'/index/resource/video',name:'视频库'},
                        {path:'/index/resource/audio',name:'音频库'},
                        {path:'/index/resource/teacher',name:'教师库'},
                    ]
                }
            },
            {
                path:'',
                meta:{
                    name:'课程',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index:'2',
                    child:[
                        {path:'/index/course/myCourse',name:'我的课程'},
                        {path:'/index/course/auditing',name:'课程审核'},
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'订单',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '3',
                    child:[
                        { path: '/index/order/index', name: '订单' }
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'结算',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '4',
                    child:[
                        { path: '/index/settlement/indexOne', name: '结算' },
                        { path: '/index/settlement/approvalList', name: '财务结算' }
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'认证',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '5',
                    child:[
                        { path: '/index/attestation/userAttestation/index', name: '个人认证' },
                        // { path: '/index/attestation/userAttestation/cashOut', name: '个人提现' },
                        { path: '/index/attestation/companyAttestation/index', name: '机构认证' },
                        // { path: '/index/attestation/companyAttestation/companyCashout', name: '机构提现' },
                        { path: '/index/attestation/adminIsTrators', name: '认证管理' }
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'账户',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '6',
                    child: [
                        { path: '/index/attestation/account/index', name: '更换管理员' },
                        { path: '/index/attestation/account/updatePassword', name: '更换密码' },
                        { path: '/index/attestation/account/updateManage', name: '更换管理员列表' },
                        { path: '/index/attestation/account/accountCashOut', name: '提现账户(个人)' },
                        { path: '/index/attestation/account/cashOutCompany', name: '提现账户(企业)' }
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'统计管理',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '7',
                    child:[
                        { path: '/index/statistics/index', name: '统计' }
                    ]
                }
            },
            {
                path:'',
                meta:{
                    name:'后台管理',
                    role:'menu',
                    iconClassName:'data-icon',
                    index:'8',
                    child:[
                        {path:'/index/backstage/auth',name:'权限管理'},
                        {path:'/index/backstage/role',name:'角色管理'},
                        {path:'/index/backstage/account',name:'后台账户管理'},
                    ]
                }
            },
            {
                path: '',
                meta:{
                    name:'消息管理',
                    role:'menu',
                    iconClassName:'transaction-icon',
                    index: '9',
                    child:[
                        { path: '/index/news/index', name: '消息' }
                    ]
                }
            },
            {
                path:'/index/home',
                name: 'home',
                component: () => import(/* webpackChunkName: "home" */ '../views/index/home/index.vue'),
                meta:{
                    code:'',
                    name:'首页'
                }
            },
            {
                path:'/index/resource/video',
                name:'video',
                component: () => import(/* webpackChunkName: "video" */ '../views/index/resource/video/index.vue'),
                meta:{
                    code:'',
                    name:'视频库',
                }
            },
            {
                path:'/index/resource/video/add',
                name:'video',
                component: () => import(/* webpackChunkName: "videoAdd" */ '../views/index/resource/video/add.vue'),
                meta:{
                    code:'',
                    name:'视频库添加',
                }
            },
            {
                path:'/index/resource/audio',
                name:'audio',
                component: () => import(/* webpackChunkName: "audio" */ '../views/index/resource/audio/index.vue'),
                meta:{
                    code:'',
                    name:'音频库',
                }
            },
            {
                path:'/index/resource/audio/add',
                name:'audio',
                component: () => import(/* webpackChunkName: "audioAdd" */ '../views/index/resource/audio/add.vue'),
                meta:{
                    code:'',
                    name:'音频库添加',
                }
            },
            {
                path:'/index/resource/teacher',
                name:'teacher',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/resource/teacher/index.vue'),
                meta:{
                    code:'',
                    name:'教师库'
                }
            },
            {
                path:'/index/resource/teacher/update',
                name:'teacherUpdate',
                component: () => import(/* webpackChunkName: "teacherUpdate" */ '../views/index/resource/teacher/update.vue'),
                meta:{
                code:'',
                    name:'教师库更新'
                }
            },
            {
                path:'/index/course/myCourse',
                name:'myCourse',
                component: () => import(/* webpackChunkName: "myCourse" */ '../views/index/course/myCourse/index.vue'),
                meta:{
                    code:'',
                    name:'我的课程'
                }
            },
            {
                path:'/index/course/auditing',
                name:'auditing',
                component: () => import(/* webpackChunkName: "auditing" */ '../views/index/course/auditing/index.vue'),
                meta:{
                    code:'',
                    name:'课程审核'
                }
            },
            {
                path:'/index/course/myCourse/update',
                name:'courseUpdate',
                component: () => import(/* webpackChunkName: "courseUpdate" */ '../views/index/course/update/index.vue'),
                meta:{
                    code:'',
                    name:'我的课程发课'
                }
            },
            {
                path:'/index/course/myCourse/update/baseInfo',
                name:'courseUpdateBaseInfo',
                component: () => import(/* webpackChunkName: "courseBaseInfo" */ '../views/index/course/update/baseInfo.vue'),
                meta:{
                    code:'',
                    name:'课程发课基础信息'
                }
            },
            {
                path:'/index/order/index',
                name:'order',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/order/index.vue'),
                meta:{
                    code:'',
                    name:'订单'
                }
            },
            {
                path:'/index/statistics/index',
                name:'statistics',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/statistics/index.vue'),
                meta:{
                    code:'',
                    name:'统计'
                }
            },
            {
                path:'/index/attestation/adminIsTrators',
                name:'settlement1',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/adminIsTrators/index.vue'),
                meta:{
                    code:'',
                    name:'认证管理'
                }
            },
            {
                path:'/index/attestation/adminIsTrators/adminCompanSuccess',
                name:'adminCompanSuccess',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/adminIsTrators/adminCompanSuccess.vue'),
                meta:{
                    code:'',
                    name:'认证管理-机构认证成功'
                }
            },
            {
                path:'/index/attestation/adminIsTrators/adminUserSuccess',
                name:'adminUserSuccess',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/adminIsTrators/adminUserSuccess.vue'),
                meta:{
                    code:'',
                    name:'认证管理-个人认证成功'
                }
            },
            {
                path:'/index/attestation/adminIsTrators/companyToExamine',
                name:'companyToExamine',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/adminIsTrators/companyToExamine.vue'),
                meta:{
                    code:'',
                    name:'认证管理-机构认证审核中'
                }
            },
            {
                path:'/index/attestation/adminIsTrators/userToExamine',
                name:'userToExamine',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/adminIsTrators/userToExamine.vue'),
                meta:{
                    code:'',
                    name:'认证管理-个人认证审核中'
                }
            },
            {
                path:'/index/settlement/indexOne',
                name:'settlement1',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/settlement/indexOne.vue'),
                meta:{
                    code:'',
                    name:'待结算'
                }
            },
            {
                path:'/index/settlement/indexTwo',
                name:'settlement2',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/settlement/indexTwo.vue'),
                meta:{
                    code:'',
                    name:'已结算'
                }
            },
            {
                path:'/index/settlement/approvalList',
                name:'approvals',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/settlement/approvalList.vue'),
                meta:{
                    code:'',
                    name:'财务结算'
                }
            },
            {
                path:'/index/settlement/creatApproval',
                name:'creatApproval',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/settlement/creatApproval.vue'),
                meta:{
                    code:'',
                    name:'创建提现'
                }
            },
            {
                path:'/index/settlement/approvalInfo',
                name:'approvalInfo',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/settlement/approvalInfo.vue'),
                meta:{
                    code:'',
                    name:'审批'
                }
            },
            {
                path:'/index/attestation/userAttestation/index',
                name:'userAttestation',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/userAttestation/index.vue'),
                meta:{
                    code:'',
                    name:'个人认证'
                }
            },
            {
                path:'/index/attestation/updateUserAttes/updateUserAttes',
                name:'updateUserAttes',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/userAttestation/updateUserAttes.vue'),
                meta:{
                    code:'',
                    name:'个人认证修改'
                }
            },
            {
                path:'/index/attestation/userAttestation/setUpUserCashOut',
                name:'setUpUserCashOut',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/userAttestation/setUpUserCashOut.vue'),
                meta:{
                    code:'',
                    name:'个人提现设置'
                }
            },
            {
                path:'/index/attestation/userAttestation/cashOut',
                name:'userAttestation',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/userAttestation/cashOut.vue'),
                meta:{
                    code:'',
                    name:'个人提现'
                }
            },
            {
                path:'/index/attestation/companyAttestation/index',
                name:'companyAttestation',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/companyAttestation/index.vue'),
                meta:{
                    code:'',
                    name:'机构认证'
                }
            },
            {
                path:'/index/attestation/companyAttestation/updateAttestation',
                name:'userAttestation',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/companyAttestation/updateAttestation.vue'),
                meta:{
                    code:'',
                    name:'机构认证修改'
                }
            },
            {
                path:'/index/attestation/companyAttestation/companyCashout',
                name:'companyCashout',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/companyAttestation/companyCashout.vue'),
                meta:{
                    code:'',
                    name:'机构提现'
                }
            },
            {
                path:'/index/attestation/companyAttestation/cashOutstate',
                name:'cashOutstate',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/companyAttestation/cashOutstate.vue'),
                meta:{
                    code:'',
                    name:'提现设置'
                }
            },
            {
                path:'/index/attestation/account/index',
                name:'account',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/index.vue'),
                meta:{
                    code:'',
                    name:'更新管理员1'
                }
            },
            {
                path:'/index/attestation/account/indexNext',
                name:'accountTwo',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/indexNext.vue'),
                meta:{
                    code:'',
                    name:'更新管理员2'
                }
            },
            {
                path:'/index/attestation/account/updatePassword',
                name:'accountPassword',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/updatePassword.vue'),
                meta:{
                    code:'',
                    name:'更新密码'
                }
            },
            {
                path:'/index/attestation/account/updateManage',
                name:'updateManage',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/updateManage.vue'),
                meta:{
                    code:'',
                    name:'更换管理员'
                }
            },
            {
                path:'/index/attestation/account/accountCashOut',
                name:'accountCashOut',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/accountCashOut.vue'),
                meta:{
                    code:'',
                    name:'提现账户(个人)'
                }
            },
            {
                path:'/index/attestation/account/cashOutCompany',
                name:'cashOutCompany',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/attestation/account/cashOutCompany.vue'),
                meta:{
                    code:'',
                    name:'提现账户(企业)'
                }
            },
            {
                path:'/index/news/index',
                name:'news',
                component: () => import(/* webpackChunkName: "teacher" */ '../views/index/news/index.vue'),
                meta:{
                    code:'',
                    name:'消息'
                }
            },
            {
                path:'/index/backstage/auth',
                name:'auth',
                component: () => import(/* webpackChunkName: "auth" */ '../views/index/backstage/authManage/index.vue'),
                meta:{
                    code:'',
                    name:'权限管理'
                }
            },
            {
                path:'/index/backstage/account',
                name:'account',
                component: () => import(/* webpackChunkName: "account" */ '../views/index/backstage/accountManage/index.vue'),
                meta:{
                    code:'',
                    name:'后台账户管理'
                }
            },
            {
                path:'/index/backstage/role',
                name:'role',
                component: () => import(/* webpackChunkName: "role" */ '../views/index/backstage/roleManage/index.vue'),
                meta:{
                    code:'',
                    name:'角色管理'
                }
            },
            {
                path:'/index/backstage/role/auth',
                name:'role',
                component: () => import(/* webpackChunkName: "role-auth" */ '../views/index/backstage/roleManage/authCenter.vue'),
                meta:{
                    code:'',
                    name:'角色管理'
                }
            },
        ]
    }
]
export default dynamicRoutes;