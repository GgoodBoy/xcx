import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'
import dynamicRoutes from './routes'
// import utils from '../utils' 

const originalPush:any = VueRouter.prototype.push
VueRouter.prototype.push = function push(location:any) {
  return originalPush.call(this, location).catch((err: any) => err)
};
Vue.use(VueRouter)
const routes: Array<RouteConfig> = [
  {
    path:'/',
    redirect:'/index/home'
  },
  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../views/login/index.vue')
  },
  { path: '/404',
    name:'error',
    component: () => import(/* webpackChunkName: "error" */ '../views/error/index.vue')
  },
  { path: '*', redirect: '/404' },
]

const router = new VueRouter({
  mode: 'history',
  base: '/platform',
  routes:[...routes,...dynamicRoutes]
})
// router.beforeEach((to, from, next) => {
//   const path = to.redirectedFrom || to.path;
//   const whiteList = routes.map(item=>item.path)
//   // 白名单 放行
//   if(whiteList.includes(path)) return next()
//   if (!vuex.getters.roleRouter) return next({ path: '/login' });
//   if (!vuex.getters.isAddRoutes) {
//     console.log('path未注册,存在角色路由，立即注册尝试匹配');
//     router.addRoutes(vuex.getters.roleRouter);
//     vuex.dispatch('set_isAddRoutes', true);
//     next(path);
//   } else {
//     console.log('已注册过动态路由，尝试匹配');
//     next();
//   }
// });
// router.beforeEach((to, from, next) => {
//   const user = utils.getUser()
//   if(user){
//     if(to.path.includes('/index')){
//       next()
//     }else{
//       next('/')
//     }
//   }else{
//     if(to.path.includes('/index')){
//       next('/login')
//     }else{
//       next()
//     }
//   }
// })
export default router



