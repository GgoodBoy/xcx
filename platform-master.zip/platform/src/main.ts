import Vue from 'vue'
import App from './App.vue'
import router from './router'
import {
  Input,
  Button,
  Menu,
  Submenu,
  MenuItem,
  Dialog,
  Pagination,
  Radio,
  Checkbox,
  Select,
  Option,
  Table,
  TableColumn,
  DatePicker,
  Breadcrumb,
  BreadcrumbItem,
  Image,
  Loading,
  Message,
  Progress,
  Badge,
  Tooltip,
  Form,
  FormItem,
  Row,
  Col,
  Upload,
  Cascader,
  RadioGroup,
  MessageBox,
  Tree,
  Steps,
  Step
} from 'element-ui'
import AFTableColumn from 'af-table-column'
import store from './store'
import http from './api/axios'
import url from './api/serverConfig/index'
import utils from './utils' 
import './utils/directive'
import './assets/style/reset.scss'
import Directives from '@/utils/directives.ts'
import '@/assets/style/style.css'
Vue.config.productionTip = false

const components = [
  Button,
  Menu,
  Submenu,
  MenuItem,
  Table,
  TableColumn,
  Select,
  Option,
  DatePicker,
  Input,
  Pagination,
  Form,
  FormItem,
  Row,
  Col,
  Cascader,
  Upload,
  RadioGroup,
  Radio,
  AFTableColumn,
  Tooltip,
  Badge,
  Progress,
  Image,
  BreadcrumbItem,
  Breadcrumb,
  Checkbox,
  Dialog,
  Loading,
  Steps,
  Step,
  Directives,
  Tree
];
components.forEach((component) => {
  Vue.prototype.$ELEMENT = { size: 'small', zIndex: 10 };
  Vue.use(component)
});

Vue.prototype.$http = http;
Vue.prototype.$server = url;
Vue.prototype.$utils = utils;
Vue.prototype.$message = Message;
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$loading = Loading.service;

new Vue({
  router,
  store,
  render: (h: (arg0: any) => any) => h(App)
}).$mount('#app')
