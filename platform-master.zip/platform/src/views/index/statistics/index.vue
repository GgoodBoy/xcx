<template>
    <div class="statistics-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '' }">统计</el-breadcrumb-item>
        </el-breadcrumb>        
        <div class="search-area">
            <div class="keyword-box">
                <el-input style="width:208px;" v-model="input" placeholder="请输入订单号,支付宝账号或课程名称查询"></el-input>
            </div>
            <div class="select-box">
            <el-select v-model="mechanismId" placeholder="所属机构">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.mechanismName"
                :value="item.id">
                </el-option>
            </el-select>   
            </div>
            <el-button class="search-btn primary" icon="el-icon-search" @click="search">查询</el-button>         
        </div>
        <div class="table-container">
            <el-table
                :data="tableData"
                :loading='loading'
                header-row-class-name="table-header"
                border
                stripe
                style="width: 100%">
                <el-table-column
                    prop="sort"
                    label="序号"
                    align="center"
                    min-width="50">
                </el-table-column>
                <el-table-column
                    prop="title"
                    label="课程名称"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="playNum"
                    label="播放量"
                    min-width="180"
                    align="center"
                    sortable
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="orderNum"
                    label="订单量"
                    min-width="180"
                    align="center"
                    sortable
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="mechanismName"
                    label="所属机构"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>                            
                </el-table>   
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>                         
        </div>
    </div>
</template>
<script lang="ts">
// import common from '../common'
import { Component,Vue } from 'vue-property-decorator'
// const fn = new common()
@Component({
  name:'statistics'
})
export default class StatisticsComponent extends Vue {  
    pageNo:number = 1;
    pageSize:number=10; 
    pages = 1;
    input:string = '';
    mechanismId = '' ;
    loading:boolean=false;
    pageAtion={
        pageTotal:0,
        paginationPage:1
    };   
    options:any= [];
    tableData:any= [];
    isLastPage:boolean=false; 
    pageNoAddNum:number=1;
    sortType:number=1;
    updown:number=1;    
    created(){
        if(!this.isLastPage){
            this.getMechanismList(0);
        }        
        this.getOrderList(1);
    }       
    search(){
        this.getOrderList(1);
    }  
    //分页
    childPageValue(num:number){
        this.childPageValue(num);
    }
    async getMechanismList(n:number){
        try {
            if(n){
                this.pageNoAddNum = this.pageNoAddNum+n;
            }else{
                this.pageNoAddNum = 1;
            }            
            const query = {
                params:{
                    pageNo:this.pageNoAddNum,
                    pageSize:10
                }
            }                               
            const res = await this.$http.get(this.$server.getSearchMechanismList,query)
                if(res.code==200){
                    if(res.data.isLastPage){
                        this.isLastPage = true;
                    }
                    this.options = this.options.concat(res.data.list)                    
                }                   
        } catch (err) { 
            console.log(err);
        }        
    }    
    //获取表单数据
    async getOrderList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    title:this.input,
                    mechanismId:this.mechanismId,
                    sortType:this.sortType,
                    updown:this.updown
                }
            }                    
            this.loading = true; 
            const res = await this.$http.get(this.$server.getStatisticalList,query)
            if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pages = contentdate.pages;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
            }  
        }catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }
    setElementColor(name:string){
        const nameArry = ['actualTop','actualBot','timeTop','timeBot'];
        nameArry.forEach(element => {
            const dom = document.getElementsByClassName(element)[0] as HTMLImageElement;
            if(name==element){
                dom.style.color='#C30D23';
            }else{
                dom.style.color='#000';
            }
        });
    }    
    renderHeader1 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top timeTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                 
                                this.setElementColor('timeTop') 
                                this.getOrderList(1);                               
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom timeBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                 
                                this.setElementColor('timeBot');
                                this.getOrderList(1);                                    
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }
    renderHeader2 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top actualTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=1;                                 
                                this.setElementColor('actualTop')
                                this.getOrderList(1); 
                            }// 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom actualBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=2;                                 
                                this.setElementColor('actualBot')
                                this.getOrderList(1); 
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }   
}

</script>
<style lang="scss" scoped>
.search-area{
    font-size: 0;
    >div{
        display: inline-block;
        vertical-align: middle;
    }
    .select-box{
        margin:0 20px;
        /deep/ .el-input{
            width: 128px;
        }
    }
    .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
    }
}
.statistics-page{
    background: #fff;
}
.displayInline{
    display: inline-block;
}
.margin10{
    margin: 0 10px;
}
.block{
        text-align: center;
        padding: 40px 0 40px 0;
        background: #fff;
}
.table-container{
    margin-top:20px;
}
</style>
