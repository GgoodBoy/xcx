<template>
    <div class="company-cashout-page">
         <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/attestation/companyAttestation/companyCashout' }">认证</el-breadcrumb-item>
            <el-breadcrumb-item>提现设置</el-breadcrumb-item>
        </el-breadcrumb>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="58px" class="form-box">
            <el-form-item label="银行账号" prop="bankAccount">
                <el-input v-model="ruleForm.bankAccount" placeholder="请输入对公银行账户" show-word-limit maxlength="50"></el-input>
            </el-form-item>
            <el-form-item label="收款银行" prop="reeceivingBank">
                <el-input v-model="ruleForm.reeceivingBank" placeholder="请输入开户行名称" show-word-limit maxlength="50"></el-input>
            </el-form-item> 
            <el-form-item label="开户支行" prop="accountOpening">
                <el-input v-model="ruleForm.accountOpening" placeholder="请输入开户行所在地" show-word-limit maxlength="50"></el-input>
            </el-form-item>  
            <el-form-item label="发票类型" prop="invoiceType">
                <el-radio-group v-model="ruleForm.invoiceType">
                    <el-radio label="1">普通发票</el-radio>
                    <el-radio label="2">增值税专用发票</el-radio>
                </el-radio-group>
            </el-form-item>            
            <el-form-item label="税号" prop="taxNumber">
                <el-input v-model="ruleForm.taxNumber" show-word-limit maxlength="50"></el-input>
            </el-form-item>                                     
            <el-form-item>
                <el-button type="primary" v-btn-blur class="save-btn" @click="submitForm('ruleForm')">保存</el-button>
                <el-button plain v-btn-blur class="cancel-btn" @click="resetForm('ruleForm')">取消</el-button>
            </el-form-item>
        </el-form>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'login'
})
export default class MyComponent extends Vue {
        ruleForm:any= {
          bankAccount: '',
          reeceivingBank:'',
          accountOpening:'',
          invoiceType:'1',
          taxNumber:''
        };
        rules:any= {
          bankAccount: [
            { required: true, message: '请正确输入信息', trigger: 'blur' }
          ],
          reeceivingBank: [
            {  required: true, message: '请正确输入信息', trigger: 'blur' }
          ],
          accountOpening: [
            {  required: true, message: '请正确输入信息', trigger: 'blur' }
          ],
          invoiceType: [
            { required: true, message: '请选择活动资源', trigger: 'change' }
          ],
          taxNumber: [
            {  required: true,message: '请正确输入信息', trigger: 'blur' }
          ]
        };   
        submitForm(formName:string){
            const form:any = this.$refs[formName];
            form.validate((valid:boolean) => {
                if (valid) {                 
                    this.updataAuthentication();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });               
        }
        resetForm(title:string){
            console.log(title);
        }
        async updataAuthentication(){
            try {
                const params={
                    bankAccount:this.ruleForm.bankAccount,
                    reeceivingBank:this.ruleForm.reeceivingBank,
                    accountOpening:this.ruleForm.accountOpening,
                    invoiceType:this.ruleForm.invoiceType,
                    taxNumber:this.ruleForm.taxNumber
                }                                  
                const res = await this.$http.post(this.$server.addOrGwithdrawal,params)
                if(res.code==200){
                    this.$message.success('添加成功');
                    this.$router.push('/index/attestation/companyAttestation/cashOutstate');
                }                   
            } catch (err) {
                console.log(err);
            }            
        }        
}
</script>
<style lang="scss" scoped>
    .company-cashout-page{
        .form-box{
            background: #fff;
            border-radius: 6px;
            transition: all 0.3s;
            padding: 40px 27px;
            &:hover{
                box-shadow: 0 0 10px #dfdfdf;
            }
            /deep/ .el-form-item{
                .el-form-item__label{
                    position: relative;
                    padding: 0!important;
                    text-align: justify;
                    -moz-text-align-last: justify;
                    text-align-last: justify;
                    font-weight: bold;
                    &::before{
                        position: absolute;
                        left: -10px;
                        top:2px;
                    }
                }
                .el-form-item__content{
                    margin-left: 82px!important;
                    .el-input{
                        width: auto;
                        .el-input__inner{
                            background: #fcfcfc;
                            width: 442px;
                        }
                    }
                }
                .save-btn{
                    padding: 12px 65px;
                    margin-top:20px;
                }
                .cancel-btn{
                    padding: 12px 65px;
                    margin-left: 20px;
                    margin-top:20px;
                }
            }
        }
    }
</style>
