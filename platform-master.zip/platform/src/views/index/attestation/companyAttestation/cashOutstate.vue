<template>
    <div class="cashout-page">
        <div class="cashoutBox">
            <div>银行帐号:</div>
            <div>{{data.bankAccount}}</div>
        </div>
        <div class="cashoutBox">
            <div>收款银行:</div>
            <div>{{data.reeceivingBank}}</div>
        </div>
        <div class="cashoutBox">
            <div>开户支行:</div>
            <div>{{data.accountOpening}}</div>                
        </div>
        <div class="cashoutBox">
            <div>发票类型:</div>
            <div>{{data.invoiceType==1?'普通发票':'增值税专用发票'}}</div>                
        </div>
        <div class="cashoutBox">
            <div>税号:</div>
            <div>{{data.taxNumber}}</div>                
        </div>
        <div style="text-align: center;">
            <el-button type="info" v-if="data.examineStatus!=1" @click="toExamineEven">提交审核</el-button>
            <el-button type="info" @click="upadteEven">修改</el-button>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'login'
})
export default class MyComponent extends Vue {
    id:number=-1;
    data:any={};
    upadteEven(){
       this.$router.push('/index/attestation/companyAttestation/companyCashout');
    }
    created(){
        this.getToExamineEven();
    }
    //getSubmitExamine
    async getToExamineEven(){
        try {      
            const query = {
                params:{
                    pageNo:1,
                    pageSize:10
                }
            }                                      
            const res = await this.$http.get(`${this.$server.getWithdrawalWithdrawal}`+1,query)
            if(res.code==200){
                this.data=res.data.detail[0];
                this.$message.success('添加成功');
            }                   
        } catch (err) {
            console.log(err);
        }      
    }
    async toExamineEven(){
        try {                                         
            const res = await this.$http.post(`${this.$server.getSubmitExamine}`+this.data.id)
            if(res.code==200){
                this.getToExamineEven();
            }                   
        } catch (err) {
            console.log(err);
        }      
    }    
}
</script>
<style lang="scss" scoped>
    .cashout-page{
        padding: 15px;
        .cashoutBox{
            overflow: hidden;
            margin-bottom: 20px;
            div{
                float: left;
                font-size: 14px;
            }
            div:nth-child(1){
                width: 120px;
            }
        }
    }
</style>
