<template>
    <div class="company-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/attestation/companyAttestation/index' }">认证</el-breadcrumb-item>
            <el-breadcrumb-item>机构认证</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="58px" class="demo-ruleForm">
                <div class="part-item">
                    <p class="title">机构信息</p>
                    <el-form-item label="机构名称" prop="mechanismName">
                        <el-input v-model="ruleForm.mechanismName" maxlength="50"></el-input>
                        <p class="num">{{ruleForm.mechanismName.length}}/50</p>
                    </el-form-item>
                    <el-form-item label="机构简介" prop="synopsis">
                        <el-input v-model="ruleForm.synopsis" maxlength="200" resize="none" type="textarea" :autosize="{ minRows: 9}"></el-input>
                        <p class="num">{{ruleForm.synopsis.length}}/200</p>
                    </el-form-item>     
                    <el-form-item label="联系人" prop="contacts">
                        <el-input v-model="ruleForm.contacts" ></el-input>
                    </el-form-item>       
                    <el-form-item label="联系方式" prop="tellphone">
                        <el-input v-model="ruleForm.tellphone" maxlength="11"></el-input>
                    </el-form-item> 
                </div>
                <div class="part-item">
                    <el-form-item label="营业执照注册号" prop="businessLicenseNo" class="normal">
                        <el-input v-model="ruleForm.businessLicenseNo"></el-input>
                    </el-form-item>
                    <el-form-item label="营业执照"
                                    prop="businessLicenseImg" class="upload-form-item">
                        <!-- surfacePlot -->
                        <div class="img-box">
                            <template v-if="ruleForm.businessLicenseImg">
                                <img :src="ruleForm.businessLicenseImg"/>
                            </template>
                        </div>
                        <p class="upload-btn" @click="uploadEvent">{{ruleForm.businessLicenseImg?'重新上传':'点击上传'}}</p>
                        <el-upload class="avatar-uploader"
                                    ref="uploadComp"
                                    :action="actiosAudio"
                                    :before-upload="(file)=>{return beforeUpload(file)}"
                                    :on-success="(file)=>{return uploadFileSuccess(file)}"
                                    :on-error="(file)=>{return uploadFileError()}" 
                                    :show-file-list="false">
                            <img v-if="ruleForm.businessLicenseImg"
                                    :src="ruleForm.businessLicenseImg"
                                    class="avatar">
                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            <div class="loadingStyle" style="position: absolute;top: 0;" v-loading="londStates"></div>
                        </el-upload>
                        <p class="form-tips">支持PNG、JPG格式，大小小于5M</p>
                    </el-form-item>  
                    <el-form-item>
                        <el-button class="submit-btn" type="primary" v-btn-blur @click="submitForm('ruleForm')">提交认证</el-button>
                        <el-button class="cancel-btn"  plain v-btn-blur @click="resetForm('ruleForm')">取消</el-button>
                    </el-form-item>              
                </div>
            </el-form>  
        </div>    
        <div class="dialog-box" v-if="dialogVisible">
            <div class="dialog-content">
                <span>是否立即保存当前修改</span>
                <div style="margin-top:30px">
                    <el-button type="primary" @click="dialogVisibleEven(true)">确 定</el-button>
                    <el-button @click="dialogVisibleEven(false)">取 消</el-button>                
                </div>                
            </div>
        </div>                 
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import companyImg from '@/assets/image/1.jpg'
@Component({
  name:'company'
})
export default class CompanyComponent extends Vue {
  companyImg:any=companyImg;
        ruleForm:any= {
            id:'',
            mechanismName: '',
            synopsis:'',
            contacts:'',
            tellphone:'',
            businessLicenseNo:'',
            businessLicenseImg:''
        };
        londStates:boolean=false;
        dialogVisible:boolean=false;
        rules:any= {
            mechanismName: [
                { required: true, min: 1, max: 50,message: '请输入机构名称', trigger: 'blur' }
            ],
            synopsis: [
                { required: true, min: 1, max: 200,message: '请输入机构简介', trigger: 'blur' }
            ],
            contacts: [
                { required: true, min: 1, message: '请填写联系人', trigger: 'blur' }
            ],
            tellphone: [
                { required: true, min: 1,message: '请正填写联系方式', trigger: 'blur' }
            ],
            businessLicenseImg: [
                { required: true, min: 1, message: '请输入营业执照注册号', trigger: 'blur' }
            ],
            businessLicenseNo: [
                {
                    required: true,
                    message: '请上传营业执照',
                    trigger: 'change'
                }
            ]         
        }; 
        get actiosAudio(){
            return  'http://172.16.120.6:8750'+this.$server.setUploadPic;
        }
        commonHeader:any ={};
        created(){
            this.getMechanismInfo();
        } 
        dialogVisibleEven(type:boolean){
            if(type){
                this.updataAuthentication();
            }else{
                this.dialogVisible = false;
                this.$router.push('/index/attestation/companyAttestation/index');
            }
        }
        submitForm(formName:string){
            const form:any = this.$refs[formName];
            form.validate((valid:boolean) => {
                if (valid) {                 
                    this.updataAuthentication();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });               
        }        
        async updataAuthentication(){
               try {
                    const params={
                        id:this.ruleForm.id,
                        mechanismName:this.ruleForm.mechanismName,
                        synopsis:this.ruleForm.synopsis,
                        contacts:this.ruleForm.contacts,
                        tellphone:this.ruleForm.tellphone,
                        businessLicenseNo:this.ruleForm.businessLicenseNo,
                        businessLicenseImg:this.ruleForm.businessLicenseImg
                    }                                  
                    const res = await this.$http.post(this.$server.updateOrgMechanism,params)
                    if(res.code==200){
                        if(this.dialogVisible){
                            this.dialogVisible = false;
                        }
                        this.$message.success('修改成功');
                        this.$router.push('/index/attestation/companyAttestation/index');
                    }                   
                } catch (err) {
                    console.log(err);
                }
        }        
        async getMechanismInfo(){
                try {                
                    const res = await this.$http.get(`${this.$server.getMechanismDetail}`+1)
                    if(res.code==200){
                        if(res.data.detail){
                            const mechanismData = res.data.detail;
                            this.ruleForm= {
                                id:mechanismData.id,
                                mechanismName:mechanismData.mechanismName,
                                synopsis:mechanismData.synopsis,
                                idCardImgFront:mechanismData.contacts,
                                idCardImgBack:mechanismData.tellphone,
                                holdIdCardImg:mechanismData.businessLicenseNo,
                                idCard:mechanismData.businessLicenseNo
                            }
                        }else{
                            this.$message.error('机构认证不存在');
                            setTimeout(()=>{
                                this.$router.go(-1)
                            },1000);
                        } 
                    }                   
                } catch (err) {
                    console.log(err);
                }      
        }                
        // 图片文件上传
        beforeUpload(file:any) {
            this.londStates = true;
            const isJPG = (file.type === 'image/png'||file.type ==='image/jpeg'||file.type ==='image/jpg')?true:false;
            const isLt2M = file.size / 1024 / 1024 < 5.001;
            if (!isJPG) {
                this.$message.error('上传图片只能是 JPG,PNG,JPEG 格式!');
            }
            if (!isLt2M) {
                this.$message.error('上传图片大小不能超过 5M!');
            }            
            return isJPG && isLt2M ;
        }
        uploadEvent(){
            const uploadComp:any= this.$refs.uploadComp;
            uploadComp.$el.querySelector('.el-upload').click()
        }
        //文件上传失败
        uploadFileError() {
                try {
                     this.londStates = false;
                    this.$message.error('上传错误');
                    return;
                } catch (e) {}
        }
        // 图片上传成功
        uploadFileSuccess( file:any) {
                this.londStates = false;
                this.ruleForm.businessLicenseImg = file.data.resourceUrl;
                const ruleForm:any = this.$refs['ruleForm'];
                this.$nextTick(()=>{
                    ruleForm.validateField('businessLicenseImg');
                    this.londStates = false;
                })
        }

}
</script>
<style lang="scss" scoped>
.company-page{
    .content{
        .part-item{
            padding: 34px 27px;
            background: #fff;
            margin-bottom: 20px;
            border-radius: 6px;
            transition: all 0.3s;
            &:hover{
                box-shadow: 0 0 10px #dfdfdf;
            }
        }
        /deep/ .el-form-item{
            margin:40px 0;
            &.normal{
                .el-form-item__label{
                    text-align: left;
                    text-align-last:auto;
                    line-height: 24px;
                }
            }
            .el-form-item__label{
                position: relative;
                padding: 0!important;
                text-align: justify;
                -moz-text-align-last: justify;
                text-align-last: justify;
                font-weight: bold;
                &::before{
                    position: absolute;
                    left: -7px;
                    top:2px;
                }
            }
            .el-form-item__content{
                margin-left: 82px!important;
            }
            .num{
                display: inline-block;
                vertical-align: middle;
                color:#666666;
                margin:0 20px 0 10px;
            }
            .el-input{
                width: auto;
                .el-input__inner{
                    background: #fcfcfc;
                    width: 442px;
                }
            }
            .el-textarea{
                width: auto;
                textarea{
                    background: #fcfcfc;
                    width: 442px;
                }
            }
            &.upload-form-item{
                .img-box{
                    width: 133px;
                    height: 190px;
                    position: relative;
                    overflow: hidden;
                    border:1px solid #e5e5e5;
                    border-radius: 6px;
                    display: inline-block;
                    img{
                        position: absolute;
                        width: 100%;
                        max-width: 100%;
                        top:50%;
                        left:50%;
                        transform: translate(-50%,-50%);
                        cursor: pointer;
                    }
                }
                .upload-btn{
                    display: inline-block;
                    vertical-align: bottom;
                    text-decoration: underline;
                    margin:0 0 3px 5px;
                    cursor: pointer;
                }
                .avatar-uploader{
                    position: absolute;
                    right: -1000px;
                    z-index: 1;
                    opacity: 0;
                }
                .form-tips{
                    color:#999;
                }
            }
            .submit-btn{
                padding: 12px 51px;
            }
            .cancel-btn{
                padding: 12px 65px;
                margin-left: 20px;
            }
        }
        .title{
            font-size: 16px;
            font-family: MicrosoftYaHei-Bold, MicrosoftYaHei;
            font-weight: bold;
            color: #C30D20;
            line-height: 21px;
        }
    }
}
</style>
