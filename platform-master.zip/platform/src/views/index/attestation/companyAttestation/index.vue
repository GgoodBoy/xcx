<template>
    <div class="company-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/attestation/companyAttestation/index' }">认证</el-breadcrumb-item>
            <el-breadcrumb-item>机构认证</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="company-box">
            <div class="child-box title">机构信息</div>
            <div class="child-box clearfix">
                <div class="child-title">机构名称</div>
                <div class="child-content">{{mechanismData.mechanismName}}</div>
                <div><i class="el-icon-upload"></i> 
                    <span v-if="mechanismData.authStatus==1">认证中</span>
                    <span v-else-if="mechanismData.authStatus==2">已认证</span>
                    <span v-else-if="mechanismData.authStatus==3">拒绝</span>
                    <span v-else>更新中</span>                
                </div>               
            </div>
            <div class="child-box clearfix">
                <div class="child-title">机构简介</div>
                <div class="child-deatil">
                    {{mechanismData.synopsis}}
                </div>                
            </div>
            <div class="child-box clearfix">
                <div class="child-title">联系人</div>
                <div class="child-content">{{mechanismData.contacts}}</div>     
                                        
            </div>
            <div class="child-box clearfix">
                <div class="child-title">联系方式</div>
                <div class="child-content">{{mechanismData.tellphone}}</div>           
            </div>
        </div>
        <div class="company-box">
            <div class="child-box clearfix">
                <div class="child-title normal">营业执照注册号</div>
                <div class="child-content">{{mechanismData.businessLicenseNo}}</div>
            </div>
            <div class="child-box clearfix">
                <div class="child-title">营业执照</div>
                <div class="child-img" @click="showFlag = true">
                    <img :src="mechanismData.businessLicenseImg?mechanismData.businessLicenseImg:companyImg"/>
                </div>
            </div> 
            <el-button class="edit-btn"  plain @click="updateCompanyEven">修改</el-button>           
        </div>
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import companyImg from '@/assets/image/1.jpg'
import previewImage from '@/components/PreviewImage.vue'
@Component({
  name:'company',
  components:{previewImage}
})
export default class CompanyComponent extends Vue {
  companyImg:any=companyImg;
  mechanismData:any = {};
  showFlag = false;
  srcList:any= []
  created(){
      this.getMechanismInfo();
  } 
  async getMechanismInfo(){
        try {                
            const res = await this.$http.get(`${this.$server.getMechanismDetail}`+1)
               if(res.code==200){
                   if(res.data.detail){
                       this.mechanismData = res.data.detail;
                       this.srcList = [res.data.detail.businessLicenseImg]
                   }else{
                       this.$message.error('机构认证不存在');
                       setTimeout(()=>{
                           this.$router.go(-1)
                       },1000);
                       
                   } 
               }                   
        } catch (err) {
            console.log(err);
        }      
  }   
  updateCompanyEven(){
       this.$router.push('/index/attestation/companyAttestation/updateAttestation')
  }
}
</script>
<style lang="scss" scoped>
.company-page{
    .company-box{
        padding: 34px 27px;
        background: #fff;
        margin-bottom: 20px;
        border-radius: 6px;
        transition: all 0.3s;
        &:hover{
            box-shadow: 0 0 10px #dfdfdf;
        }
        .title{
            font-size: 16px;
            font-family: MicrosoftYaHei-Bold, MicrosoftYaHei;
            font-weight: bold;
            color: #C30D20;
            line-height: 21px;
        }
        .child-box{
            font-size: 14px;
            margin-bottom: 50px;
            .child-title{
                width: 58px;
                margin-right: 34px;
                position: relative;
                text-align: justify;
                -moz-text-align-last: justify;
                text-align-last: justify;
                font-weight: bold;
                &.normal{
                    text-align: left;
                    text-align-last:auto;
                }
                &::before{
                    content:'*';
                    position: absolute;
                    top:2px;
                    left: -10px;
                    color:#C30D20;
                }
            }
            >div{
                float: left;
            }
            .child-deatil{
                width: 412px;
                color: #333;
            }
            .child-content{
                color: #333;
                margin-right: 20px;
            }   
            .child-img{
                width: 133px;
                height: 190px;
                position: relative;
                overflow: hidden;
                border:1px solid #e5e5e5;
                border-radius: 6px;
                img{
                    position: absolute;
                    width: 100%;
                    max-width: 100%;
                    top:50%;
                    left:50%;
                    transform: translate(-50%,-50%);
                    cursor: pointer;
                }
            }   
        }
        /deep/ .edit-btn{
                padding: 12px 65px;
                margin-left: 92px;
            }      
    }
}
</style>
