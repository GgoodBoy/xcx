<template>
    <div class="company-page" v-loading="loading">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/attestation/adminIsTrators' }">认证</el-breadcrumb-item>
            <el-breadcrumb-item>机构认证</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="part-item">
                <p class="part-title">机构信息</p>
                <div class="child-box clearfix">
                    <div class="child-title">机构名称</div>
                    <div class="child-content">{{mechanismData.mechanismName}}</div>
                    <div> 
                        <span v-if="mechanismData.authStatus==1">认证中</span>
                        <span v-else-if="mechanismData.authStatus==2">已认证</span>
                        <span v-else-if="mechanismData.authStatus==3">拒绝</span>
                        <span v-else>更新中</span>                
                    </div>               
                </div>
                <div class="child-box clearfix">
                    <div class="child-title">机构简介</div>
                    <div class="child-deatil">
                        {{mechanismData.synopsis}}
                    </div>                
                </div>
                <div class="child-box clearfix">
                    <div class="child-title">联系人</div>
                    <div class="child-content">{{mechanismData.contacts}}</div>              
                </div>
                <div class="child-box clearfix">
                    <div class="child-title">联系方式</div>
                    <div class="child-content">{{mechanismData.tellphone}}</div>
                </div>
            </div>
            <div class="part-item">
                <div class="child-box clearfix">
                    <div class="child-title">营业执照注册号</div>
                    <div class="child-content">{{mechanismData.businessLicenseNo}}</div>
                </div>
                <div class="child-box clearfix">
                    <div class="child-title">营业执照</div>
                    <div class="child-img">
                        <div class="block"  @click="previewImageEvent(mechanismData.businessLicenseImg)">
                            <img :src="mechanismData.businessLicenseImg"/>
                        </div>
                    </div>
                </div>            
            </div>
        </div>  
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>         
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import previewImage from '@/components/PreviewImage.vue'
@Component({
  name:'company',
  components:{previewImage}
})
export default class CompanyComponent extends Vue {
  mechanismData:any = {};
  refuseInfo:string='';
  toExamine:number=1;
  iduser:any={}
  showFlag = false;
  srcList:any = []
  loading = false;
  created(){
      this.iduser= this.$route.query; 
      this.getMechanismInfo(this.iduser);
  } 
  async getMechanismInfo(iduser:any){
      this.loading = true;
        try {                
            const res = await this.$http.get(`${this.$server.getMechanismInfo}`+iduser.id)
            this.loading = false;
               if(res.code==200){
                   this.mechanismData = res.data;
               }else{
                //    this.$message.error('机构认证不存在'); 
               }                
        } catch (err) {
            console.log(err);
        }      
  }
    previewImageEvent(url:string){
        this.showFlag = true;
        this.srcList = [url]
    }  
}
 
</script>
<style lang="scss" scoped>
.company-page{
    padding: 0!important;
    .current-account{
        background: url('../../../../assets/image/withcash_bgd.png')no-repeat 50% 50% / cover;
        height: 63px;
        line-height: 63px;
        border-radius: 6px;
        padding: 0 27px;
        font-size: 0;
        margin-bottom: 20px;
        label,p{
            display: inline-block;
            vertical-align: middle;
            font-size: 16px;
            color:#333;
            font-weight: bold;
        }
        p{
            margin-left: 30px;
        }
    }
    .content{
        .part-item{
            background: #fff;
            border-radius: 6px;
            padding: 30px 27px;
            margin-bottom:20px;
            .part-title{
                color:#C30D20;
                font-size: 16px;
                font-weight: bold;
                line-height: 21px;
            }
            .child-box{
                margin:50px 0;
                >div{
                    float: left;
                }
                .status{
                    color:#C30D20;
                    margin-left: 40px;
                    font-weight: bold;
                }
                .child-title{
                    width: 60px;
                    position: relative;
                    padding-left:4px;
                    font-weight: bold;
                    &::before{
                        content:'*';
                        position: absolute;
                        left:-6px;
                        top:3px;
                        color:#C30D20;
                    }
                }
                .child-content,.child-deatil,.child-img{
                    margin-left: 36px;
                }
                .child-img{
                    .block{
                        width: 133px;
                        height: 190px;
                        background: #fcfcfc;
                        border-radius: 6px;
                        border:1px solid #e5e5e5;
                        overflow: hidden;
                        position: relative;
                        cursor: pointer;
                        img{
                            position: absolute;
                            top:50%;
                            left: 50%;
                            transform: translate(-50%,-50%);
                            width: 100%;
                            max-width: 100%;
                        }
                    }
                    .block+.block{
                        margin-top:30px;
                    }
                }
            }
            .el-textarea{
                margin:20px 0 0 0;
            }
            .el-button{
                margin-top:30px;
                padding: 12px 63px;
            }
        }
    }    
}
</style>
