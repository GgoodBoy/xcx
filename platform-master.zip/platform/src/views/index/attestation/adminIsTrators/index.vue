<template>
    <div class="news-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/attestation/adminIsTrators' }">认证管理</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="search-area">
                <div class="keyword-box">
                <el-input v-model="mechanismName" placeholder="联系人或者管理员账号"></el-input>
                </div>
                <div class="select-box">
                <el-select 
                    v-model="authStatus" 
                    placeholder="认证" 
                    >
                        <el-option
                        v-for="item in options1"
                        :key="item.value"
                        :label="item.lable"
                        :value="item.value">
                        </el-option>
                </el-select> 
                </div> 
                <div class="select-box">
                <el-select 
                    v-model="status" 
                    placeholder="状态" 
                    >
                        <el-option
                        v-for="item in options2"
                        :key="item.value"
                        :label="item.lable"
                        :value="item.value">
                        </el-option>
                </el-select>     
                </div>                          
                <el-button class="search-btn primary" v-btn-blur @click="search"><i class="el-icon-search"></i>查询</el-button>
            </div>
            <div class="table-container scroll-table">
            <el-table
                :data="tableData"
                :loading='loading'
                stripe
                border
                header-row-class-name="table-header"
                style="width: 100%">
                <el-table-column
                    label="序号"
                    prop="sortId"
                    align="center"
                    min-width="50">                   
                </el-table-column>
                <el-table-column
                    label="名称"
                    prop="mechanismName"
                    min-width="150"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="关联帐号"
                    prop="tellphone"
                    min-width="150"
                    align="center">                    
                </el-table-column>    
                <el-table-column
                    label="类型"
                    min-width="80"
                    align="center"
                    show-overflow-tooltip>    
                            <template slot-scope="scope">
                               <span v-if="scope.row.type==1">机构</span> 
                               <span v-else>个人</span>                                             
                            </template>                                     
                </el-table-column>  
                <el-table-column
                    label="平台费"
                    prop="platformFee"
                    min-width="80"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="创建时间"
                    prop="createdAt"
                    min-width="180"
                    align="center"
                    sortable
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="最后登录"
                    prop="lastLoginAt"
                    min-width="180"
                    align="center"
                    sortable
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="认证"
                    min-width="80"
                    align="center"
                    show-overflow-tooltip>         
                            <template slot-scope="scope">
                               <span v-if="scope.row.authStatus==1">认证中</span> 
                               <span v-else-if="scope.row.authStatus==2">已认证</span>
                               <span v-else-if="scope.row.authStatus==3">拒绝</span>
                               <span v-else>更新中</span>                                             
                            </template>                                
                </el-table-column>  
                <el-table-column
                    label="操作"
                    min-width="200"
                    align="center"
                    show-overflow-tooltip>    
                            <template slot-scope="scope">
                                <el-button type="text" icon="el-icon-view" @click="approvalEven(scope.row)">查看</el-button> 
                                <el-button type="text" icon="el-icon-remove-outline" @click="enableOrDisable(scope.row,'eo')">{{scope.row.status==1?'禁用':'启用'}}</el-button> 
                                <el-button type="text" icon="el-icon-edit-outline" @click="enableOrDisable(scope.row,'m')">平台费</el-button>                                                
                            </template>                                    
                </el-table-column>                                                                    
                </el-table>
                </div>   
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>  

        </div>
        <div class="my-dialog" v-if="dialogVisible">
            <div class="dialogConten">
                <div class="listCss"> 
                    <span v-if="dialogType==1">是否禁用当前机构</span>
                    <span v-else-if="dialogType==2">是否启用当前机构</span>
                    <div v-else>
                        <p>设置平台费</p>
                        <el-input v-model="inputDialog" maxlength="2" @blur="inputDialogblur" placeholder="请输入内容"></el-input>
                    </div>                              
                </div>
                <div style="text-align:center" v-if="dialogType==3">
                    <el-button type="success" @click='save(2)'>保 存</el-button>
                </div>                
                <div style="text-align:center" v-else>
                    <el-button type="danger" @click='save(1)'>确 定</el-button>
                    <el-button type="info" @click='closeDialog'>取 消</el-button>
                </div>
            </div>
        </div>                
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'news'
})
export default class CashOutComponent extends Vue {
    tableData:any= [
        
    ];
    inputDialog:any=0;
    dialogVisible:boolean=false;
    pageNo:number=1;
    pageSize:number=10;
    pages = 1;
    loading:boolean=false;
    isActive:boolean = true;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    selectTableData:any={};
    dialogType:number=-1;
    mechanismName:string='';
    authStatus:string='';
    status:string='';
    sortType=1;
    updown=1;
    isFirster:boolean=true;
    //1启用，2禁用
    options1:object[]=[
        {
            lable:'启用',
            value:'1'
        },
        {
            lable:'禁用',
            value:'2'
        }       
    ];    
    //1认证中，2已认证，3拒绝 4更新中
    options2:object[]=[
        {
            lable:'认证中',
            value:'1'
        },
        {
            lable:'已认证',
            value:'2'
        },
        {
            lable:'拒绝',
            value:'3'
        },
        {
            lable:'更新中',
            value:'4'
        }        
    ];
    created(){
        this.getNewsList(1);
    } 
    approvalEven(data:any){
        if(data.type==1){
            switch (data.authStatus) {
                case 2:
                case 3:  
                    this.$router.push({path:'/index/attestation/adminIsTrators/adminCompanSuccess',query:{id:data.id}});
                    break;
                case 1: 
                case 4:
                    this.$router.push({path:'/index/attestation/adminIsTrators/companyToExamine',query:{id:data.id}}); 
                    break;
                default:
                    console.log('机构');
                    break;
            }
        }else{
            switch (data.authStatus) {
                case 2:
                case 3:  
                    this.$router.push({path:'/index/attestation/adminIsTrators/adminUserSuccess',query:{id:data.id}});
                    break;
                case 1: 
                case 4:
                    this.$router.push({path:'/index/attestation/adminIsTrators/userToExamine',query:{id:data.id}}); 
                    break;
                default:
                    console.log('个人');
                    break;
            }            
            
        }
    }
    setBody(type:string){
        const bodyStyle:any = document.querySelector('body');
        if(type=='h'){
            bodyStyle.setAttribute('style', 'overflow: hidden;');
        }else{
            bodyStyle.setAttribute('style', 'overflow: visibl;');
        }
    }
    enableOrDisable(data:any,type:string){
        if(type=='m'){
            this.dialogType=3;
        }else{
            if(data.status==1){
                this.dialogType=1;
            }else{
                this.dialogType=2;
            }
        }
        this.setBody('h');
        this.selectTableData = data;
        this.dialogVisible=true;
    }
    childPageValue(num:number){
        this.getNewsList(num)
    }
    addCashOut(){
        this.$router.push({path:'/index/attestation/userAttestation/setUpUserCashOut',query:{type:'add'}})
    }  
    save(type:number){
        this.setBody('i');
       if(type==1){
           //禁用启用认证管理
           this.setEnableOrDisable();
           this.dialogVisible=false;
       }else{
           this.setPlatformFeeMechanism();
           this.dialogVisible=false;
       } 
    }
    closeDialog(){
        this.setBody('i');
        this.dialogVisible=false;
    }
    inputDialogblur () {
        const reg = /^([0-9]|10)$/;
        if (!this.inputDialog.match(reg)) {
            this.inputDialog=0;
            return false;
        } else {
            return true;
        }
    }
    setElementColor(name:string){
        return;
        const nameArry = ['actualTop','actualBot','timeTop','timeBot'];
        nameArry.forEach(element => {
            const dom = document.getElementsByClassName(element)[0] as HTMLImageElement;
            if(name==element){
                dom.style.color='#C30D23';
            }else{
                dom.style.color='#000';
            }
        });
    }    
    renderHeader1 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top timeTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                
                                this.setElementColor('timeTop');
                                this.getNewsList(1);                                
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom timeBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                
                                this.setElementColor('timeBot'); 
                                this.getNewsList(1);                                 
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }
    renderHeader2 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top actualTop',
                        style: 'color:#000;position:absolute;left: 60px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=1;                                
                                this.setElementColor('actualTop'); 
                                this.getNewsList(1);
                            }// 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom actualBot',
                        style: 'color:#000;position:absolute;left: 60px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=2;                                   
                                this.setElementColor('actualBot'); 
                                this.getNewsList(1);
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }    
    search(){
        this.getNewsList(1);
    }
    //禁用启用
    async setEnableOrDisable(){
        try {                
            const res = await this.$http.post(this.$server.setEnabledMechanism+this.selectTableData.id)
            if(res.code==200){
                this.$message.success('操作成功');
                this.getNewsList(1);
            }                    
        } catch (err) {
            console.log(err);
        }        
    }
    //禁用启用
    async setPlatformFeeMechanism(){
        try {             
            const query = {
                platformFee:this.inputDialog
            }   
            const res = await this.$http.post(this.$server.setPlatformFeeMechanism+this.selectTableData.id,query)
            if(res.code==200){
                this.$message.success('操作成功');
                this.getNewsList(1);
            }                    
        } catch (err) {
            console.log(err);
        }        
    }    
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    mechanismName:this.mechanismName,
                    authStatus:this.authStatus,
                    status:this.status,
                    sortType:this.sortType,
                    updown:this.updown
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getMechanismInfoList,query)
               if(res.code==200){
                    this.tableData = res.data.list;
                    this.tableData.forEach((item:any,index:number)=>{
                        item.sortId = (this.pageNo-1)*this.pageSize+index+1;
                    })
                    this.pageAtion.pageTotal = res.data.total;
                    this.pageAtion.paginationPage = n;
                    this.pages = res.data.pages;
                    this.loading = false; 
                    if(this.isFirster){
                        this.$nextTick(()=>{
                            this.setElementColor('timeTop')
                        });
                        this.isFirster = false;
                    }                    
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }
}
</script>
<style lang="scss" scoped>
.news-page{
    background: #fff;
    .search-area{
      font-size: 0;
      >div{
        display: inline-block;
        vertical-align: middle;
      }
      .keyword-box{
        width: 208px;
      }
      .date-picker-box{
        margin:0 20px;
        >p{
          margin:0 10px;
        }
        >p,>div{
          display: inline-block;
          vertical-align: middle;
        }
        /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
          width: 100px;
        }
        /deep/ .el-input__inner{
          width: 100px;
          padding: 0;
          text-align: center;
        }
        /deep/ .el-input__prefix{
          display: none;
        }
      }
      .select-box{
        margin:0 20px;
        /deep/ .el-input{
          width: 128px;
        }
      }
      .select-box+.select-box{
          margin:0 20px 0 0;
      }
      .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
      }
      .add-btn{
        padding: 8px 13px;
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        color:#fff;
        margin-left: 102px;
      }
    }
    .table-container{
        margin-top:20px;
    }
    .my-dialog{
        position:fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        display: flex;
        flex-direction:column-reverse ;
        justify-content:center;
        align-items: center;
        background: rgba(0,0,0,0.2);
        z-index: 10;
        .dialogConten{
            padding: 20px;
            background: #fff;
            .listCss{
                min-width: 300px;
                text-align: center;
                padding: 20px 0;
            }
        }
    }    
}
.active{
    font-weight: 700;
}
.marginR5{
    margin-right: 5px;
}
</style>
