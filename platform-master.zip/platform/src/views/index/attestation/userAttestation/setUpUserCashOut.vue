<template>
    <div class="company-page">
        <div>机构信息</div>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="银行卡号:" prop="bankAccount">
                <el-input v-model="ruleForm.bankAccount" show-word-limit maxlength="50" style="width:400px;"></el-input>
            </el-form-item>
            <el-form-item label="持卡人姓名:">
               {{userInfo.username||''}}
            </el-form-item>     
            <el-form-item label="开户银行:" prop="accountOpening">
                <el-input v-model="ruleForm.accountOpening" show-word-limit maxlength="50" style="width:400px;"></el-input>
            </el-form-item> 
            <el-form-item label="开户地区:" required>
                    <div style="display: inline-block;">     
                        <el-form-item prop="provinceId">
                            <el-select 
                            v-model="ruleForm.provinceId"
                            style="width: 100%;"
                            @change="getProvince(ruleForm.provinceId)"
                            >
                                <el-option
                                v-for="(item,i) in provinceList"
                                    :key="i"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>                
                        </el-form-item>
                    </div>   
                    <div class="line" style="display: inline-block;">-</div>
                    <div style="display: inline-block;">
                        <el-form-item prop="cityId">
                            <el-select
                                v-model="ruleForm.cityId"
                                style="width: 100%;">
                                <el-option
                                v-for="(item,i) in cityList"
                                    :key="i"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>
            </el-form-item>            
            <el-form-item>
                <el-button type="primary" @click="submitForm('ruleForm')">提交认证</el-button>
                <el-button @click="resetForm()">取消</el-button>
            </el-form-item>
        </el-form>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import companyImg from '@/assets/image/1.jpg'
import utils from '../../../../utils' 
@Component({
  name:'company'
})
export default class CompanyComponent extends Vue {
  companyImg:any=companyImg;
        ruleForm:any= {
            bankAccount: '',
            cardholder:'',
            accountOpening:'',
            provinceId:'',
            cityId:''
        };
        rules:any= {
            bankAccount: [
                { required: true, message: '请填银行卡号', trigger: 'blur' }
            ],
            accountOpening: [
                { required: true, message: '请填写开户银行', trigger: 'blur' }
            ],
            provinceId: [
                { required: true, message: '请选择省/直辖市', trigger: 'change' }
            ] ,           
            cityId: [
                { required: true, message: '请选择市/区', trigger: 'change' }
            ]            
        }; 
        commonHeader:any ={};
        value1='';
        value2='';
        provinceList:any=[{
                    label:'全部',
                    value:-1                    
                }];
        cityList:any=[{
                    label:'全部',
                    value:-1                    
                }];  
        provinceArr:any={};
        cityArr:any={};  
        userInfo:any={};    
        created(){
            this.userInfo= JSON.parse(utils.getUser());
            const iduser:any= this.$route.query;            
            this.getListRegionHttp();
            if(iduser.type=='edit'){
                this.getuserCashOutInfo(iduser.id)
            }
        }
        submitForm(formName:string){
            const form:any = this.$refs[formName];
            form.validate((valid:boolean) => {
                if (valid) {                 
                    this.updataAuthentication();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });               
        } 
        resetForm(){
            this.$router.push('/index/attestation/userAttestation/cashOut');
        }
        async updataAuthentication(){
            try {
                const params={
                    bankAccount:this.ruleForm.bankAccount,
                    cardholder:this.userInfo.username,
                    accountOpening:this.ruleForm.accountOpening,
                    provinceId:this.ruleForm.provinceId,
                    cityId:this.ruleForm.cityId
                }                                  
                const res = await this.$http.post(this.$server.addPersonalWithdrawal,params)
                if(res.code==200){
                    this.$message.success('添加成功');
                    this.$router.push('/index/attestation/userAttestation/cashOut');
                }                   
            } catch (err) {
                console.log(err);
            }            
        } 
        async getuserCashOutInfo(id:any){
            try {                                 
                const res = await this.$http.get(this.$server.addPersonalWithdrawal+id)
                if(res.code==200){
                    const data = res.data;
                    this.ruleForm= {
                        bankAccount:data.bankAccount,
                        cardholder:data.cardholder,
                        accountOpening:data.accountOpening,
                        provinceId:data.provinceId,
                        cityId:data.cityId
                    };
                }                   
            } catch (err) {
                console.log(err);
            }            
        }        
        async getListRegionHttp(){
            try {                                
                const res = await this.$http.get(this.$server.getListRegion)
                if(res.code==200){
                    const provinceArr:any = [];
                    const cityArr:any = [];
                    res.data.forEach((item:any)=>{
                        item.label = item.name;
                        item.value = item.id;
                        if(item.level==1){
                            provinceArr.push(item)
                        }else if(item.level==2){
                            cityArr.push(item)
                        }
                    })
                    this.provinceArr = provinceArr;
                    this.cityArr = cityArr;
                    this.provinceList = [...this.provinceArr];
                }                  
            } catch (err) {
                console.log(err);
            }            
        }
        getProvince(val:any){
            if(val){
                const obj = this.provinceArr.find((item:any)=>item.value==val)
                const cityList:any = []
                this.cityArr.forEach((item:any)=>{
                    if(item.parentId == obj.id){
                        cityList.push(item)
                    }
                })
                this.ruleForm.cityId='';
                this.cityList = cityList;
            }
        }               

}
</script>
<style lang="scss" scoped>
.company-page{
    .company-box{
        padding: 15px;
        background: #fff;
        margin-bottom: 10px;
        .child-box{
            overflow: hidden;
            font-size: 15px;
            margin-bottom: 20px;
            .child-title{
                width: 120px;
            }
            >div{
                float: left;
            }
            .child-deatil{
                width: calc(100% - 480px); 
                color: #999;
            }
            .child-content{
                color: #999;
                margin-right: 20px;
            }            
        }
    }   
}
</style>
<style>
    .avatar-uploader .el-upload {
        border: 1px dashed #fff;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409eff;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    } 
</style>

