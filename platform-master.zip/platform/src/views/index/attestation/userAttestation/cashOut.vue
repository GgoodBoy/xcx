<template>
    <div class="news-page">
        <div>
            <div style="text-align: right;margin-bottom:20px;">
                <el-button type="primary" @click="addCashOut">添加新账户</el-button>
            </div>
            <el-table
                :data="tableData"
                :loading='loading'
                :header-cell-style="{background:'#eef1f6',color:'#606266'}"
                border
                style="width: 100%">
                <el-table-column
                    label="序号"
                    prop="sortId"
                    align="center"
                    min-width="50">                   
                </el-table-column>
                <el-table-column
                    label="银行卡号"
                    prop="bankAccount"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="持卡人姓名"
                    prop="cardholder"
                    min-width="180"
                    align="center">                    
                </el-table-column>    
                <el-table-column
                    label="开户行"
                    prop="accountOpening"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="开户地区"
                    prop="areaName"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="状态"
                    prop="address"
                    min-width="60"
                    align="center"
                    show-overflow-tooltip> 
                            <template slot-scope="scope">
                               <span v-if="scope.row.examineStatus==1">审核中</span> 
                               <span v-else-if="scope.row.examineStatus==2">通过</span>
                               <span v-else>拒绝</span>                                             
                            </template>                                        
                </el-table-column>   
                <el-table-column
                    label="操作"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>    
                            <template slot-scope="scope">
                                <el-button type="text" icon="el-icon-edit-outline" @click="approvalEven(scope.row)">修改</el-button>                                                
                            </template>                                    
                </el-table-column>                                                                    
                </el-table>   
                <div class="block">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                </div>                         
        </div>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'news'
})
export default class CashOutComponent extends Vue {
    tableData:any= [];
    pageNo:number=1;
    pageSize:number=1;
    loading:boolean=false;
    isActive:boolean = true;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    created(){
        this.getNewsList(1);
    } 
    approvalEven(data:any){
        this.$router.push({path:'/index/attestation/userAttestation/setUpUserCashOut',query:{id:data.id,type:'edit'}});
    }
    childPageValue(num:number){
        this.getNewsList(num)
    }
    addCashOut(){
        this.$router.push({path:'/index/attestation/userAttestation/setUpUserCashOut',query:{type:'add'}})
    }  
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(`${this.$server.getWithdrawalWithdrawal}`+2,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data.detail;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }


}
</script>
<style lang="scss" scoped>
.news-page{
    .block{
            text-align: center;
            padding: 40px 0 40px 0;
            background: #fff;
    }
}
.active{
    font-weight: 700;
}
</style>
