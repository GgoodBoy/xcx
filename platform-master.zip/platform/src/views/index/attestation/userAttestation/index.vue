<template>
    <div class="company-page">
            <div class="child-box">
                <div class="child-title">真是姓名:</div>
                <div class="child-content">{{mechanismData.mechanismName}}</div>
                <div><i class="el-icon-upload"></i> 
                    <span v-if="mechanismData.authStatus==1">认证中</span>
                    <span v-else-if="mechanismData.authStatus==2">已认证</span>
                    <span v-else-if="mechanismData.authStatus==3">拒绝</span>
                    <span v-else>更新中</span>
                </div>               
            </div>
            <div class="child-box">
                <div class="child-title">个人简介:</div>
                <div class="child-deatil">
                    {{mechanismData.synopsis}}
                </div>                
            </div>
            <div class="child-box">
                <div class="child-title">身份证号:</div>
                <div class="child-deatil">
                    {{mechanismData.idCard}}
                </div>                
            </div>            
            <div class="child-box">
                <div class="child-title">身份证上传:</div>
                <div class="child-img">
                    <img style="display: block; margin-bottom:10px;" :src="mechanismData.idCardImgFront?mechanismData.idCardImgFront:companyImg" />
                    <img style="display: block; margin-bottom:10px;" :src="mechanismData.idCardImgBack?mechanismData.idCardImgBack:companyImg" />
                </div>
            </div> 
            <div class="child-box">
                <div class="child-title">手持身份证照片:</div>
                <div class="child-img">
                    <img :src="mechanismData.holdIdCardImg?mechanismData.holdIdCardImg:companyImg"/>
                </div>
            </div>           
        <div style="text-align: center; margin-bottom:20px;">
            <el-button style="padding:10px 30px;" type="info" @click="updateCompanyEven">修改</el-button>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import companyImg from '@/assets/image/1.jpg'
import companyImg1 from '@/assets/image/2.jpg'
@Component({
  name:'company'
})
export default class CompanyComponent extends Vue {
  companyImg:any=companyImg;
  companyImg1:any = companyImg1;
  mechanismData:any = {};
  created(){
      this.getMechanismInfo();
  }
  updateCompanyEven(){
       this.$router.push('/index/attestation/updateUserAttes/updateUserAttes')
  }
  async getMechanismInfo(){
        try {                
            const res = await this.$http.get(`${this.$server.getMechanismDetail}`+2)
               if(res.code==200){
                   if(res.data.detail){
                       this.mechanismData = res.data.detail;
                   }else{
                       this.$message.error('个人认证信息不存在');
                       setTimeout(()=>{
                           this.$router.go(-1)
                       },1000);
                   } 
               }                   
        } catch (err) {
            console.log(err);
        }      
  }
}
</script>
<style lang="scss" scoped>
.company-page{
    .child-box{
        overflow: hidden;
        font-size: 14px;
        margin-bottom: 20px;
        .child-title{
            width: 120px;
        }
        >div{
            float: left;
        }
        .child-deatil{
            width: calc(100% - 480px); 
            color: #999;
        }
        .child-content{
            color: #999;
            margin-right: 20px;
        }            
    }
    
}
</style>
