<template>
    <div class="user-page">
        <div>
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="130px" class="demo-ruleForm">            
                <el-form-item label="真是姓名:" prop="mechanismName">
                    <el-input v-model="ruleForm.mechanismName" style="width:400px;" maxlength="50" show-word-limit></el-input>
                </el-form-item>
                <el-form-item label="个人简介:" prop="synopsis">
                    <el-input v-model="ruleForm.synopsis" maxlength="200" show-word-limit style="width:400px;" type="textarea" :autosize="{ minRows: 4, maxRows: 6 }"></el-input>
                </el-form-item>
                <el-form-item label="身份证:" prop="idCard">
                    <el-input v-model="ruleForm.idCard" style="width:400px;"  maxlength="18" show-word-limit></el-input>
                </el-form-item>                                
                <el-form-item label="身份证上传:"
                                prop="idCardImgFront">
                    <p class="form-hint">支持PNG、JPG格式，大小小于5M</p>
                    <!-- :headers="commonHeader" -->
                    <el-upload class="avatar-uploader"
                                :action="actiosAudio"
                                :before-upload="(file)=>{return beforeUpload(file,'idCardImgFront')}"
                                :on-success="(file)=>{return uploadFileSuccess(file,'idCardImgFront')}"
                                :on-error="(file)=>{return uploadFileError(file,'idCardImgFront')}"                            
                                :show-file-list="false">
                        <img v-if="ruleForm.idCardImgFront"
                                :src="ruleForm.idCardImgFront"
                                class="avatar idCardStyle">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <div class="loadingStyle" style="position: absolute;top: 0;" v-loading="londList['idCardImgFront']"></div>
                    </el-upload>
                </el-form-item>
                <el-form-item label=":"
                                prop="idCardImgBack">
                    <p class="form-hint">支持PNG、JPG格式，大小小于5M</p>
                    <!-- :headers="commonHeader" -->
                    <el-upload class="avatar-uploader"
                                :action="actiosAudio"
                                :before-upload="(file)=>{return beforeUpload(file,'idCardImgBack')}"
                                :on-success="(file)=>{return uploadFileSuccess(file,'idCardImgBack')}"
                                :on-error="(file)=>{return uploadFileError(file,'idCardImgBack')}"                           
                                :show-file-list="false">
                        <img v-if="ruleForm.idCardImgBack"
                                :src="ruleForm.idCardImgBack"
                                class="avatar idCardStyle">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <div class="loadingStyle" style="position: absolute;top: 0;" v-loading="londList['idCardImgBack']"></div>
                    </el-upload>
                </el-form-item>   
                <el-form-item label="手持身份证照片:"
                                prop="holdIdCardImg">
                    <p class="form-hint">支持PNG、JPG格式，大小小于5M</p>
                    <el-upload class="avatar-uploader"
                                :action="actiosAudio"
                                :before-upload="(file)=>{return beforeUpload(file,'holdIdCardImg')}"
                                :show-file-list="false"
                                :on-error="(file)=>{return uploadFileError(file,'holdIdCardImg')}"
                                :on-success="(file)=>{return uploadFileSuccess(file,'holdIdCardImg')}">
                        <img v-if="ruleForm.holdIdCardImg"
                                :src="ruleForm.holdIdCardImg"
                                class="avatar idCardStyle">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <div class="loadingStyle" style="position: absolute;top: 0;" v-loading="londList['holdIdCardImg']"></div>
                    </el-upload>
                </el-form-item>                             
                <el-form-item>
                    <el-button type="primary" @click="submitForm('ruleForm')">提交认证</el-button>
                    <el-button @click="resetForm()">取消</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div class="dialog-box" v-if="dialogVisible">
            <div class="dialog-content">
                <span>是否立即保存当前修改</span>
                <div style="margin-top:30px">
                    <el-button type="primary" @click="dialogVisibleEven(true)">确 定</el-button>
                    <el-button @click="dialogVisibleEven(false)">取 消</el-button>                
                </div>                
            </div>
        </div>                              
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'userAttes'
})
export default class UserComponent extends Vue {
        commonHeader:any = {};
        ruleForm:any= {
          id:'',
          mechanismName: '',
          synopsis:'',
          idCardImgFront:'',
          idCardImgBack:'',
          holdIdCardImg:'',
          idCard:''
        };
        authenData:any={};
        londList:any={
            'idCardImgFront':false,
            'idCardImgBack':false,
            'holdIdCardImg':false,
        };
        dialogVisible:boolean=false;
        rules:any= {
            mechanismName: [
                { required: true, min: 1, max: 50,message: '请正确输入真实姓名', trigger: 'blur' }
            ],
            synopsis: [
                { required: true, min: 1, max: 200,message: '请正确输入个人简介', trigger: 'blur' }
            ],
            idCard: [
                { required: true, min: 18, max: 18,message: '请正确输入身份证号', trigger: 'blur' }
            ],            
            idCardImgFront: [
                {
                    required: true,
                    message: '请上传身份证头像面',
                    trigger: 'change'
                }
            ],            
            idCardImgBack: [
                {
                    required: true,
                    message: '请上传身份证国徽面',
                    trigger: 'change'
                }
            ],            
            holdIdCardImg: [
                {
                    required: true,
                    message: '请上传手持身份证照',
                    trigger: 'change'
                }
            ]
        }; 
        get actiosAudio(){
            return  'http://172.16.120.6:8750'+this.$server.setUploadPic;
        }  
        created(){
            // this.authenData = this.$route.query.data;
            this.getMechanismInfo();
        }     
        // 图片文件上传
        beforeUpload(file:any,type:string) {
            this.londList[type] = true;
            const isJPG = (file.type === 'image/png'||file.type ==='image/jpeg'||file.type ==='image/jpg')?true:false;
            const isLt2M = file.size / 1024 / 1024 < 5.001;
            if (!isJPG) {
                this.$message.error('上传头像图片只能是 JPG,PNG,JPEG 格式!');
            }
            if (!isLt2M) {
                this.$message.error('上传头像图片大小不能超过 5M!');
            } 
            return isJPG && isLt2M ;
        }
        resetForm(){
            this.dialogVisible = true;
        }
        dialogVisibleEven(type:boolean){
            if(type){
                this.updataAuthentication();
            }else{
                this.dialogVisible = false;
                this.$router.push('/index/attestation/userAttestation/index');
            }
        }
        async getMechanismInfo(){
                try {                
                    const res = await this.$http.get(`${this.$server.getMechanismDetail}`+2)
                    if(res.code==200){
                        const mechanismData = res.data.detail;
                        this.ruleForm= {
                            id:mechanismData.id,
                            mechanismName:mechanismData.mechanismName,
                            synopsis:mechanismData.synopsis,
                            idCardImgFront:mechanismData.idCardImgFront,
                            idCardImgBack:mechanismData.idCardImgBack,
                            holdIdCardImg:mechanismData.holdIdCardImg,
                            idCard:mechanismData.idCard
                        }                        
                    }                   
                } catch (err) {
                    console.log(err);
                }      
        }        
        async updataAuthentication(){
               try {
                    const params={
                        id:this.ruleForm.id,
                        mechanismName:this.ruleForm.mechanismName,
                        synopsis:this.ruleForm.synopsis,
                        idCard:this.ruleForm.idCard,
                        idCardImgFront:this.ruleForm.idCardImgFront,
                        idCardImgBack:this.ruleForm.idCardImgBack,
                        holdIdCardImg:this.ruleForm.holdIdCardImg
                    }                                  
                    const res = await this.$http.post(this.$server.updatePersonalMechanism,params)
                    if(res.code==200){
                        if(this.dialogVisible){
                            this.dialogVisible = false;
                        }
                        this.$message.success('修改成功');
                        this.$router.push('/index/attestation/userAttestation/index');
                    }                   
                } catch (err) {
                    console.log(err);
                }
        }
        submitForm(formName:string){
            const form:any = this.$refs[formName];
            form.validate((valid:boolean) => {
                if (valid) {                 
                    this.updataAuthentication();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });               
        }
        //文件上传失败
        uploadFileError(file:any,type:string) {
                try {
                    // const msg = JSON.parse(err.message).message;
                    this.londList[type] = false;
                    this.$message.error('上传失败');
                    return;
                } catch (e) {

                }
        }
        // 图片上传成功
        uploadFileSuccess(file:any,type:string) {
                if(file.code==200){
                    const ruleForm:any = this.$refs['ruleForm'];
                    switch (type) {
                        case 'idCardImgFront':
                            this.ruleForm.idCardImgFront = file.data.resourceUrl;
                            break;
                        case 'idCardImgBack':
                            this.ruleForm.idCardImgBack = file.data.resourceUrl;
                            break;
                        case 'holdIdCardImg':
                            this.ruleForm.holdIdCardImg = file.data.resourceUrl;
                            break;                                      
                        default:
                            break;
                    }
                    this.$nextTick(()=>{
                        ruleForm.validateField(type);
                         this.londList[type] = false;
                    })
                }
        }         
}
</script>
<style lang="scss" scoped>
.user-page{
    .dialog-box{
        background: rgba(0,0,0,0.5);
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction:column-reverse ;
        .dialog-content{
            max-width: 30%;
            text-align: center;
            background: #fff;
            border-radius: 10px;
            max-height: 200px;
            padding: 40px 60px;
        }
    }
}

</style>
<style>
    .avatar-uploader .el-upload {
        border: 1px dashed #fff;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409eff;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .loadingStyle{
        width: 178px;
        height: 178px;
    }    
    .idCardStyle{
        max-width: 400px;
    } 
</style>