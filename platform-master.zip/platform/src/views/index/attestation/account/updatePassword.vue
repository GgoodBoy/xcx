<template>
    <div class="password-page">      
        <div>
            <div>
                当前登录帐号 :  
                <span style="padding:0 30px;">
                    {{inputPhone}}
                </span>
                <span>
                    <el-button type="primary" icon="el-icon-search" @click="getSmsCodeEven">发送验证码</el-button>
                </span>                
            </div>
            <div style="margin:20px 0;">
                <div>
                    收到的验证码 : <el-input class="marginR5" style="width:300px;" v-model="inputCode" placeholder="6位验证码"></el-input>
                </div> 
                <div style="color:#C30D23;font-size:12px;padding: 0px 0px 0 110px;" v-if="inputCodeType">验证码错误</div>             
            </div> 
            <div style="overflow: hidden;">
                <div>
                    <div>
                        输入新的密码 :  <el-input class="marginR5" style="width:300px;" v-model="passwords" placeholder="6-18位密码，数字，字母，下划线组成"></el-input>
                    </div>
                    <div style="color:#C30D23;font-size:12px;padding: 0px 0px 0 110px;" v-if="passwordsType">
                        密码不能为空
                    </div>
                </div>              
            </div>
            <div style="text-align:center;margin-top:20px;">
                <el-button type="primary" @click="toExamineEven">保存</el-button>
            </div>                        
        </div>
        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
const Base64 = require('js-base64').Base64;
import utils from '../../../../utils'
@Component({
  name:'password'
})
export default class MyComponent extends Vue {
    inputCode:string = '';
    password:string='';
    cellphone:number=-1;
    passwords:string='';
    passwordsType:boolean=false;
    inputCodeType:boolean=false;
    inputPhone:string='';
    created(){
        const user:any|null = utils.getUser();
        if(user){
            this.inputPhone = JSON.parse(user).username;
        }
    }
    async getSmsCodeEven(){
        try {
            const query = {
                params:{
                    cellphone:this.cellphone,
                    tokenType:4,
                    msgType:2
                }
            }                                                    
            const res = await this.$http.get(this.$server.getSmsCodeCommon,query)
            if(res.code==200){
                this.$message.success('获取验证码成功');
            }                   
        } catch (err) {
            console.log(err);
        }         
    }
    async toExamineEven(){
        try {
            if(!this.passwords){
                this.passwordsType = true;
                return;
            }else{
                this.passwordsType = false;
            }
            if(!this.cellphone){
                this.inputCodeType = true;
                return;
            }else{
                this.inputCodeType = false;
            }       
            const params={
                code:this.inputCode,
                cellphone:this.cellphone,
                tokenType:4,
                password:Base64.encode(this.passwords)
            }                                          
            const res = await this.$http.post(this.$server.setResetPwd,params)
            if(res.code==200){
                this.$message.success('添加成功');
                // this.$router.push('/index/attestation/userAttestation/index');
            }                   
        } catch (err) {
            console.log(err);
        }      
    }
}
</script>
<style lang="scss" scoped>
.password-page{
    padding: 20px !important;
}
</style>
