<template>
    <div class="aco-page">
        <div>
            <div class="tabs">
                <div class="tab-pane" :class="tabsIndex==index?'active':''" v-for="(item,index) in tabsList" :key="index" @click="tabsChangeEven(item,index)">{{item.name}}</div>
            </div>            
            <el-table
                :data="tableData"
                :header-cell-style="{background:'#eef1f6',color:'#606266'}"
                border
                :loading='loading'
                style="width: 100%">
                <el-table-column
                    label="序号"
                    prop="sortId"
                    align="center"
                    min-width="50">                   
                </el-table-column>
                <el-table-column
                    label="银行卡号"
                    prop="bankAccount"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="持卡人姓名"
                    prop="cardholder"
                    min-width="180"
                    align="center">                    
                </el-table-column>    
                <el-table-column
                    label="开户行"
                    prop="accountOpening"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="开户地区"
                    prop="areaName"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="状态"
                    min-width="60"
                    align="center"
                    show-overflow-tooltip>  
                        <template slot-scope="scope">
                            <span v-if="scope.row.examineStatus==1">审核中</span>
                            <span v-if="scope.row.examineStatus==2">通过</span>                                      
                            <span v-if="scope.row.examineStatus==3">拒绝</span>
                        </template>                                       
                </el-table-column>   
                <el-table-column
                    label="操作"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>    
                    <template slot-scope="scope">
                        <div v-if="scope.row.examineStatus==1">
                            <el-button type="text" icon="el-icon-circle-check" @click="approvalEven(scope.row,'ok')">通过</el-button>   
                            <el-button type="text" icon="el-icon-circle-close" @click="approvalEven(scope.row,'no')">拒绝</el-button>                                        
                        </div> 
                    </template>                                    
                </el-table-column>                                                                    
                </el-table>   
                <div class="block">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                </div>                         
        </div>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'aco'
})
export default class AcoComponent extends Vue {
    tableData:any= [];

    tabsList:any = [
        {
            name:'个人提现账户审核',
            id:1,
            csstype:true,
            path:'/index/attestation/account/accountCashOut'
        },
        {
            name:'企业提现账户审核',
            id:2,
            csstype:false,
            path:'/index/attestation/account/cashOutCompany'                
        }
    ];  
    tabsIndex:number=0;      
    pageNo:number=1;
    pageSize:number=1;
    isActive:boolean = true;
    loading:boolean=false;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    created(){
        this.getNewsList(1);
    } 
    childPageValue(num:number){
        this.getNewsList(num)
    }
    tabsChangeEven(data:any,index:number){
        this.tabsIndex = index;
        if(index==1){
            this.$router.push(data.path)
        }else{
            this.$router.push(data.path)
        }       
    } 
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    page:this.pageNo,
                    pageSize:this.pageSize,
                    type:2
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getSettleOrderList,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }        
    }
    //获取表单数据
    async approvalEven(data:any,type:string){
        try {
            const query = {
                examineStatus:type=='yes'?1:2,
            }    
            this.loading = true;                 
            const res = await this.$http.post(this.$server.examineWithdrawal+data.id,query)
               if(res.code==200){
                   this.getNewsList(1);
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }        
    }
}
</script>
<style lang="scss" scoped>
.aco-page{
    .block{
            text-align: center;
            padding: 40px 0 40px 0;
            background: #fff;
    }
}
.active{
    font-weight: 700;
}
.tabs{
    margin-top: 10px;
    overflow:hidden;
    .tab-pane{
        float: left;
        height: 40px;
        line-height: 40px;
        text-align: center;
        width: 120px;
        margin-right: 10px;
        // background: rgba(0,0,0,0.2);
        border-radius: 6px 6px 0 0;
        border:1px solid #EBEEF5;
    }
}
.active{
    background: rgba(0,0,0,0.3);
    color:#fff;
}
</style>
