<template>
    <div class="account-page">
        <el-steps :active="1" simple>
            <el-step title="步骤 1" icon="el-icon-edit"></el-step>
            <el-step title="步骤 2" icon="el-icon-upload"></el-step>
        </el-steps>       
        <div class="content-box">
            <div>
                当前登录帐号 :  
                <span style="padding:0 30px;">
                    {{inputPhone}}
                </span>
                <span>
                    <el-button type="primary" icon="el-icon-search" @click="getSmsCodeEven">发送验证码</el-button>
                </span>                
            </div>
            <div style="margin:20px 0;">
                 
                <div>
                    收到的验证码 : <el-input class="marginR5" style="width:300px;" v-model="testInput" placeholder="6位验证码"></el-input>
                </div>    
                <div v-if="codeType" style="color:#C30D23;font-size:12px;padding: 0px 0px 0 110px;">验证码错误</div>          
            </div>   
            <div style="text-align:center;">
                <el-button type="primary" @click="goTo">下一步</el-button>
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import utils from '../../../../utils' 
@Component({
  name:'account'
})
export default class MyComponent extends Vue {
    inputPhone:string = '';
    testInput:string = '';  
    codeType:boolean=false;
    created(){
        const user:any|null = utils.getUser();
        if(user){
            this.inputPhone = JSON.parse(user).username;
        }
    }
    goTo(){
        // this.toExamineEven();
        this.$router.push('/index/attestation/account/indexNext')
    }
    //获取验证码
    async getSmsCodeEven(){
        try {
            const query = {
                params:{
                    cellphone:this.inputPhone,
                    tokenType:4,
                    msgType:1
                }
            }                                                    
            const res = await this.$http.get(this.$server.getSmsCodeCommon,query)
            if(res.code==200){
                this.$message.success('验证码已发送');
            }                   
        } catch (err) {
            console.log(err);
        }         
    }    
    async toExamineEven(){
        try {
            const params={
                code:this.testInput,
                cellphone:this.inputPhone,
                tokenType:4
            }                                  
            const res = await this.$http.post(this.$server.getVerifySmsCodeAccount,params)
            if(res.code==200){
                if(res.data==1){
                    this.codeType==false;
                    this.$message.success('添加成功');
                    this.$router.push('/index/attestation/account/indexNext')
                }else{
                    this.codeType==true;
                }
                // this.$router.push('/index/attestation/userAttestation/index');
            }                   
        } catch (err) {
            console.log(err);
        }      
    }  
}
</script>
<style lang="scss" scoped>
.account-page{
    padding: 0 !important;
    .content-box{
        padding: 40px 20px;
        background: #f2f2f2;
        margin-top: 5px;
    }
}
</style>
