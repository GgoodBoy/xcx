<template>
  <div class="accountList-page">
        <div>
            <el-table
                :data="tableData"
                :header-cell-style="{background:'#eef1f6',color:'#606266'}"
                border
                style="width: 100%">
                <el-table-column
                    prop="sort"
                    label="序号"
                    align="center"
                    min-width="50">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="订单号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="账号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="date"
                    label="课程名称"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="订单提交时间"
                    min-width="180"
                    align="center">
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="应付金额"
                    min-width="100"
                    align="center">
                </el-table-column>  
                <el-table-column
                    prop="date"
                    label="实付金额"
                    min-width="100"
                    align="center">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="所属机构"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>                            
                </el-table>   
                <div class="block">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                </div>                         
        </div>
  </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'accountList'
})
export default class MyComponent extends Vue {
    tableData:any= [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄',
            sort:1
        }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄',
            sort:2
        }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄',
            sort:3
        }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄',
            sort:4
        }];

    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };          
    //分页
    childPageValue(num:number){
        this.childPageValue(num);
    },          
}
</script>
<style lang="scss" scoped>

</style>
