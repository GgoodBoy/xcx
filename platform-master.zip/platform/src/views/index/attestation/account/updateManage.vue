<template>
    <div class="manage-page">
        <div>
            <el-table
                :data="tableData"
                :header-cell-style="{background:'#eef1f6',color:'#606266'}"
                border
                style="width: 100%">
                <el-table-column
                    label="序号"
                    prop="sort"
                    align="center"
                    min-width="50">                   
                </el-table-column>
                <el-table-column
                    label="银行卡"
                    prop="address"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="持卡人姓名"
                    prop="date"
                    min-width="180"
                    align="center">                    
                </el-table-column>    
                <el-table-column
                    label="开户行"
                    prop="address"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="开户地区"
                    prop="address"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="状态"
                    prop="address"
                    min-width="60"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>   
                <el-table-column
                    label="操作"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>    
                            <template slot-scope="scope">
                                <el-button type="text" icon="el-icon-edit-outline" @click="approvalEven(scope.row)">修改</el-button>                                                
                            </template>                                    
                </el-table-column>                                                                    
                </el-table>   
                <div class="block">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                </div>                         
        </div>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'updateManage'
})
export default class UpdateManageComponent extends Vue {
    tableData:any= [{
            id:1,
            date: '2016-05-02',
            address: '上海市普陀区金沙江路 1518 弄',
            sort:1,
            seeType:true
        }, {
            id:2,
            date: '2016-05-04',
            address: '上海市普陀区金沙江路 1517 弄',
            sort:2,
            seeType:true
        }, {
            id:3,
            date: '2016-05-01',
            address: '上海市普陀区金沙江路 1519 弄',
            sort:3,
            seeType:false
        }, {
            id:4,
            date: '2016-05-03',
            address: '上海市普陀区金沙江路 1516 弄',
            sort:4,
            seeType:false
    }];
    pageNo:number=1;
    pageSize:number=1;
    isActive:boolean = true;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    created(){
        this.getNewsList(1);
    } 
    approvalEven(data:any){
        this.$router.push('/attestation/setUpUserCashOut')
        console.log('data',data);
    }
    childPageValue(num:number){
        this.getNewsList(num)
    }
    //获取没有看过消息的id
    setTableId(list:any){
        const idArray:any = [];
        list.forEach((element:any) => {
            if(!element.seeType){
                idArray.push(element.id);
            }
            this.setFilterId(idArray);
        });
    }
    //保存表单没观看信息数据id
    async setFilterId(list:any){
        try {
            const query = {
                params:{
                    ids:list.toString()
                }
            }                    
            const res = await this.$http.get(this.$server.logout,query)
            if(res.code==200){
                // this.tableData = res;
                console.log('保存消息id成功');
            }                    
        } catch (err) {
            console.log(err);
        }
    }    
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    page:this.pageNo,
                    pageSize:this.pageSize
                }
            }                    
            const res = await this.$http.get(this.$server.textHttp1,query)
            if(res.code==200){
                // this.tableData = res;
                console.log('进来了');
                this.setTableId(res.content);
            }                    
        } catch (err) {
            console.log(err);
        }
    }


}
</script>
<style lang="scss" scoped>
.manage-page{
    .block{
            text-align: center;
            padding: 40px 0 40px 0;
            background: #fff;
    }
}
.active{
    font-weight: 700;
}
</style>
