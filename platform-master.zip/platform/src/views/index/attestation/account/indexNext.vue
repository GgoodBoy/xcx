<template>
    <div class="account2-page">
        <el-steps :active="2" simple>
            <el-step title="步骤 1" icon="el-icon-edit"></el-step>
            <el-step title="步骤 2" icon="el-icon-upload"></el-step>
        </el-steps>       
        <div class="content-box">
            <div style="overflow: hidden;">
                <div style="float: left;">
                    <div>
                        当前登录帐号 : <el-input class="marginR5" style="width:300px;" maxlength='11' @blur="validateTel(inputPhone)" v-model="inputPhone" placeholder="11位手机号码"></el-input>
                    </div>
                    <div style="color:#C30D23;font-size:12px;padding: 0px 0px 0 110px;">
                        手机号格式错误
                    </div>
                </div>
                <div  style="padding:0 30px;float: left;">
                    <el-button type="primary" icon="el-icon-search"  @click="getSmsCodeEven">发送验证码</el-button>
                </div>                
            </div>
            <div style="margin:20px 0;">
                <div>
                    收到的验证码 : <el-input class="marginR5" style="width:300px;" maxlength='6' v-model="testInput" placeholder="6位验证码"></el-input>
                </div> 
                <div style="color:#C30D23;font-size:12px;padding: 0px 0px 0 110px;">验证码错误</div>             
            </div>   
            <div style="text-align:center;">
                <el-button type="primary" @click="save">保存</el-button>
            </div> 
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'account2'
})
export default class MyComponent extends Vue {
        inputPhone:string = '';
        testInput:string = '';
        cancelEvev(){
            console.log('2');
        }
        save(){
                // this.toExamineEven();
                this.$message({
                    showClose: true,
                    message: '更换管理员帐号成功',
                    type: 'success'
                });      
        }
        validateTel(tel:any){
            const TEL_REGEXP = /^1([38]\d|5[0-35-9]|7[3678])\d{8}$/;
            if(TEL_REGEXP.test(tel)){
                console.log('1');
                return true;
            }
            console.log('2');
            return false;      
        }
        //获取验证码
        async getSmsCodeEven(){
            try {
                const query = {
                    params:{
                        cellphone:this.inputPhone,
                        tokenType:4,
                        msgType:1
                    }
                }                                                    
                const res = await this.$http.get(this.$server.getSmsCodeCommon,query)
                if(res.code==200){
                    this.$message.success('验证码已发送');
                }                   
            } catch (err) {
                console.log(err);
            }         
        }        
        async toExamineEven(){
            try {
                const params={
                    code:this.testInput,
                    cellphone:this.inputPhone,
                    tokenType:4,
                    mechanismId:''
                }                                  
                const res = await this.$http.post(this.$server.changeAccountaccount,params)
                if(res.code==200){
                    this.$message.success('更换管理员帐号成功');
                    // this.$router.push('/index/attestation/userAttestation/index');
                    // if(res.data==1){
                    //     this.codeType==false;
                    //     this.$message.success('添加成功');
                    //     this.$router.push('/index/attestation/account/indexNext')
                    // }else{
                    //     this.codeType==true;
                    // }                    
                }                   
            } catch (err) {
                console.log(err);
            }      
        }
}
</script>
<style lang="scss" scoped>
.account2-page{
    padding: 0 !important;
    .content-box{
        padding: 40px 20px;
        background: #f2f2f2;
        margin-top: 5px;
    }
}
</style>
