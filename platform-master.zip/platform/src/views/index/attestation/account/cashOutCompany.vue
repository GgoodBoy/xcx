<template>
    <div class="coc-page">
        <div>
            <div class="tabs">
                <div class="tab-pane" :class="tabsIndex==index?'active':''" v-for="(item,index) in tabsList" :key="index" @click="tabsChangeEven(item,index)">{{item.name}}</div>
            </div>             
            <el-table
                :data="tableData"
                :header-cell-style="{background:'#eef1f6',color:'#606266'}"
                border
                :loading="loading"
                style="width: 100%">                
                <el-table-column
                    label="序号"
                    prop="sort"
                    align="center"
                    min-width="50">                   
                </el-table-column>
                <el-table-column
                    label="银行卡号"
                    prop="bankAccount"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="公司名称"
                    prop="mechanismName"
                    min-width="180"
                    align="center">                    
                </el-table-column>    
                <el-table-column
                    label="关联帐号"
                    prop="cellphone"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>  
                <el-table-column
                    label="收款银行"
                    prop="reeceivingBank"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>
                <el-table-column
                    label="开户支行"
                    prop="accountOpening"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>    
                <el-table-column
                    label="发票"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>   
                        <template slot-scope="scope">
                            <span v-if="scope.row.invoiceType==1">普通发票</span>
                            <span v-if="scope.row.invoiceType==2">增值税专用发票</span>   
                        </template>                                      
                </el-table-column>    
                <el-table-column
                    label="税号"
                    prop="taxNumber"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>                    
                </el-table-column>                            
                <el-table-column
                    label="状态"
                    min-width="60"
                    align="center"
                    show-overflow-tooltip>   
                        <template slot-scope="scope">
                            <span v-if="scope.row.examineStatus==1">审核中</span>
                            <span v-if="scope.row.examineStatus==2">通过</span>                                      
                            <span v-if="scope.row.examineStatus==3">拒绝</span>
                        </template>                                      
                </el-table-column>   
                <el-table-column
                    label="操作"
                    min-width="250"
                    align="center"
                    show-overflow-tooltip>    
                        <template slot-scope="scope">
                            <div v-if="scope.row.examineStatus==1">
                                <el-button type="text" icon="el-icon-edit-outline" @click="approvalEven(scope.row,'yes')">通过</el-button>   
                                <el-button type="text" icon="el-icon-edit-outline" @click="approvalEven(scope.row,'no')">拒绝</el-button>                                        
                            </div>        
                        </template>                                    
                </el-table-column>                                                                    
                </el-table>   
                <div class="block">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                </div>                         
        </div>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'coc'
})
export default class CocComponent extends Vue {
    tableData:any= [{
            id:1,
            date: '2016-05-02',
            address: '上海市普陀区金沙江路 1518 弄',
            sort:1,
            seeType:true
        }, {
            id:2,
            date: '2016-05-04',
            address: '上海市普陀区金沙江路 1517 弄',
            sort:2,
            seeType:true
        }, {
            id:3,
            date: '2016-05-01',
            address: '上海市普陀区金沙江路 1519 弄',
            sort:3,
            seeType:false
        }, {
            id:4,
            date: '2016-05-03',
            address: '上海市普陀区金沙江路 1516 弄',
            sort:4,
            seeType:false
    }];
    tabsList:any = [
        {
            name:'待结算',
            id:1,
            csstype:true,
            path:'/index/attestation/account/accountCashOut'
        },
        {
            name:'结算完成',
            id:2,
            csstype:false,
            path:'/index/attestation/account/cashOutCompany'                
        }
    ];  
    tabsIndex:number=1;  
    pageNo:number=1;
    pageSize:number=1;
    isActive:boolean = true;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    loading:boolean=false;
    created(){
        this.getNewsList(1);
    } 
    childPageValue(num:number){
        this.getNewsList(num)
    }
    tabsChangeEven(data:any,index:number){
        this.tabsIndex = index;
        if(index==1){
            this.$router.push(data.path)
        }else{
            this.$router.push(data.path)
        }      
    }       
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    page:this.pageNo,
                    pageSize:this.pageSize,
                    type:1
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getSettleOrderList,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }        
    }
    //获取表单数据
    async approvalEven(data:any,type:string){
        try {
            const query = {
                examineStatus:type=='yes'?1:2,
            }    
            this.loading = true;                 
            const res = await this.$http.post(this.$server.examineWithdrawal+data.id,query)
               if(res.code==200){
                   this.getNewsList(1);
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }        
    }

}
</script>
<style lang="scss" scoped>
.coc-page{
    .block{
            text-align: center;
            padding: 40px 0 40px 0;
            background: #fff;
    }
}
.active{
    font-weight: 700;
}
.tabs{
    margin-top: 10px;
    overflow:hidden;
    .tab-pane{
        float: left;
        height: 40px;
        line-height: 40px;
        text-align: center;
        width: 120px;
        margin-right: 10px;
        // background: rgba(0,0,0,0.2);
        border-radius: 6px 6px 0 0;
        border:1px solid #EBEEF5;
    }
}
.active{
    background: rgba(0,0,0,0.3);
    color:#fff;
}
</style>
