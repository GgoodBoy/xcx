<template>
    <div class="order-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '' }">订单管理</el-breadcrumb-item>
        </el-breadcrumb>        
        <div class="search-area">
            <div class="keyword-box">
                <el-input style="width:208px;" v-model="searchContent" placeholder="请输入订单号,支付账号或课程名称查询"></el-input>
            </div>
            <div class="date-picker-box">
                <el-date-picker
                v-model="beginAt"
                @change="pickerBegin(beginAt)"
                type="date"
                placeholder="开始日期">
                </el-date-picker>
                <p>至</p>
                <el-date-picker
                v-model="endAt"
                @change="pickerEnd(endAt)"
                type="date"
                placeholder="截止日期">
                </el-date-picker>                    
            </div>
            <div class="select-box">
            <el-select 
                    v-model="mechanismId" 
                    placeholder="所属机构" 
                    v-loadmore="loadMore"
                    >
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.mechanismName"
                :value="item.id">
                </el-option>
            </el-select>   
            </div>
            <el-button class="search-btn primary" icon="el-icon-search" @click="search">查询</el-button>         
        </div>
        <div class="table-container scroll-table">
            <el-table
                :data="tableData"
                stripe
                :loading='loading'
                header-row-class-name="table-header"
                border
                style="width: 100%">
                <el-table-column
                    prop="sortId"
                    label="序号"
                    align="center"
                    min-width="60">
                </el-table-column>
                <el-table-column
                    prop="orderId"
                    label="订单号"
                    min-width="200"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="cellphone"
                    label="账号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="courseName"
                    label="课程名称"
                    min-width="220"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="createdAt"
                    label="订单提交时间"
                    min-width="180"
                    :render-header='renderHeader1'
                    align="center">
                </el-table-column>
                <el-table-column
                    label="应付金额"
                    min-width="100"
                    :render-header='renderHeader2'
                    align="center">
                        <template slot-scope="scope">
                            <span>{{scope.row.commodityPrice}}元</span>                                                    
                        </template>                     
                </el-table-column>  
                <el-table-column
                    label="实付金额"
                    min-width="100"
                    :render-header='renderHeader3'
                    align="center">
                        <template slot-scope="scope">
                            <span>{{scope.row.payPrice}}元</span>                                                    
                        </template>                        
                </el-table-column>
                <el-table-column
                    prop="mechanismName"
                    label="所属机构"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>                            
                </el-table>   
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>                         
        </div>
    </div>
</template>
<script lang="ts">
import common from '@/utils/common.ts'
import { Component,Vue } from 'vue-property-decorator'
const fn = new common()
declare const document: Document;
@Component({
  name:'order'
})
export default class OrderComponent extends Vue {  
    pageNo:number = 1;
    pageSize:number=10; 
    pages = 1;
    pageNoAddNum:number=1;
    input:string = '';
    searchContent:string='';
    mechanismId = '' ;
    loading:boolean=false;
    sortType:number=1;
    updown:number=1;
    beginAt ='';
    endAt='';
    isLastPage:boolean=false;
    pageAtion={
        pageTotal:0,
        paginationPage:1
    };   
    options:any= []
    tableData:any= [];
    isFirster:boolean = true;
    created(){
        if(!this.isLastPage){
            this.getMechanismList(1);
        }   
        this.getOrderList(1);
    }         
    //开始时间
    pickerBegin(val:string){
        const beginData = Number(val);
        const endData = Number(this.endAt);
        if(beginData>endData){
            this.endAt = '';
        }
    }
    //结束时间 
    pickerEnd(val:string){
        const endData = Number(val);
        const beginData = Number(this.beginAt);
        if(beginData>endData){
            this.endAt = '';
        }
    }
    //分页
    childPageValue(num:number){
        this.childPageValue(num);
    }
    search(){    
        this.getOrderList(1);           
    }  
    loadMore(){
        console.log('loadMore');
        this.getMechanismList(1);
    }
    async getMechanismList(n:number){
        try {
            if(n){
                this.pageNoAddNum = this.pageNoAddNum+n;
            }else{
                this.pageNoAddNum = 1;
            }            
            const query = {
                params:{
                    pageNo:this.pageNoAddNum,
                    pageSize:10
                }
            }                               
            const res = await this.$http.get(this.$server.getSearchMechanismList,query)
                if(res.code==200){
                    if(res.data.isLastPage){
                        this.isLastPage = true;
                    }
                    this.options = this.options.concat(res.data.list)                    
                }                   
        } catch (err) { 
            console.log(err);
        }        
    }
    //获取表单数据
    async getOrderList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    searchContent:this.searchContent,
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    beginAt:fn.formatDate(this.beginAt,'begin'),
                    endAt:fn.formatDate(this.endAt,'end'),
                    mechanismId:this.mechanismId,
                    sortType:this.sortType,
                    updown:this.updown
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getOrderListOrder,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
                    this.pages = contentdate.pages;
                    if(this.isFirster){
                        this.$nextTick(()=>{
                            this.setElementColor('timeTop')
                        });
                        this.isFirster = false;
                    }
               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }
    setElementColor(name:string){
        const nameArry = ['actualTop','actualBot','planTop','planBot','timeTop','timeBot'];
        nameArry.forEach(element => {
            const dom = document.getElementsByClassName(element)[0] as HTMLImageElement;
            if(name==element){
                dom.style.color='#C30D23';
            }else{
                dom.style.color='#000';
            }
        });
    }    
    renderHeader1 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top timeTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                
                                this.setElementColor('timeTop');
                                this.getOrderList(1);                                
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom timeBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                
                                this.setElementColor('timeBot'); 
                                this.getOrderList(1);                                 
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }
    renderHeader2 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top actualTop',
                        style: 'color:#000;position:absolute;left: 60px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=1;                                
                                this.setElementColor('actualTop'); 
                                this.getOrderList(1);
                            }// 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom actualBot',
                        style: 'color:#000;position:absolute;left: 60px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=2;                                   
                                this.setElementColor('actualBot'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }  
    renderHeader3 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top planTop',
                        style: 'color:#000;position:absolute;left: 60px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=3;
                                this.updown=1;                                 
                                this.setElementColor('planTop'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom planBot',
                        style: 'color:#000;position:absolute;left: 60px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=3;
                                this.updown=2;                                
                                this.setElementColor('planBot'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }      
}

</script>
<style lang="scss" scoped>
.order-page{
    background: #fff;
}
.search-area{
      font-size: 0;
      >div{
        display: inline-block;
        vertical-align: middle;
      }
      .keyword-box{
        width: 208px;
      }
      .date-picker-box{
        margin:0 20px;
        >p{
          margin:0 10px;
        }
        >p,>div{
          display: inline-block;
          vertical-align: middle;
        }
        /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
          width: 100px;
        }
        /deep/ .el-input__inner{
          width: 100px;
          padding: 0;
          text-align: center;
        }
        /deep/ .el-input__prefix{
          display: none;
        }
      }
      .select-box{
        margin:0 20px 0 0;
        /deep/ .el-input{
          width: 128px;
        }
      }
      .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
      }
    }
    .table-container{
        margin-top:20px;
    }
</style>
