<template>
  <div class="home-page">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">快捷操作</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="list">
      <div class="item" v-for="(item,index) in list" :key="index">
        <template v-show="item.src">
          <img :src="item.src" :style="item.style"/>
          <div v-if="item.badgeVal"  class="home-msg" :style="`{left:${item.style.left},top:${item.style.top}}`?item.style:'{}'">
            <el-badge  :value="item.badgeVal" :max="99"></el-badge>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import bgd1 from '@/assets/image/home_1.png'
import bgd2 from '@/assets/image/home_2.png'
import bgd3 from '@/assets/image/home_3.png'
import bgd4 from '@/assets/image/home_4.png'
import bgd5 from '@/assets/image/home_5.png'
import bgd6 from '@/assets/image/home_6.png'
import bgd7 from '@/assets/image/home_7.png'
import bgd9 from '@/assets/image/home_8.png'
import _bgd1 from '@/assets/image/home_manager_1.png'
import _bgd2 from '@/assets/image/home_manager_2.png'
import _bgd3 from '@/assets/image/home_manager_3.png'
import _bgd4 from '@/assets/image/home_manager_4.png'
import _bgd5 from '@/assets/image/home_manager_5.png'
import _bgd6 from '@/assets/image/home_manager_6.png'
import _bgd7 from '@/assets/image/home_manager_7.png'
import _bgd8 from '@/assets/image/home_manager_8.png'
import _bgd9 from '@/assets/image/home_manager_9.png'
@Component({
  name:'home'
})
export default class MyComponent extends Vue {
  list:any = []
  list1 = [
    {type:1,path:'/',src:bgd1,style:{height:'130px'}},
    {type:2,path:'/',src:bgd2,style:{height:'130px'}},
    {type:3,path:'/',src:bgd3,badgeVal:10,style:{height:'130px',left:'156px',top:'45px'}},
    {type:4,path:'/',src:bgd4,style:{height:'90px'}},
    {type:5,path:'/',src:bgd5,style:{height:'90px'}},
    {type:6,path:'/',src:bgd6,style:{height:'90px'}},
    {type:7,path:'/',src:bgd7,style:{height:'90px'}},
    {type:8,path:'/',src:null,style:{}},
    {type:9,path:'/',src:bgd9,badgeVal:100,style:{height:'90px',left:'176px',top:'25px'}},
  ]
  list2 = [
    {type:1,path:'/',src:_bgd1,badgeVal:99,style:{height:'130px',left:'200px',top:'45px'}},
    {type:2,path:'/',src:_bgd2,badgeVal:200,style:{height:'130px',left:'200px',top:'45px'}},
    {type:3,path:'/',src:_bgd3,badgeVal:10,style:{height:'130px',left:'156px',top:'45px'}},
    {type:4,path:'/',src:_bgd4,style:{height:'90px'}},
    {type:5,path:'/',src:_bgd5,style:{height:'90px'}},
    {type:6,path:'/',src:_bgd6,style:{height:'90px'}},
    {type:7,path:'/',src:_bgd7,style:{height:'90px'}},
    {type:8,path:'/',src:_bgd8,style:{height:'90px'}},
    {type:9,path:'/',src:_bgd9,badgeVal:10,style:{height:'90px',left:'200px',top:'25px'}},
  ]
  created(){
    this.getHomeData()
  }
  async getHomeData(){
    const query = {
      params:{

      }
    }
    const res = await this.$http.get(this.$server.home,query)
    if(res.code==200){
      this.list = [...this.list1];
    }
  }
}
</script>
<style lang="scss" scoped>
  .home-page{
    background: #fff;
    min-height: calc(100vh - 97px);
    .list{
      overflow: hidden;
      .item{
        float: left;
        min-height: 90px;
        margin-bottom: 20px;
        position: relative;
        .home-msg{
          position: absolute;
          /deep/ .el-badge__content{              
            background: linear-gradient(90deg, #D11229 0%, #FB6371 100%);
          }
        }
        &:nth-child(3n-1){
          margin:0 20px;
        }
        img{
          width: 286px;
          max-width: 100%;
          cursor: pointer;
        }
      }
    }
  }
</style>
