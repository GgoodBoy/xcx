<template>
    <div class="approval-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/settlement/approvalList' }">财务结算</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="search-area">
            <div class="keyword-box">
                <el-input v-model="settleOrderId" placeholder="请输入结算单号"></el-input>
            </div>
            <div class="select-box">
            <el-select 
                v-model="mechanismId" 
                placeholder="所属机构" 
                v-loadmore="loadMore"
                >
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.mechanismName"
                    :value="item.id">
                    </el-option>
            </el-select>   
            </div>
            <el-button class="search-btn primary" v-btn-blur icon="el-icon-search">查询</el-button>  
            <el-button class="export-btn" type="primary" v-btn-blur @click="headExport">导出</el-button>                  
        </div>
        <div class="table-container scroll-table">
            <el-table
                :data="tableData"
                :loading='loading'
                header-row-class-name="table-header"
                border
                stripe
                style="width: 100%">
                <el-table-column
                    prop="sort"
                    label="序号"
                    align="center"
                    min-width="50">
                </el-table-column>
                <el-table-column
                    prop="settleOrderId"
                    label="结算单号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="cellphone"
                    label="账号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="settlePrice"
                    label="结算金额"
                    min-width="180"
                    align="center"
                    :render-header='renderHeader1'
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="createdAt"
                    label="结算发起时间"
                    min-width="180"
                    align="center"
                    :render-header='renderHeader2'
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="mechanismName"
                    label="所属机构"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="操作"
                    min-width="180"
                    align="center">
                            <template slot-scope="scope">
                                 <el-button type="text" v-if="scope.row.settleStatus==1" @click="approvalEven(scope.row)">审批</el-button>  
                                 <el-button type="text" v-if="scope.row.settleStatus==2">已审批</el-button>                                                  
                                 <el-button type="text" v-if="scope.row.settleStatus==3">拒绝  </el-button>    
                            </template>                     
                </el-table-column>                             
                </el-table>   
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>                         
        </div>
    </div>
</template>
<script lang="ts">
// import common from '../common'
import { Component,Vue } from 'vue-property-decorator'
import utils from '../../../utils' 
// const fn = new common()
@Component({
  name:'order'
})
export default class OrderComponent extends Vue {  
    pageNo:number = 1;
    pageSize:number=10; 
    pages = 1;
    settleOrderId:string = '';
    mechanismId = '' ;
    pageNoAddNum:number=1;
    loading:boolean=false;
    pageAtion={
        pageTotal:0,
        paginationPage:1
    };   
    options:any= []
    tableData:any= [];
    isLastPage:boolean=false;
    sortType:number=1;
    updown:number=1;
    isFirster:boolean=true;
    created(){
        this.getOrderList(1);
    }         
    //分页
    childPageValue(num:number){
        this.childPageValue(num);
    }
    //审批
    approvalEven(data:any){
        this.$router.push({path:'/index/settlement/approvalInfo',query:{data:data}})
    }
    setElementColor(name:string){
        const nameArry = ['actualTop','actualBot','timeTop','timeBot'];
        nameArry.forEach(element => {
            const dom = document.getElementsByClassName(element)[0] as HTMLImageElement;
            if(name==element){
                dom.style.color='#C30D23';
            }else{
                dom.style.color='#000';
            }
        });
    }    
    //获取表单数据
    async getOrderList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    mechanismId:this.mechanismId,
                    // type:1,
                    sortType:this.sortType,
                    updown:this.updown,    
                    settleOrderId:this.settleOrderId            
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getSettleOrderList,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.pages = contentdate.page;
                    this.loading = false; 
                   if(this.isFirster){
                        this.$nextTick(()=>{
                            this.setElementColor('actualTop')
                        });
                        this.isFirster = false;
                    }

               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }             
    loadMore(){
        this.getMechanismList(1);
    }    
    async getMechanismList(n:number){
        try {
            if(n){
                this.pageNoAddNum = this.pageNoAddNum+n;
            }else{
                this.pageNoAddNum = 1;
            }            
            const query = {
                params:{
                    pageNo:this.pageNoAddNum,
                    pageSize:10
                }
            }                               
            const res = await this.$http.get(this.$server.getSearchMechanismList,query)
                if(res.code==200){
                    if(res.data.isLastPage){
                        this.isLastPage = true;
                    }
                    this.options = this.options.concat(res.data.list)                    
                }                   
        } catch (err) { 
            console.log(err);
        }        
    }    
    renderHeader1 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top actualTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                   
                                this.setElementColor('actualTop')
                                this.getOrderList(1);     
                            }// 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom actualBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                 
                                this.setElementColor('actualBot')
                                this.getOrderList(1);     
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }     
    renderHeader2 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top timeTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                
                                this.setElementColor('timeTop');
                                this.getOrderList(1);                                
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom timeBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                
                                this.setElementColor('timeBot'); 
                                this.getOrderList(1);                                 
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }    
    //导出
    download2(url:string) {
        try{ 
            const elemIF:any = document.createElement('iframe');   
            elemIF.src = url;   
            elemIF.style.display = 'none';   
            document.body.appendChild(elemIF);   
        }catch(e){ 
            this.$message.error('下载异常！');
        }
    }           
    //导出
    headExport(){
        const user:string = utils.getUser();
        const parems:object = {
            token:JSON.parse(user).token,
            settleOrderId:'',
            mechanismId:'',
            type:1,
        };
        this.download2(this.$server.schooleSchooleExport(parems)); 
    }       
}

</script>
<style lang="scss" scoped>
.approval-page{
    padding:0 20px;
    background: #fff;
}
.search-area{
    font-size: 0;
    >div{
    display: inline-block;
    vertical-align: middle;
    }
    .keyword-box{
    width: 208px;
    }
    .date-picker-box{
    margin:0 20px 0 0;
    >p{
        margin:0 10px;
    }
    >p,>div{
        display: inline-block;
        vertical-align: middle;
    }
    /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
        width: 100px;
    }
    /deep/ .el-input__inner{
        width: 100px;
        padding: 0;
        text-align: center;
    }
    /deep/ .el-input__prefix{
        display: none;
    }
    }
    .select-box{
    margin:0 20px;
    /deep/ .el-input{
        width: 120px;
    }
    }
    .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
    }
    .export-btn{
        display: inline-block;
        vertical-align: middle;
        margin-left: 364px;
        padding: 8px 35px;
    }
}
.table-container{
    margin-top:20px;
}
</style>
