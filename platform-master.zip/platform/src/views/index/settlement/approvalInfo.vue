<template>
    <div class="approvalInfo-page">
        <div>
            <h3>结算单号：{{data.settleOrderId}}</h3>
            <div class="info">结算金额：￥{{data.settlePrice}}</div>
            <div class="info">
                <div class="info-l">结算帐号:{{data.cellphone}}</div>
                <div>结算申请日期：{{data.createdAt}}</div>
            </div>
            <div class="info">
                <div class="info-l">银行帐号：{{data.bankAccount}}</div>
                <div>结算帐户名称：{{data.mechanismName}}</div>                
            </div>
        </div>
        <div style="text-align: center;">
            <el-button class="but" type="primary" @click="saveType(1)">同意</el-button>
            <el-button class="but" type="info" @click="saveType(2)">拒绝</el-button>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'login'
})
export default class MyComponent extends Vue {
    data:any={};
    created(){
        this.data = this.$route.query.data;
    }
    saveType(type:number){
           this.setExamineTle(type);
    }
    //保存表单没观看信息数据id
    async setExamineTle(type:number){
        try {
            const query = {
                id:this.data.id,
                type:type
            }                    
            const res = await this.$http.post(this.$server.setExamineTle,query)
            if(res.code==200){
                this.$router.push('/index/settlement/approvalList');
                console.log('保存消息id成功');
            }                    
        } catch (err) {
            console.log(err);
        }
    }    
}
</script>
<style lang="scss" scoped>
.approvalInfo-page{
    .but{
        margin: 0 15px;
    }
    .info{
        line-height: 60px;
        font-size: 14px;
        .info-l{
            width: 300px;
        }
        div{
            display: inline-block;
        }
    }
}
</style>
