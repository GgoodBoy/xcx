<template>
    <div class="settlement-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/settlement/indexTwo' }">结算</el-breadcrumb-item>
            <el-breadcrumb-item>结算完成</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="search-area">
            <div class="keyword-box">
                <el-input  v-model="settleOrderId" placeholder="请输入结算单号"></el-input>
            </div>    
            <div class="select-box">
            <el-select 
                v-model="timeType" 
                placeholder="选择时间类型"
                >
                    <el-option
                    v-for="item in options"
                    :key="item.id"
                    :label="item.label"
                    :value="item.id">
                    </el-option>
            </el-select>   
            </div>         
            <div class="date-picker-box">
                <el-date-picker
                v-model="begin"
                @change="pickerBegin(begin)"
                type="date"
                placeholder="开始日期">
                </el-date-picker>
                <p>至</p>
                <el-date-picker
                v-model="end"
                @change="pickerEnd(end)"
                type="date"
                placeholder="截止日期">
            </el-date-picker>                    
            </div>   
            <el-button class="search-btn primary" v-btn-blur @click="search" icon="el-icon-search">查询</el-button>         
        </div>
        <div class="moneyBox">
            <div class="moneyOne">
                <span>待结算</span>
                <span class="font-bold">￥{{settlePriceBegin}}</span>
                <p class="but" @click="goto" >提现</p>
            </div>
            <div class="moneyTwo">
                <span>已结算</span>
                <span class="font-bold">￥{{settlePriceEnd}}</span>                
            </div>
        </div>
        <div>
            <div class="tabs">
                <div class="tab-pane" :class="tabsIndex==index?'active':''" v-for="(item,index) in tabsList" :key="index" @click="tabsChangeEven(item,index)">{{item.name}}</div>
            </div> 
            <div class="table-container scroll-table">
                <el-table
                :data="tableData"
                :loading='loading'
                header-row-class-name="table-header"
                border
                stripe
                style="width: 100%">
                <el-table-column
                    prop="sort"
                    label="序号"
                    align="center"
                    min-width="50">
                </el-table-column>
                <el-table-column
                    prop="settleOrderId"
                    label="结算单号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="cellphone"
                    label="帐号"
                    min-width="180"
                    align="center"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="settlePrice"
                    label="结算金额"
                    min-width="100"
                    align="center"
                    :render-header='renderHeader1'
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="createdAt"
                    label="结算发起时间"
                    min-width="180"
                    :render-header='renderHeader2'
                    align="center">
                </el-table-column>
                <el-table-column
                    prop="updatedAt"
                    label="结算审批时间"
                    min-width="180"
                    :render-header='renderHeader3'
                    align="center">
                </el-table-column>                
                <el-table-column
                    label="状态"
                    min-width="80"
                    align="center">
                        <template slot-scope="scope">
                            <span v-if="scope.row.settleStatu==1">待结算</span>
                            <span v-else-if="scope.row.settleStatus==2">结算完成</span>
                            <span v-else>拒绝</span>                                                   
                        </template>                    
                </el-table-column>                  
                </el-table>   
            </div>    
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>                                      
        </div>
    </div>
</template>
<script lang="ts">
import common from '@/utils/common.ts'
import { Component,Vue } from 'vue-property-decorator'
const fn = new common()
@Component({
  name:'settlement'
})
export default class SettlementComponent extends Vue {  
    pageNo:number = 1;
    pageSize:number=10; 
    pages = 1;
    settleOrderId:string = '';
    timeType = '' ;
    begin ='';
    tabsIndex:number=1;
    pageAtion={
        pageTotal:0,
        paginationPage:1
    };   
    end='';
    sortType:number=1;
    updown:number=1;  
    loading:boolean=false;
    options:any= [
        {
            label:'结算发起时间',
            id:1
        },
        {
            label:'结算审批',
            id:2               
        }]
    tabsList:any = [
        {
            name:'待结算',
            id:1,
            csstype:true,
            path:''
        },
        {
            name:'结算完成',
            id:2,
            csstype:false,
            path:'/settlement2'                
        }
    ];       
    tableData:any= [];
    isFirster:boolean = true;
    settlePriceBegin='';
    settlePriceEnd='';
    created(){       
        this.getSettlePriceEven();
        this.getOrderList(1);
    }   
    tabsChangeEven(data:any,index:number){
        this.tabsIndex = index;
        if(index==1){
            this.$router.push('/index/settlement/indexTwo')
        }else{
            this.$router.push('/index/settlement/indexOne')
        }       
    }      
    //开始时间
    pickerBegin(val:string){
        const beginData = Number(val);
        const endData = Number(this.end);
        if(beginData>endData){
            this.end = '';
        }
    }
    //结束时间 
    pickerEnd(val:string){
        const endData = Number(val);
        const beginData = Number(this.begin);
        if(beginData>endData){
            this.end = '';
        }
    }
    //分页
    childPageValue(num:number){
        this.getOrderList(num);
    }    
    setElementColor(name:string){
        const nameArry = ['actualTop','actualBot','planTop','planBot','timeTop','timeBot'];
        nameArry.forEach(element => {
            const dom = document.getElementsByClassName(element)[0] as HTMLImageElement;
            if(name==element){
                dom.style.color='#C30D23';
            }else{
                dom.style.color='#000';
            }
        });
    }   
    renderHeader2 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top timeTop',
                        style: 'color:#000;position:absolute;left: 100px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=1;                                
                                this.setElementColor('timeTop');
                                this.getOrderList(1);                                
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom timeBot',
                        style: 'color:#000;position:absolute;left: 100px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=1;
                                this.updown=2;                                
                                this.setElementColor('timeBot'); 
                                this.getOrderList(1);                                 
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }
    renderHeader1 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top actualTop',
                        style: 'color:#000;position:absolute;left: 60px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=1;                                
                                this.setElementColor('actualTop'); 
                                this.getOrderList(1);
                            }// 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom actualBot',
                        style: 'color:#000;position:absolute;left: 60px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=2;
                                this.updown=2;                                   
                                this.setElementColor('actualBot'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }  
    renderHeader3 (h:any,{column}:any) {
        return h(
            'div',{
                style:'display:flex;margin:auto;'
            },
            [
                h('span', column.label,''),
                [
                    h('i', {
                        class: 'el-icon-caret-top planTop',
                        style: 'color:#000;position:absolute;left: 60px;top: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=3;
                                this.updown=1;                                 
                                this.setElementColor('planTop'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }
                    }),                    
                    h('i', {
                        class: 'el-icon-caret-bottom planBot',
                        style: 'color:#000;position:absolute;left: 60px;bottom: 0;cursor: pointer;', 
                        on:{
                            click:()=>{
                                this.sortType=3;
                                this.updown=2;                                
                                this.setElementColor('planBot'); 
                                this.getOrderList(1);
                            } // 选中事件 
                        }             
                    })                      
                ]

            ]
        )
    }      
    //保存表单没观看信息数据id
    async getSettlePriceEven(){
        try {                   
            const res = await this.$http.get(this.$server.getSettlePriceSettle)
            if(res.code==200){
                this.settlePriceBegin=res.data.settlePriceBegin;
                this.settlePriceEnd=res.data.settlePriceEnd;
            }                    
        } catch (err) {
            console.log(err);
        }
    }     
    goto(){
        this.$router.push('/index/settlement/creatApproval')
    }    
    search(){
        this.getOrderList(1);
    }
    //获取表单数据
    async getOrderList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    beginAt:fn.formatDate(this.begin,'begin'),
                    endAt:fn.formatDate(this.end,'end'),
                    timeType:this.timeType,
                    settleOrderId:this.settleOrderId,
                    type:2,
                    sortType:this.sortType,
                    updown:this.updown         
                }
            }    
            this.loading = true;                 
            const res = await this.$http.get(this.$server.getSettleOrderList,query)
               if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pageAtion.paginationPage = n;
                    this.pages = contentdate.pages;
                    this.loading = false; 
                   if(this.isFirster){
                        this.$nextTick(()=>{
                            this.setElementColor('actualTop')
                        });
                        this.isFirster = false;
                    }

               }                   
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }             
}

</script>
<style lang="scss" scoped>
.search-area{
    font-size: 0;
    >div{
    display: inline-block;
    vertical-align: middle;
    }
    .keyword-box{
    width: 208px;
    }
    .date-picker-box{
    margin:0 20px 0 0;
    >p{
        margin:0 10px;
    }
    >p,>div{
        display: inline-block;
        vertical-align: middle;
    }
    /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
        width: 100px;
    }
    /deep/ .el-input__inner{
        width: 100px;
        padding: 0;
        text-align: center;
    }
    /deep/ .el-input__prefix{
        display: none;
    }
    }
    .select-box{
    margin:0 20px;
    /deep/ .el-input{
        width: 128px;
    }
    }
    .search-btn{
    padding: 8px 9px;
    display: inline-block;
    vertical-align: middle;
    color:#666;
    font-size: 14px;
    }
}
.tabs{
    overflow:hidden;
    .tab-pane{
        float: left;
        height: 32px;
        line-height: 32px;
        text-align: center;
        width: 120px;
        margin-right: 20px;
        background: #E5E5E5;
        color:#333;
        border-radius: 6px;
        cursor: pointer;
        &.active{
            color:#fff;
            background: #C30D20;
            i{
                background: url('../../../assets/image/money_icon_active.png')no-repeat 50% 50% / cover;
            }
        }
        i{
            display: inline-block;
            vertical-align: middle;
            margin-right: 4px;
            height: 14px;
            width: 14px;
            background: url('../../../assets/image/money_icon.png')no-repeat 50% 50% / cover;
        }
    }
}
.table-container{
    margin-top:20px;
}
.settlement-page{
    padding:0 20px !important;
    background: #fff;
    .moneyBox{
        overflow:hidden;
        margin:20px 0;
        .moneyOne,.moneyTwo{
            float: left;
            width: 440px;
            background: rgba(0,0,0,0.2);
            height: 66px;
            line-height: 66px;
            text-align: center;
            border-radius: 6px;
            &.moneyOne{
                background-image: linear-gradient(#FF9760, #FD7A59);
                background-color:#FF8A5D;
                margin-right: 20px;
            }
            &.moneyTwo{
                background-image: linear-gradient(#80DEFF, #79C0FF);
                background-color: #7DCFFF;
            }
            span{
                font-size: 16px;
                color:#fff;
                display: inline-block;
                vertical-align: middle;
            }
            .font-bold{
                font-weight: bold;
                font-size: 18px;
                margin:0 20px;
                color:#fff;
                display: inline-block;
                vertical-align: middle;
            }
            .but{
                width: 80px;
                height: 26px;
                line-height: 26px;
                border-radius: 6px;
                font-size: 12px;
                color:#C30D20;
                background: #fff;
                cursor: pointer;
                display: inline-block;
                vertical-align: middle;
                &:hover{
                    background: rgba(255,255,255,0.9);
                }
            }
        }
    }
}
</style>
