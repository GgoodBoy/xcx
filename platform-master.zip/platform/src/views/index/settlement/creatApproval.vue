<template>
    <div class="creat-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/settlement/indexOne' }">结算</el-breadcrumb-item>
            <el-breadcrumb-item>提现</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content-one">
            <div class="account-info">
                <div class="account-num">
                    提现帐号：<span> {{radioData?radioData.bankAccount:''}} </span>  {{radioData?radioData.reeceivingBank:''}}
                </div>  
                <div v-if="userOrcompany==1?false:true" class="account-btn">
                    <div v-if="userOrcompany==2">
                        <img :src="icons"/>
                        <el-button v-btn-blur class="black-btn" type="text" @click="changeBank(1)">更换</el-button>
                    </div>
                    <div v-if="userOrcompany==1&&!radioData">
                        <el-button v-btn-blur class="black-btn" type="text" @click="changeBank(2)">添加</el-button>
                    </div>
                </div>
            </div>
            <p class="tips">
                修改提现帐户请进入【帐户】-【提现设置】
            </p>
        </div>
        <div  class="content-two">
            <div>
                <div>
                    <label>提现金额</label>
                    <el-input
                        placeholder="请输入提现金额"
                        v-model="settlePrice"
                        style="width:442px;"
                        clearable>
                    </el-input>
                    <p class="black-btn"  @click="allMoneyCochOut">全部</p>
                </div>
                <p class="error-tips">
                    金额不符合提现规则
                </p>
                <div class="btn">
                    <el-button type="primary" v-btn-blur @click="saveType">提交申请</el-button>
                    <p class="tips">￥100元起提</p>
                </div>
            </div>
            <div class="creatApprovalInfo">
                <p>提现说明：</p>

                <p>提1.提现金额不能低于￥100元</p>

                <p>提2.提现申请发起后，由管理员进行审批，请关注结算订单状态。</p>

                <p>提3.当前提现金额是您的税前收入，会根据你在学国学网中的提现金额合并计税。详询客服。</p>

                <p>提4.提现如遇问题，请拨打客服电话：010-62198619</p>                
            </div>

        </div>
        <div class="my-dialog" v-if="dialogVisible">
            <div class="dialogConten">
                <div style="text-align:center">选择提现帐号</div>
                <div class="listCss">  
                    <el-radio-group v-model="withdrawalId" @change="radioBank">
                        <div v-for="(item,index) in bankData" :key="index">
                            <el-radio :label="item.id">{{item.reeceivingBank}}</el-radio>
                        </div>
                    </el-radio-group>                               
                </div>
                <div style="text-align:center">
                    <el-button type="primary">确 定</el-button>
                    <el-button type="success">取 消</el-button>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import icons from '@/assets/image/icons.jpg'
@Component({
  name:'login'
})
export default class MyComponent extends Vue {
    bankData:object[]=[];
    icons:any=icons;
    settlePrice='';
    withdrawalId='';
    dialogVisible:boolean=false;
    radioData:any={
        bankAccount:'',
        reeceivingBank:''
    };
    settlePriceBegin='';
    settlePriceEnd='';
    userOrcompany:number=-1;
    created(){
        this.getCreatPassAccount();
        this.getSettlePriceEven();
    }
    saveType(){
           this.setExamineTle();
    }
    allMoneyCochOut(){
        this.settlePrice=this.settlePriceBegin;
    }
    //保存表单没观看信息数据id
    async setExamineTle(){
        try {
            const query = {
                settlePrice:this.settlePrice,
                withdrawalId:this.withdrawalId
            }                    
            const res = await this.$http.post(this.$server.setTleAddOrder,query)
            if(res.code==200){
                this.$router.push('/index/settlement/indexOne');
                console.log('保存消息id成功');
            }                    
        } catch (err) {
            console.log(err);
        }
    }    
    //保存表单没观看信息数据id
    async getSettlePriceEven(){
        try {                   
            const res = await this.$http.get(this.$server.getSettlePriceSettle)
            if(res.code==200){
                this.settlePriceBegin=res.data.settlePriceBegin;
                this.settlePriceEnd=res.data.settlePriceEnd;
            }                    
        } catch (err) {
            console.log(err);
        }
    }    
    //保存表单没观看信息数据id
    async getCreatPassAccount(){
        try {                
            const res = await this.$http.get(this.$server.getPassAccountWithdrawal)
            if(res.code==200){
                if(res.data){
                    this.bankData = res.data;
                    this.radioData = res.data[0];
                }
            }                    
        } catch (err) {
            console.log(err);
        }
    }   
    //
    //保存表单没观看信息数据id
    async getMechanismTypes(){
        try {                
            const res = await this.$http.get(this.$server.getMechanismTypeSettle)
            if(res.code==200){
                this.userOrcompany=res.data
            }                    
        } catch (err) {
            console.log(err);
        }
    }    
    radioBank(id:any){
        this.bankData.forEach((element:any) => {
            if(element.id==id){
                this.radioData = element;
            }
        });
        this.dialogVisible=false;
    } 
    changeBank(type:number){
        if(type==1){
            if(this.bankData){
                this.dialogVisible=true;
            }else{
                //跳转个人认证-提现设置
                this.$router.push('/index/attestation/userAttestation/setUpUserCashOut');
            }
        }else{
            //跳转机构认证-提现设置
            this.$router.push('/index/attestation/companyAttestation/companyCashout');
        }

    }
}
</script>
<style lang="scss" scoped>
.creat-page{
    padding: 0px 0 20px !important;
    background: #f4f4f4;
    .content-one{
        padding: 20px 27px;
        margin-top:7px;
        border:6px;
        overflow: hidden;
        height: 85px;
        background: url('../../../assets/image/withcash_bgd.png')no-repeat 50% 50% / cover;
        .account-info{
            font-size: 0;
            >div{
                display: inline-block;
                vertical-align: middle;
                &.account-num{
                    line-height: 21px;
                    height: 21px;
                    font-weight: bold;
                    font-size: 16px;
                    span{
                        margin-right: 30px;
                    }
                }
            }
        }
        .tips{
            line-height: 19px;
            height: 19px;
            margin-top:4px;
        }
    }
    .content-two{
        padding:30px 20px;
        margin-top:20px;
        background: #fff;
        border-radius: 6px;
        label{
            position: relative;
            padding-left: 7px;
            line-height: 19px;
            height: 19px;
            font-weight: bold;
            margin-right: 24px;
            &::before{
                content:'*';
                color:#C30D23;
                position: absolute;
                left: -2px;
                top:3px;
            }
        }
        .black-btn{
            display: inline-block;
            vertical-align: middle;
            margin-left: 10px;
            color:#666;
        }
        .error-tips{
            margin-top:7px;
            padding: 0 99px;
            color:#C30D23;
            font-size: 12px;
        }
        .btn{
            margin-top:17px;
            font-size: 0;
            padding-left: 87px;
            /deep/ .el-button{
                padding: 12px 51px;
                color:#fff;
            }
            .tips{
                margin-left: 10px;
                color:#C30D20;
                font-size: 12px;
                display: inline-block;
                vertical-align: bottom;
            }
        }
        .creatApprovalInfo{
            border-top: 1px solid #e5e5e5;
            padding: 20px 0;
            margin-top:36px;
            p{
                font-size: 12px;
                font-family: MicrosoftYaHei;
                color: #999;
                line-height: 25px;
                padding-left: 12px;
            }
        } 
    } 
    .my-dialog{
        position:fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        display: flex;
        flex-direction:column-reverse ;
        justify-content:center;
        align-items: center;
        background: rgba(0,0,0,0.2);
        .dialogConten{
            padding: 20px;
            background: #fff;
            .listCss{
                min-width: 300px;
                max-height: 300px;
                overflow-y: auto;
            }
        }
    }  
}

</style>
