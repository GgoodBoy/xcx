<template>
    <div class="course-baseInfo-update-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/course/myCourse' }">课程</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/index/course/myCourse' }">我的课程</el-breadcrumb-item>
            <el-breadcrumb-item>发课</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content" v-loading="loading">
            <div class="part-item">
                <el-form class="form" ref="form1" :model="form1" label-width="68px" :rules="rules1">
                    <el-form-item label="课程名称" class="course-name" prop="title">
                        <el-input placeholder="请输入20个字以内的课程名称" v-model="form1.title" maxlength="20" clearable></el-input>
                        <p class="num">{{form1.title.length}}/20</p>
                    </el-form-item>
                    <el-form-item label="课程简介" class="course-intro" prop="intro">
                        <el-input placeholder="请输入20个字以内的课程简介" v-model="form1.intro" maxlength="20" clearable></el-input>
                        <p class="num">{{form1.intro.length}}/20</p>
                    </el-form-item>
                    <el-form-item label="课程类型" class="course-type">
                        <el-radio v-model="form1.courseType" label="1" :disabled="courseData.id?true:false">视频</el-radio>
                        <el-radio v-model="form1.courseType" label="2" :disabled="courseData.id?true:false">音频</el-radio>
                        <span class="tips">课程类型选中后不能修改</span>
                    </el-form-item>
                    <el-form-item label="适合人群" class="course-type">
                        <el-radio v-model="form1.crowdType" label="1" :disabled="courseData.id?true:false">成人</el-radio>
                        <el-radio v-model="form1.crowdType" label="2" :disabled="courseData.id?true:false">少儿</el-radio>
                        <span class="tips">适合人群选中后不能修改</span>
                    </el-form-item>
                </el-form>
            </div>
            <div class="part-item">
                <el-form class="form" ref="form2" :model="form2" label-width="68px" :rules="rules2">
                    <el-form-item label="所属分类" class="course-classify" prop="mainClassifyId">
                        <el-select placeholder="一级分类" clearable v-model="form2.mainClassifyId" @change="getMainClassifyId" v-loading="oneClassifyListLoading">
                            <el-option
                                v-for="item in oneClassifyList"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                        <el-select placeholder="二级分类" clearable v-model="form2.childrenClassifyIds" v-loading="twoClassifyListLoading">
                            <el-option
                                v-for="item in twoClassifyList"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="课程封面" class="course-surface" prop="surfacePlot" >
                        <div class="surface" v-loading="imgLoading" @click="uploadFile('box')">
                            <template v-if="form2.surfacePlot.length>0">
                                <img :src="form2.surfacePlot" @click="previewImageEvent(form2.surfacePlot)"/>
                            </template>
                            <template v-else><i class="pic"></i></template>
                        </div>
                        <div class="edit-surface" v-if="form2.surfacePlot.length>0" @click="uploadFile">
                            <i class="el-icon-edit"></i>
                            修改
                        </div>
                        <p class="tips">课程简介图片尺寸750*420像素或16:9， 支持PNG、JPG格式，大小小于1M</p>
                    </el-form-item>
                    <el-form-item label="课程讲师" class="course-teacher" prop="teacherList">
                        <div class="empty" v-if="form2.teacherList.length==0" @click="openDialog">
                            <i class="pic"></i>
                        </div>
                        <template v-else>
                            <div class="teacher-box" v-for="item in form2.teacherList" :key="item.id">
                                <img :src="item.avatar" class="avatar" @click="previewImageEvent(item.avatar)"/>
                                <div class="info">
                                    <p class="name">{{item.name}}</p>
                                    <p class="professional">{{item.professionalTitle}}</p>
                                </div>
                            </div>
                        </template>
                        <div class="edit-surface" v-if="form2.teacherList.length>0" @click="openDialog">
                            <i class="el-icon-edit"></i>
                            修改
                        </div>
                        <p class="tips">最多选中10名讲师信息</p>
                    </el-form-item>
                    <el-form-item label="课时" class="course-period" prop="planPeriodNum">
                        <el-input placeholder="1-9999" v-model.trim="form2.planPeriodNum" maxlength="4" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="是否收费" class="course-isFree">
                        <el-radio v-model="form2.isFree" label="1" :disabled="courseData.id?true:false">免费</el-radio>
                        <el-radio v-model="form2.isFree" label="0" :disabled="courseData.id?true:false">收费</el-radio>
                        <span class="tips">收费课程价格大于0元，选中后不能修改</span>
                    </el-form-item>
                    <el-form-item label="价格" class="course-price" prop="sellingPrice" v-if="form2.isFree=='0'">
                        <el-input placeholder="最多保留2位小数" v-model.trim="form2.sellingPrice" clearable></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div class="part-item">
                <el-form class="form" ref="form3" :model="form3" label-width="68px" :rules="rules3">
                    <el-form-item label="课程介绍" class="course-introduce" prop="introduce" :error="introduceError">
                        <Editor v-model="form3.introduce" @blurEvent="blurEvent"/>
                    </el-form-item>        
                </el-form>
                <div class="btns" v-if="courseData.id">
                    <el-button type="primary" class="save" @click="auditingEvent">提交审核</el-button>
                    <el-button type="primary" class="save" @click="saveEvent('edit')">保存</el-button>
                    <el-button class="cancel" @click="$router.go(-1)">取消</el-button>
                </div>  
                <div class="btns" v-else>
                    <el-button type="primary" class="save" @click="saveEvent('add')">保存</el-button>
                    <el-button class="cancel" @click="$router.go(-1)">取消</el-button>
                </div>       
            </div> 
        </div>
        <input type="file" name="file" class="file-upload" ref="uploadInput" @change="getFile($event)" @click="emptyFile($event)"/>
        <el-dialog
            :visible.sync="dialogVisible"
            width="978px"
            custom-class="teacher-list-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >
            <p slot="title">
                选择讲师
            </p>
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入讲师姓名" v-model="name"></el-input>
                </div>
                <el-button class="search-btn" @click="searchEvent" v-btn-blur>
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <el-button class="refresh-btn" @click="refreshEvent" v-btn-blur>
                    <i class="el-icon-refresh"></i>
                    刷新
                </el-button>
            </div>
            <div class="teacher-list">
                <div class="teacher-item" v-for="(item,index) in teacherList " :key="item.id" :class="{'active':item.checked}" @click="chooseTeacher(index)">
                    <img class="avatar" :src="item.avatar"/>
                    <div class="info">
                        <p class="name">{{item.name}}</p>
                        <p class="job">{{item.professionalTitle}}</p>
                    </div>
                    <div class="check">
                        <i class="el-icon-check"></i>
                    </div>
                </div>
            </div>
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>  
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" class="save-btn" @click="saveTeacher">确 定</el-button>
            </span>
        </el-dialog>
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>
    </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import Editor from '@/components/Editor.vue'
import previewImage from '@/components/PreviewImage.vue'
Component.registerHooks([
  'beforeRouteLeave','beforeDestroy'
]);
@Component({
    name:'course-baseInfo-update',
    components:{Editor,previewImage}
})
export default class Index extends Vue{
    editFlag = false;//是否动过数据
    oneClassifyAllList:any = []
    oneClassifyList:any = []
    oneClassifyListLoading = false
    twoClassifyList = []
    twoClassifyListLoading = false
    form1 = {
        title:'',
        intro:'',
        courseType:'1',
        crowdType:'1'
    }
    rules1 = {
        title:[
            { required: true, message: '课程名称不能为空', trigger: 'blur' },
            { min: 1, max: 20, message: '课程名称不能超过20个字', trigger: 'blur' }
        ],
        intro:[
            { required: true, message: '课程简介不能为空', trigger: 'blur' },
            { min: 1, max: 20, message: '课程简介不能超过20个字', trigger: 'blur' }
        ]
    }
    form2 = {
        mainClassifyId:'',
        childrenClassifyIds:'',
        surfacePlot:'',
        teacherList:[],
        planPeriodNum:'',
        isFree:'1',
        sellingPrice:'',
        originalPrice:''
    }
    rules2 = {
        mainClassifyId:[
            { required: true, message: '请选择所属分类', trigger: 'change' },
        ],
        surfacePlot:[
            { required: true, message: '请选择上传课程封面图', trigger: 'click' },
        ],
        teacherList:[
            { required: true, message: '请选择课程教师', trigger: 'click' },
        ],
        planPeriodNum:[
            { required: true, message: '课时数不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^\d+$/
                if(!regExp.test(value)||value<1||value>9999){
                    return callback(new Error('课时数限1-9999的整数'));
                }
                callback();
            }, trigger: 'blur' }
        ],
        sellingPrice:[
            { required: true, message: '请输入价格', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^(?!0+(?:\.0+)?$)(?:[1-9]\d*|0)(?:\.\d{1,2})?$/
                if(!regExp.test(value)){
                    return callback(new Error('只能输入非零数字，最多保留小数点后两位'));
                }
                callback();
            }, trigger: 'blur' }
        ]
    }
    imgLoading = false;
    form3 = {
        introduce:''
    }
    rules3 = {
        introduce:[
            { required: true, message: '请输入课程介绍', trigger: 'blur' },
        ]
    }
    introduceError = ''
    dialogVisible = false;
    pageNo = 1;
    pageSize = 12;
    total = 12;
    pages = 1;
    teacherList = []
    name = ''
    courseId:any = ''
    courseData:any= {}
    loading = false
    showFlag = false
    srcList:any = []
    @Watch('pageNo')
        onPageNoChanged(cur:number){
            if(cur>0){
                this.getList()
            }
        }
    @Watch('form1',{ deep: true })
        onForm1Changed(cur:any){
            this.editFlag = true;
            if(this.oneClassifyAllList.length==0) return;
            if(cur.crowdType==1){
                this.form2.mainClassifyId = ''
                this.form2.childrenClassifyIds = ''
                this.oneClassifyList = this.oneClassifyAllList.manClassifies.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                });        
            }else if(cur.crowdType==2){
                this.form2.mainClassifyId = ''
                this.form2.childrenClassifyIds = ''
                this.oneClassifyList = this.oneClassifyAllList.childClassifies.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                });        
            }else{
                //other
            }
        }
    @Watch('form2',{ deep: true })
        onForm2Changed(){
            this.editFlag = true;
        }
    @Watch('form2',{ deep: true })
        onForm3Changed(){
            this.editFlag = true;
        }
    @Watch('editFlag')
        onEditFlagChanged(cur:boolean){
            if(cur){
                window.addEventListener('beforeunload', this.beforeunloadHandler, false);
            }else{
                window.removeEventListener('beforeunload',this.beforeunloadHandler,false)
            }
        }    
    beforeRouteLeave (to:any,from:any,next:any){
        if(this.editFlag){
            this.$confirm(`是否立即保存当前修改`, {
                confirmButtonText: '保存',
                cancelButtonText: '取消',
                closeOnClickModal:false,
                closeOnPressEscape:false,
                center:true
            }).then(() => {
                this.save()
            }).catch(()=>{
                this.editFlag = false;
                next()
            })
        }else{
            next()
        }
        next(false)
    }              
    created(){
        this.$message.error('1')
        if(this.$route.query&&this.$route.query.id){
            this.courseId = this.$route.query.id;
            this.getOneClassifyList()
            this.$nextTick(()=>{
                this.getCourseInfo()
            })
        }else{
            this.getOneClassifyList()
        }
    }
    beforeunloadHandler (e:any) {
        e = e || window.event
        if (e) {
        e.returnValue = '您的数据还没有保存，确定要离开吗'
        }
        return '您的数据还没有保存，确定要离开吗'
    }
    /**
     * 预览图片
     */
    previewImageEvent(url:string){
        this.showFlag = true;
        this.srcList = [url]
    }
    /**
     * 获取课程详情
     */
    async getCourseInfo(){
        this.loading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(`${this.$server.courseInfo}/${this.courseId}`,query)
        this.loading = false;
        if(res.code==200){
            this.courseData = res.data.course;
            this.form1 = {
                title:this.courseData.title,
                intro:this.courseData.intro,
                courseType:String(this.courseData.courseType),
                crowdType:String(this.courseData.crowdType)
            }
            setTimeout(()=>{
                this.form2 = {
                    mainClassifyId:this.courseData.oneClassifyList[0].mainClassifyId,
                    childrenClassifyIds:'',
                    surfacePlot:this.courseData.surfacePlot,
                    teacherList:this.courseData.lectureTeacherList,
                    planPeriodNum:this.courseData.planPeriodNum,
                    isFree:String(this.courseData.isFree),
                    sellingPrice:this.courseData.sellingPrice,
                    originalPrice:this.courseData.originalPrice
                }
                if(this.courseData.twoClassifyList){
                    this.form2.childrenClassifyIds = this.courseData.twoClassifyList[0].mainClassifyId
                }
            },1)
            this.form3 = {
                introduce:this.courseData.introduce
            }
            setTimeout(()=>{
                this.editFlag = false;
            },500)
        }else{
            if(res.message=='课程不存在'){
                this.$router.push('/index/course/myCourse')
            }
        }
    }
    /**
     * 获取一级分类
     */
    async getOneClassifyList(){
        this.oneClassifyListLoading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getOneClassifyList,query)
        this.oneClassifyListLoading = false;
        if(res.code==200){
            this.oneClassifyAllList = res.data;
            this.oneClassifyList = res.data.manClassifies.map((item:any)=>{
                return {
                    label:item.name,
                    value:item.id
                }
            });
        }
    }
    /**
     * 下拉框获取一级分类的id
     */
    getMainClassifyId(){
        if(this.form2.mainClassifyId){
            this.getTwoClassifyList();
            this.twoClassifyList = [];
            this.form2.childrenClassifyIds = ''
        }
    }
    /**
     * 根据一级分类获取二级分类
     */
    async getTwoClassifyList(){
        this.twoClassifyListLoading = false;
        const query = {
            params:{}
        }
        const res = await this.$http.get(`${this.$server.getTwoClassifyList}/${this.form2.mainClassifyId}`,query)
        this.twoClassifyListLoading = false;
        if(res.code==200){
            if(res.data.length>0){
                this.twoClassifyList = res.data.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                })  
            }else{
                this.twoClassifyList = []
            }
        }
    }
    blurEvent(content:string){
        if(content.length==0){
            this.introduceError = '请输入课程介绍'
        }else{
            this.introduceError = ''
        }
    }
    /**
     * 上传事件
     */
    uploadFile(flag:string = 'normal'){
        if(flag=='box'&&this.form2.surfacePlot.length>0) return;
        if(this.imgLoading) return;
        const dom = this.$refs.uploadInput as HTMLElement;
        dom.click()
    }
    emptyFile(e:any){
        e.target.value = ''
    }
    /**
     * 获取文件并上传
     */
    getFile(e:any){
        const files = e.target.files || e.dataTransfer.files;
        const fileData = files[0];
        if (!/(\.png|\.jpg|\.jpeg)$/.test(fileData.name.toLowerCase())) {
            this.$message.error('图片格式有误，请上传JPEG(JPG)或PNG格式');
            return;
        }
        if(fileData.size>1024*1024){
            this.$message.error('图片大小不能超过1M');
            return;
        }
        const reader = new FileReader();
        reader.readAsDataURL(fileData);
        reader.onload =(e:any)=>{
            const data = e.target.result;
            const image = new Image();
            image.onload = ()=>{
                const width = image.width;
                const height = image.height;
                if(!((width==750&&height==420)||((height/width)==0.5625))){
                    this.$message.error('请上传750*420或者宽高比等于16:9的图片');
                    return;
                }
                this.imgLoading = true;
                const params = new FormData();
                params.append('file',fileData)
                const config = {
                    headers: {'Content-Type': 'multipart/form-data'}
                }
                this.$http.post(this.$server.uploadPic,params,config).then((res:any)=>{
                    this.imgLoading = false;
                    if(res.code==200){
                        this.form2.surfacePlot = res.data.resourceUrl;
                        const srcList = [];
                        srcList.push(res.data.resourceUrl);
                        this.srcList = srcList;
                    }
                }).catch(()=>{
                    this.imgLoading = false;
                })
            }
            image.src= data;
        }
    }
    openDialog(){
        this.dialogVisible = true;
        this.$nextTick(()=>{
            this.getList()
        })
    }
    /**
     * 获取老师列表
     */
    async getList(){
        const dom = document.querySelector('.teacher-list-dialog') as HTMLElement
        let loadingInstance:any = '';
        if(dom){
            loadingInstance = this.$loading({
                target:dom
            });
        }
        const query = {
            params:{
                name:this.name,
                teacherIds:'',
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        }
        const res = await this.$http.get(this.$server.getSearchTeacherList,query)
        if(dom){
            loadingInstance.close()
        }
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.teacherList = res.data.list;
            this.teacherList.forEach((item:any)=>{
                const index = this.form2.teacherList.findIndex((option:any)=>option.id==item.id)
                item.checked = index>=0?true:false
            })
        }
    }
    /**
     * 选择老师
     */
    chooseTeacher(index:number){
        const obj:any = this.teacherList[index];
        if(!obj.checked){
            const temp = this.teacherList.filter((item:any)=>item.checked==true)
            if(temp.length>9){
                this.$message.error('最多选择10名老师');
                return;
            }
        }
        obj.checked = !obj.checked
        this.$set(this.teacherList,index,obj)
    }
    /**
     * 保存老师
     */
    saveTeacher(){
        this.form2.teacherList = this.teacherList.filter((item:any)=>item.checked==true)
        this.dialogVisible = false;
    }
    /**
     * 老师列表搜索
     */
    searchEvent(){
        this.pageNo = 0;
        this.$nextTick(()=>{
            this.pageNo = 1;
        })
    }
    /**
     * 老师列表刷新
     */
    refreshEvent(){
        this.name = '';
        this.searchEvent()
    }
    /**
     * 保存之前验证
     */
    saveEvent(flag:string){
        const form1:any = this.$refs.form1 as HTMLElement;
        form1.validate((valid:any) => {
            if (valid) {
                const form2:any = this.$refs.form2 as HTMLElement;
                form2.validate((valid:any) => {
                    if (valid) {
                        const form3:any = this.$refs.form3 as HTMLElement;
                        form3.validate((valid:any) => {
                            if (valid) {
                                if(flag=='add'){
                                    this.save()
                                }else{
                                    this.edit()
                                }
                            } else {
                                return false;
                            }
                        });
                    } else {
                        return false;
                    }
                });
            } else {
                return false;
            }
        });
    }
    /**
     * 保存课程基本信息
     */
    async save(){
        this.loading = true;
        const form1:any = this.$refs.form1 as HTMLElement;
        const form2:any = this.$refs.form2 as HTMLElement;
        const form3:any = this.$refs.form3 as HTMLElement;
        form1.clearValidate();
        form2.clearValidate();
        form3.clearValidate();
        const query:any = Object.assign({},this.form1,this.form2,this.form3)
        query.crowdType = Number(query.crowdType)
        query.courseType = Number(query.courseType)
        query.isFree = Number(query.isFree)
        query.planPeriodNum = Number(query.planPeriodNum)
        query.originalPrice = query.sellingPrice
        const teacherList = query.teacherList;
        delete query.teacherList
        teacherList.forEach((item:any,index:number)=>{
            query['teacherList['+index+'].teacherId'] = item.id;
            query['teacherList['+index+'].type'] = index+1;
        })
        const res = await this.$http.post(this.$server.courseAdd,query)
        this.loading = false;
        if(res.code==200){
            this.editFlag = false;
            this.$router.push('/index/course/myCourse')
        }
    }
    /**
     * 编辑课程
     */
    async edit(){
        this.loading = true;
        const form1:any = this.$refs.form1 as HTMLElement;
        const form2:any = this.$refs.form2 as HTMLElement;
        const form3:any = this.$refs.form3 as HTMLElement;
        form1.clearValidate();
        form2.clearValidate();
        form3.clearValidate();
        const query:any = Object.assign({},this.form1,this.form2,this.form3)
        query.crowdType = Number(query.crowdType)
        query.courseType = Number(query.courseType)
        query.isFree = Number(query.isFree)
        query.planPeriodNum = Number(query.planPeriodNum)
        query.originalPrice = query.sellingPrice
        const teacherList = query.teacherList;
        delete query.teacherList
        teacherList.forEach((item:any,index:number)=>{
            query['teacherList['+index+'].teacherId'] = item.id;
            query['teacherList['+index+'].type'] = index+1;
        })
        const res = await this.$http.post(`${this.$server.courseEdit}/${this.courseId}`,query);
        this.loading = false;
        if(res.code==200){
            this.editFlag = false;
            this.$message.success('课程信息修改成功')
            this.$router.push('/index/course/myCourse')
        }
    }
    /**
     * 提交审核
     */
    auditingEvent(){
        console.log(1)
    }
}
</script>
<style lang="scss" scoped>
    .course-baseInfo-update-page{
        background: #F4F4F4;
        padding: 0 0 10px 0!important;
        .el-breadcrumb{
            margin-left: 20px;
        }
        .part-item{
            background: #fff;
            border-radius: 6px;
            padding: 20px 32px;
            margin-bottom: 20px;
            transition: all 0.3s;
            &:hover{
                box-shadow: 0 0 10px #dfdfdf;
            }
            /deep/ .el-form{
                .el-form-item__content{
                    margin-left: 94px!important;
                }
                .el-form-item__label{
                    text-align: justify;
                    -moz-text-align-last: justify;
                    text-align-last: justify;
                    font-weight: bold;
                    position: relative;
                }
                .el-form-item__label::before{
                    position: absolute;
                    left: -13px;
                    top: 3px;
                }
                .el-input__inner{
                    width: 442px;
                    background: #fcfcfc;
                }
                .el-select{
                    margin-right: 20px;
                    .el-input__inner{
                        width: 120px;
                    }
                }
                .el-input{
                    width:auto!important;
                }
                .num{
                    display: inline-block;
                    vertical-align: middle;
                    color:#666666;
                    margin:0 20px 0 10px;
                }
                .tips{
                    color:#999;
                }
                .surface{
                    width: 150px;
                    height: 84px;
                    border: 1px solid #E5E5E5;
                    border-radius: 6px;
                    position: relative;
                    cursor: pointer;
                    display: inline-block;
                    img{
                        position: absolute;
                        background: none;
                        outline: none;
                        top:50%;
                        left: 50%;
                        border-radius: 6px;
                        transform:translate(-50%,-50%);
                        width:100%;
                        user-select:none;
                        max-width: 150px;
                        max-height: 84px;
                    }
                    .pic{
                        width: 44px;
                        height: 37px;
                        position: absolute;
                        top:50%;
                        left: 50%;
                        transform: translate(-50%,-50%);
                        background: url('../../../../assets/image/pic.png')no-repeat 50% 50% / cover;
                    }
                }
                .edit-surface{
                    color:#C30D20;
                    display: inline-block;
                    vertical-align: bottom;
                    margin:0 0 2px 5px;
                    cursor: pointer;
                }
                .course-surface{
                    .tips{
                        font-size: 12px;
                        width: 220px;
                        line-height: 16px;
                        margin-top:5px;
                    }
                }
                .course-teacher{
                    .teacher-box,.empty{
                        width:228px;
                        height: 84px;
                        border-radius: 6px;
                        border:1px solid #e5e5e5;
                        padding: 18px;
                        display: inline-block;
                        position: relative;
                        font-size: 0;
                        margin-right: 20px;
                        margin-bottom:5px;
                        .pic{
                            width: 44px;
                            height: 37px;
                            position: absolute;
                            top:50%;
                            left: 20%;
                            transform: translate(-50%,-50%);
                            background: url('../../../../assets/image/pic.png')no-repeat 50% 50% / cover;
                        }
                        .avatar{
                            display: inline-block;
                            vertical-align: top;
                            width: 46px;
                            height: 46px;
                            margin-right: 6px;
                            border-radius: 50%;
                        }
                        .info{
                            display: inline-block;
                            vertical-align: top;
                            width: calc(100% - 52px);
                            .name{
                                color: #333333;
                                line-height: 19px;
                                font-size: 13px;
                                margin-top:-4px;
                            }
                            .professional{
                                color: #666666;
                                line-height: 16px;
                                display: -webkit-box;
                                -webkit-box-orient: vertical;
                                -webkit-line-clamp: 2;
                                overflow: hidden;
                                font-size: 13px;
                            }
                        }
                    }
                    .teacher-box{
                        margin-bottom:20px;
                    }
                    .edit-surface{
                        color:#C30D20;
                        display: inline-block;
                        vertical-align: bottom;
                        margin:0 0 12px -10px;
                        cursor: pointer;
                    }
                    .tips{
                        font-size: 12px;
                        width: 220px;
                        line-height: 12px;
                    }
                }
            }
        }
        .btns{
            padding-left:94px;
            /deep/ .el-button{
                padding: 13px 38px;
            }
            .save{
                margin-right: 10px;
            }
        }
        .file-upload{
            opacity: 0;
            position: absolute;
            right: 10000px;
        }
        /deep/ .teacher-list-dialog{
            margin:0!important;
            position: absolute!important;
            top:50%;
            left: 50%;
            transform: translate(-50%,-50%);
            .el-dialog__header{
                p{
                    text-align: left;
                }
            }
            .el-dialog__body{
                .search-area{
                    /deep/ .el-input__inner{
                        width: 610px;
                    }
                    .keyword-box{
                        display: inline-block;
                        vertical-align: middle;
                    }
                    .search-btn{
                        margin-left:20px;
                    }
                    .refresh-btn{
                        margin-left:141px;
                    }
                }
                .teacher-list{
                    font-size: 0;
                    margin-top:20px;
                    .teacher-item{
                        width: 296px;
                        height: 108px;
                        border-radius: 6px;
                        border:1px solid #e5e5e5;
                        padding: 23px 20px;
                        font-size: 0;
                        margin-bottom:20px;
                        transition: all 0.3s;
                        position: relative;
                        overflow: hidden;
                        display: inline-block;
                        &:nth-child(3n+2){
                            margin:0 20px 20px 20px;
                        }
                        &.active{
                            border:1px solid #C30D20;
                            .check{
                                opacity: 1;
                            }
                        }
                        .avatar{
                            width: 60px;
                            height: 60px;
                            border-radius: 50%;
                            display: inline-block;
                            vertical-align: middle;
                            margin-right: 10px;
                        }
                        .info{
                            display: inline-block;
                            vertical-align: top;
                            width: calc(100% - 70px);
                            .name{
                                height: 19px;
                                line-height: 20px;
                                font-size: 14px;
                                color:#333;
                                
                            }
                            .job{
                                margin-top:8px;
                                line-height: 17px;
                                font-size: 14px;
                                color:#666;
                            }
                        }
                        .check{
                            position: absolute;
                            right: 0;
                            top:0;
                            width:0;
                            height:0;
                            border-top:32px solid #C30D20;
                            border-left:32px solid transparent;
                            opacity: 0;
                            transition: all 0.3s;
                            i{
                                font-size: 14px;
                                position: absolute;
                                left: -17px;
                                top: -29px;
                                color: #fff;
                            }
                        }
                    }
                }
                .page-container{
                    padding: 20px 0 0 0;
                }
            }
            .el-dialog__footer{
                .dialog-footer{
                    /deep/ .el-button{
                            margin:-20px 0 20px 0;
                        padding: 13px 65px;
                    }
                }
            }
        }
    }
</style>