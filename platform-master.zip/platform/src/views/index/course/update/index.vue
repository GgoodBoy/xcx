<template>
    <div class="course-update-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/course/myCourse' }">课程</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/index/course/myCourse' }">我的课程</el-breadcrumb-item>
            <el-breadcrumb-item>发课</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content" v-loading="loading">
            <div class="course-info clearfix">
                <div class="left">
                    <div class="surface" @click="previewImageEvent">
                        <img :src="courseData.surfacePlot"/>
                    </div>
                    <div class="data">
                        <p class="course-title">{{courseData.title}}</p>
                        <div class="b">
                            <p>价格：{{courseData.sellingPrice}}夫子币</p>
                            <p>课程类型：{{courseData.courseType==1?'视频':'音频'}}</p>
                        </div>
                    </div>
                </div>
                <div class="right">
                    <el-button type="text" @click="editCourse"><i class="el-icon-edit-outline"></i>编辑</el-button>
                    <p class="period-num">共{{courseData.planPeriodNum}}节/已更新{{periodList.length}}节</p>
                </div>
            </div>
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入标题" v-model="title" clearable></el-input>
                </div>
                <div class="select-box">
                    <el-select placeholder="试看" clearable v-model="isTry">
                        <el-option
                        v-for="item in tryArr"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <el-button class="search-btn primary" v-btn-blur @click="getPeriodList">
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <el-button class="add-btn" type="primary" v-btn-blur @click="addPeriodEvent">
                    <i class="el-icon-plus"></i>
                    新增一节
                </el-button>
            </div>
            <div class="empty" v-if="periodList.length==0&&finished&&!addPeriodFlag">暂未添加任何节~</div>
            <div class="period-list" v-if="periodList.length>0">
                <div class="period-item" v-for="(item,index) in periodList" :key="item.id">
                    <template v-if="item.status==1">
                        <transition name="fade-show">
                            <div class="form-box" v-if="insertPeriodFlag">
                                <el-form class="form" ref="insertForm" :model="insertForm" label-width="68px" :rules="insertFormRules">
                                    <el-form-item label="" class=""> 
                                        <div class="edit-period">
                                            <p>第{{index+1}}节</p>
                                        </div>
                                    </el-form-item>
                                    <el-form-item label="节标题" class="period-name" prop="title">
                                        <el-input placeholder="请输入20个字以内的节标题" v-model="insertForm.title" maxlength="20" clearable></el-input>
                                        <p class="num">{{insertForm.title.length}}/20</p>
                                    </el-form-item>
                                    <el-form-item :label="courseData.courseType==1?'关联视频':'关联音频'" class="period-video" prop="targetId">
                                        <div class="add-box" @click="openDialog">
                                            <i class="el-icon-plus"></i>
                                            {{courseData.courseType==1?'添加视频':'添加音频'}}
                                        </div>
                                    </el-form-item>
                                    <el-form-item label="文稿" class="period-introduce">
                                        <Editor v-model="insertForm.introduce"/>
                                    </el-form-item>  
                                    <el-form-item label="" class="" v-if="courseData.isFree==0">
                                        <el-checkbox v-model="insertForm.isTry">本节试看</el-checkbox>
                                    </el-form-item>
                                    <el-form-item>
                                        <el-button type="primary" v-btn-blur @click="submitFormEvent('insertForm')">保存</el-button>
                                        <el-button v-btn-blur @click="cancelEvent">取消</el-button>
                                    </el-form-item>      
                                </el-form>    
                            </div>
                        </transition>
                    </template>
                    <template v-if="item.status==2">
                        <div class="period-item-box clearfix">
                            <div class="l">
                                第{{index+1}}节 {{item.title}}
                            </div>
                            <div class="r">
                                <el-button class="up-btn" v-btn-blur type="text" @click="sortEvent(index,'up')" v-if="index>0" :disabled="btnStatus">
                                    <i></i>
                                    上移
                                </el-button>
                                <el-button class="down-btn" v-btn-blur type="text" @click="sortEvent(index,'down')" v-if="index<periodList.length-1" :disabled="btnStatus">
                                    <i></i>
                                    下移
                                </el-button>
                                <el-button class="charu-btn" v-btn-blur type="text" @click="insertEvent(index)" :disabled="btnStatus">
                                    <i></i>
                                    插入
                                </el-button>
                                <el-button class="edit-btn" v-btn-blur type="text" @click="editPeriodEvent(item,index)" :disabled="btnStatus">
                                    <i class="el-icon-edit"></i>
                                    编辑
                                </el-button>
                                <el-button class="shangjia-btn" v-btn-blur type="text" v-if="item.periodStatus==4&&courseData.courseStatus==2" :disabled="btnStatus">
                                    <i></i>
                                    上架
                                </el-button>
                                <el-button class="xiajia-btn" v-btn-blur type="text" v-if="item.periodStatus==3" :disabled="btnStatus">
                                    <i></i>
                                    下架
                                </el-button>
                                <el-button class="del-btn" v-btn-blur type="text" @click="delPeriod(item.id)" :disabled="btnStatus">
                                    <i class="el-icon-circle-close"></i>
                                    删除
                                </el-button>
                            </div>
                        </div>
                        <transition name="fade-show">
                            <div class="form-box" v-if="editPeriodFlag&&item.id==editForm.id">
                                <el-form class="form edit-from" ref="editForm" :model="editForm" label-width="68px" :rules="editFormRules">
                                    <el-form-item label="" class=""> 
                                        <div class="edit-period">
                                            <p>第{{editForm.sort}}节</p>
                                        </div>
                                    </el-form-item>
                                    <el-form-item label="节标题" class="period-name" prop="title">
                                        <el-input placeholder="请输入20个字以内的节标题" v-model="editForm.title" maxlength="20" clearable></el-input>
                                        <p class="num">{{editForm.title.length}}/20</p>
                                    </el-form-item>
                                    <el-form-item :label="courseData.courseType==1?'关联视频':'关联音频'" class="period-video" prop="targetId">
                                        <div class="add-box" @click="openDialog">
                                            <i class="el-icon-plus"></i>
                                            {{courseData.courseType==1?'添加视频':'添加音频'}}
                                        </div>
                                    </el-form-item>
                                    <el-form-item label="文稿" class="period-introduce">
                                        <Editor v-model="editForm.introduce"/>
                                    </el-form-item>  
                                    <el-form-item label="" class="" v-if="courseData.isFree==0">
                                        <el-checkbox v-model="editForm.isTry">本节试看</el-checkbox>
                                    </el-form-item>
                                    <el-form-item>
                                        <el-button type="primary" v-btn-blur @click="submitFormEvent('editForm')">保存</el-button>
                                        <el-button v-btn-blur @click="cancelEvent">取消</el-button>
                                    </el-form-item>      
                                </el-form>    
                            </div>
                        </transition>
                    </template>
                </div>
            </div>
            <transition name="fade-show">
                <div class="form-box" v-if="addPeriodFlag">
                    <el-form class="form" ref="addForm" :model="addForm" label-width="68px" :rules="addFormRules">
                        <el-form-item label="" class=""> 
                            <div class="edit-period">
                                <p>第{{periodList.length+1}}节</p>
                            </div>
                        </el-form-item>
                        <el-form-item label="节标题" class="period-name" prop="title">
                            <el-input placeholder="请输入20个字以内的节标题" v-model="addForm.title" maxlength="20" clearable></el-input>
                            <p class="num">{{addForm.title.length}}/20</p>
                        </el-form-item>
                        <el-form-item :label="courseData.courseType==1?'关联视频':'关联音频'" class="period-video" prop="targetId">
                            <div class="add-box" @click="openDialog">
                                <i class="el-icon-plus"></i>
                                {{courseData.courseType==1?'添加视频':'添加音频'}}
                            </div>
                        </el-form-item>
                        <el-form-item label="文稿" class="period-introduce">
                            <Editor v-model="addForm.introduce"/>
                        </el-form-item>  
                        <el-form-item label="" class="" v-if="courseData.isFree==0">
                            <el-checkbox v-model="addForm.isTry">本节试看</el-checkbox>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" v-btn-blur @click="submitFormEvent('addForm')">保存</el-button>
                            <el-button v-btn-blur @click="cancelEvent">取消</el-button>
                        </el-form-item>      
                    </el-form>    
                </div>
            </transition>
            <template v-if="periodList.length>0">
                <div class="btns" v-if="!btnStatus">
                    <el-button type="primary" v-btn-blur>提交审核</el-button>
                </div>
            </template>
        </div>
        <el-dialog
            :visible.sync="dialogVisible"
            width="978px"
            custom-class="resource-list-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >
            <p slot="title">
                {{courseData.courseType==1?'选择视频':'选择音频'}}
            </p>
            <div class="search-area">
                <div class="keyword-box">
                    <el-input :placeholder="courseData.courseType==1?'请输入视频名称':'请输入音频名称'" v-model="name" clearable></el-input>
                </div>
                <el-button class="search-btn" @click="searchEvent" v-btn-blur>
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <el-button class="refresh-btn" @click="refreshEvent" v-btn-blur>
                    <i class="el-icon-refresh"></i>
                    刷新
                </el-button>
            </div>
            <p class="empty" v-if="resourceList.length==0&&resourceFinished">{{courseData.courseType==1?'没有视频文件哦~':'没有音频文件哦~'}}</p>
            <div class="resource-list">
                <div class="resource-item" v-for="(item,index) in resourceList" :key="item.id" :class="{'active':item.checked}" @click="chooseResource(index)">
                    <img class="icon" :src="item.avatar"/>
                    <div class="info">
                        <p class="title">{{item.title}}</p>
                        <div class="clearfix">
                            <p class="size">{{item.fileSize}}</p>
                            <p class="duration">{{item.durationTemp}}</p>
                        </div>
                    </div>
                    <div class="check">
                        <i class="el-icon-check"></i>
                    </div>
                </div>
            </div>
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>  
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" class="save-btn" @click="saveResource">确 定</el-button>
            </span>
        </el-dialog>
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>
    </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import Editor from '@/components/Editor.vue'
import previewImage from '@/components/PreviewImage.vue'
import {namespace} from 'vuex-class'
const user1Module = namespace('user1')
Component.registerHooks([
  'beforeRouteLeave','beforeDestroy'
]);
const formatTime = (time:any)=>{
  let h:any = '',m:any = '',s:any = '';
  const timeTemp = Math.abs(time)
  if(timeTemp>=3600){
    h = Math.floor(timeTemp / 3600) < 10 ? '0'+Math.floor(timeTemp / 3600) : Math.floor(timeTemp / 3600);
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${h}:${m}'${s}''`:`${h}:${m}'${s}''`
  }else if(timeTemp<3600&&timeTemp>=60){
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${m}'${s}''`:`${m}'${s}''`
  }else{
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${s}''`:`${s}''`
  }
}
@Component({
    name:'course-update',
    components:{Editor,previewImage}
})
export default class Index extends Vue{
    addPeriodFlag = false
    editPeriodFlag = false
    insertPeriodFlag = false
    addForm = {
        title:'',
        targetId:'',
        introduce:'',
        isTry:false,
        addType:-1,
        sort:-1
    }
    addFormRules = {
        title:[
            { required: true, message: '节标题不能为空', trigger: 'blur' },
        ],
        targetId:[
            { required: true, message: '请添加视频', trigger: 'click' },
        ],
    }
    editForm = {
        id:'',
        title:'',
        targetId:'',
        introduce:'',
        isTry:false,
        addType:-1,
        sort:-1
    }
    editFormRules = {
        title:[
            { required: true, message: '节标题不能为空', trigger: 'blur' },
        ],
        targetId:[
            { required: true, message: '请添加视频', trigger: 'click' },
        ],
    }
    insertForm = {
        title:'',
        targetId:'',
        introduce:'',
        isTry:false,
        addType:-1,
        sort:-1
    }
    insertFormRules = {
        title:[
            { required: true, message: '节标题不能为空', trigger: 'blur' },
        ],
        targetId:[
            { required: true, message: '请添加视频', trigger: 'click' },
        ],
    }
    loading = false;
    courseId:any = '';
    courseData:any = {}
    finished = false;
    title = ''
    isTry:any= ''
    tryArr = [
        {label:'是',value:'1'},{label:'否',value:'0'},
    ]
    periodList:any = []
    dialogVisible = false;
    name = ''
    pageNo = 1
    pageSize = 12
    total = 12 
    pages = 1
    resourceList:any = []
    resourceFinished = false;
    showFlag = false;
    srcList:any = []
    @user1Module.State('userInfo') userInfo:any
    @Watch('pageNo')
        onPageNoChanged(cur:number){
            if(cur>0){
                if(this.courseData.courseType==1){
                    this.getVideoList()
                }else{
                    this.getAudioList()
                }
            }
        }
    @Watch('addPeriodFlag')
        onAddPeriodFlag(cur:boolean){
            if(!cur){
                this.addForm = {
                    title:'',
                    targetId:'',
                    introduce:'',
                    isTry:false,
                    addType:-1,
                    sort:-1
                }
            }
        }  
    @Watch('editPeriodFlag')
        onEditPeriodFlag(cur:boolean){
            if(!cur){
                this.editForm = {
                    id:'',
                    title:'',
                    targetId:'',
                    introduce:'',
                    isTry:false,
                    addType:-1,
                    sort:-1
                }
            }
        }
    @Watch('insertPeriodFlag')
        onInsertPeriodFlag(cur:boolean){
            if(!cur){
                this.insertForm = {
                    title:'',
                    targetId:'',
                    introduce:'',
                    isTry:false,
                    addType:-1,
                    sort:-1
                }
            }
        }
    @Watch('dialogVisible')
        onDialogVisibleChanged(cur:boolean){
            if(!cur){
                this.pageNo = 1;
                this.name = ''
                this.pageSize = 12
                this.total = 12 
                this.pages = 1
                this.resourceList = []
            }
        }  
    get btnStatus(){
        return this.addPeriodFlag||this.editPeriodFlag||this.insertPeriodFlag
    }      
    beforeRouteLeave(to:any,from:any,next:any){
        if(this.btnStatus){
            this.cancelEvent()
            next(false)
        }else{
            next()
        }
    }     
    created(){
        if(this.$route.query&&this.$route.query.id){
            this.courseId = this.$route.query.id;
            this.$nextTick(()=>{
                this.getCourseInfo()
                this.getPeriodList()
            })
        }else{
            this.$router.go(-1);
            setTimeout(()=>{
                this.$router.push('/index/course/myCourse')
            },300)
        }
    }
    /**
     * 预览图片
     */
    previewImageEvent(){
        this.showFlag = true;
        this.srcList = [this.courseData.surfacePlot]
    }
    /**
     * 获取课程详情
     */
    async getCourseInfo(){
        this.loading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(`${this.$server.courseInfo}/${this.courseId}`,query)
        this.loading = false;
        if(res.code==200){
            this.courseData = res.data.course
        }
    }
    /**
     * 获取课时列表
     */
    async getPeriodList(){
        this.loading = true;
        const query = {
            params:{
                title:this.title,
                isTry:this.isTry==''?-1:Number(this.isTry),
                courseId:this.courseId
            }
        }
        const res = await this.$http.get(`${this.$server.getPeriodList}/${this.courseId}`,query);
        this.loading = false;
        if(res.code==200){
            this.finished = true;
            this.periodList = res.data.periodList.map((item:any)=>{
                item.status = 2;
                return item;
            })
        }
    }
    /**
     * 新增课时小节
     */
    addPeriodEvent(){
        if(this.addPeriodFlag){
            this.$message('请先新增小节的内容');
            return;
        }
        this.addPeriodFlag = true;
        this.addForm.addType = 1;
        this.addForm.sort = this.periodList.length+1
    }
    /**
     * 获取音频列表
     */
    async getAudioList(){
        const dom = document.querySelector('.resource-list-dialog') as HTMLElement;
        let loadingInstance:any = ''
        if(dom){
            loadingInstance = this.$loading({
                target:dom
            });
        }
        const query:any = {
            params:{
                title:this.name,
                beginAt:'',
                endAt:'',
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        }
        if(this.userInfo.userId){
            if(this.userInfo.mechanismId>0){
                query.params.mechanismId = this.userInfo.mechanismId;
            }
        }
        const res = await this.$http.get(this.$server.getAudioList,query);
        this.resourceFinished = true;
        if(dom){
            loadingInstance.close()
        }
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.resourceList = res.data.list;
            this.resourceList.forEach((item:any)=>{
                item.durationTemp = formatTime(item.duration);
                if(this.addPeriodFlag){
                    item.checked = this.addForm.targetId==item.id;
                }
                if(this.editPeriodFlag){
                    item.checked = this.editForm.targetId==item.id;
                }
                if(this.insertPeriodFlag){
                    item.checked = this.insertForm.targetId==item.id;
                }
            })
        }
    }
    /**
    * 获取视频列表数据
    */
    async getVideoList(){
        const dom = document.querySelector('.resource-list-dialog') as HTMLElement;
        let loadingInstance:any = ''
        if(dom){
            loadingInstance = this.$loading({
                target:dom
            });
        }
        const query:any = {
            params:{
                title:this.name,
                beginAt:'',
                endAt:'',
                type:1,
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        }
        if(this.userInfo.userId){
            if(this.userInfo.mechanismId>0){
                query.params.mechanismId = this.userInfo.mechanismId;
            }
        }
        const res = await this.$http.get(this.$server.getVideoList,query);
        this.resourceFinished = true;
        if(dom){
            loadingInstance.close()
        }
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.resourceList = res.data.list;
            this.resourceList.forEach((item:any)=>{
                item.durationTemp = formatTime(item.duration);
                if(this.addPeriodFlag){
                    item.checked = this.addForm.targetId==item.id;
                }
                if(this.editPeriodFlag){
                    item.checked = this.editForm.targetId==item.id;
                }
                if(this.insertPeriodFlag){
                    item.checked = this.insertForm.targetId==item.id;
                }
            })
        }
    }
    /**
     * 资源列表搜索
     */
    searchEvent(){
        this.pageNo = 0;
        this.$nextTick(()=>{
            this.pageNo = 1;
        })
    }
    /**
     * 资源列表刷新
     */
    refreshEvent(){
        this.name = '';
        this.searchEvent()
    }
    /**
     * 打开音频/视频弹窗
     */
    openDialog(){
        this.dialogVisible = true;
        this.resourceList = []
        this.resourceFinished = false;
        this.$nextTick(()=>{
            if(this.courseData.courseType==1){
                this.getVideoList()
            }else{
                this.getAudioList()
            }
        })
    }
    /**
     * 选择资源
     */
    chooseResource(index:number){
        const obj:any = this.resourceList[index]
        obj.checked = !obj.checked;
        this.$set(this.resourceList,index,obj)
    }
    /**
     * 保存资源
     */
    saveResource(){
        const obj = this.resourceList.find((item:any)=>item.checked==true);
        if(!obj){
            const msg = this.courseData.courseType==1?'请添加视频':'请添加音频'
            this.$message.error(msg);
            return;
        }
        if(this.addPeriodFlag){
            this.addForm.targetId = obj.id;
        }
        if(this.editPeriodFlag){
            this.editForm.targetId = obj.id;
        }
        if(this.insertPeriodFlag){
            this.insertForm.targetId = obj.id;
        }
        this.dialogVisible = false;
    }
    /**
     * form表单提交事件
     */
    submitFormEvent(formName:string){
        let form:any = ''
        if(formName=='addForm'){
            form = this.$refs[formName] as HTMLElement;
        }else{
            const temp:any = this.$refs[formName]
            form = temp[0] as HTMLElement;
        }
        form.validate((valid:any) => {
            if (valid) {
                if(this.addPeriodFlag){
                    this.addPeriod(this.addForm,'add')
                }
                if(this.editPeriodFlag){
                    this.editPeriod()
                }
                if(this.insertPeriodFlag){
                    this.addPeriod(this.insertForm,'insert')
                }
            } else {
                return false;
            }
        });
    }
    /**
     * form取消事件
     */
    cancelEvent(){
        this.$confirm(`是否立即保存当前修改`, {
            confirmButtonText: '保存',
            cancelButtonText: '取消',
            closeOnClickModal:false,
            closeOnPressEscape:false,
            center:true
        }).then(() => {
            //保存
            if(this.addPeriodFlag){
                this.submitFormEvent('addForm')
            }
            if(this.editPeriodFlag){
                this.submitFormEvent('editForm')
            }
            if(this.insertPeriodFlag){
                this.submitFormEvent('insertForm')
            }
        }).catch(()=>{
            this.cancel()
        })
    }
    /**
     * form取消
     */
    cancel(){
        if(this.insertPeriodFlag){
            const index = this.periodList.findIndex((item:any)=>item.status==1)
            this.periodList.splice(index,1)
            console.log(this.periodList)
        }
        this.addPeriodFlag = this.editPeriodFlag = this.insertPeriodFlag = false;
    }
    /**
     * 添加课时(新增|插入)
     */
    async addPeriod(form:any,flag:string){
        this.loading = true;
        const query:any = {
            title:form.title,
            targetId:form.targetId,
            introduce:form.introduce,
            addType:form.addType,
            sort:form.sort,
            isTry:form.isTry,
        }
        query.isTry = this.courseData.isFree>0?1:form.isTry?1:0
        const res = await this.$http.post(`${this.$server.addPeriod}/${this.courseId}`,query);
        this.loading = false;
        if(res.code==200){
            if(flag=='add'){
                this.$message.success('课时添加成功')
            }else{
                this.$message.success('课时插入成功')
            }
            this.cancel()
            this.getPeriodList()
        }
    }
    /**
     * 编辑课时
     */
    async editPeriod(){
        this.loading = true;
        const query:any = {
            title:this.editForm.title,
            targetId:this.editForm.targetId,
            introduce:this.editForm.introduce,
            addType:this.editForm.addType,
            sort:this.editForm.sort,
            courseId:this.courseId,
            isTry:this.editForm.isTry
        }
         //这里要改
        query.isTry = this.courseData.isFree>0?1:this.editForm.isTry?1:0
        const res = await this.$http.post(`${this.$server.editPeriod}/${this.editForm.id}`,query);
        this.loading = false;
        if(res.code==200){
            this.$message.success('课时信息编辑成功')
            this.cancel()
            this.getPeriodList()
        }
    }
    /**
     * 编辑小节
     */
    editPeriodEvent(obj:any,index:number){
        if(this.editPeriodFlag){
            this.$message('请先当前的小节编辑');
            return;
        }
        this.editPeriodFlag = true;
        this.editForm = {
            id:obj.id,
            title:obj.title,
            targetId:obj.targetId,
            introduce:obj.introduce,
            isTry:obj.isTry==1?true:false,
            sort:index+1,
            addType:2
        }
    }
    /**
     * 小节插入
     */
    insertEvent(index:number){
        const sort = this.periodList[index].sort;
        if(this.insertPeriodFlag){
            this.$message('请先完成新增小节的内容');
            return;
        }
        this.insertPeriodFlag = true;
        this.periodList.splice(index+1,0,{status:1})
        this.insertForm = {
            title:'',
            targetId:'',
            introduce:'',
            isTry:false,
            sort:sort,
            addType:1
        }
    }
    /**
     * 删除课时
     */
    async delPeriod(id:number){
        this.loading = true;
        const res = await this.$http.post(`${this.$server.delPeriod}/${id}`,{})
        this.loading = false;
        if(res.code==200){
            this.$message.success('课时删除成功')
            this.getPeriodList()
        }
    }
    /**
     * 上移/下移
     */
    async sortEvent(index:number,flag:string){
        const firstId = this.periodList[index].id
        let secondId;
        if(flag=='up'){
            secondId = this.periodList[index-1].id
        }else{
            secondId = this.periodList[index+1].id
        }
        const query = {
            firstId:firstId,
            secondId:secondId
        }
        const res = await this.$http.post(this.$server.upDownMove,query)
        if(res.code==200){
            const msg = flag=='up'?'课时小节上移成功':'课时小节下移成功'
            this.$message.success(msg)
            this.getPeriodList()
        }
    }
    /**
     * 编辑课程信息
     */
    editCourse(){
        this.$router.push({
            path:'/index/course/myCourse/update/baseInfo',
            query:{id:this.courseData.id}
        })
    }
}
</script>
<style lang="scss" scoped>
    .course-update-page{
        background: #fff;
        min-height: calc(100vh - 97px);
        padding:0 20px 20px 20px!important;
        .content{
            .course-info{
                border:1px solid #e5e5e5;
                border-radius: 6px;
                padding: 10px;
                transition: all 0.3s;
                &:hover{
                    box-shadow: 0 0 5px #dfdfdf;
                }
                .left{
                    float: left;
                    font-size: 0;
                    .surface{
                        display: inline-block;
                        vertical-align: middle;
                        cursor: pointer;
                        width: 118px;
                        height: 71px;
                        border-radius: 6px 0px 0px 6px;
                        overflow: hidden;
                        img{
                            width: 100%;
                            height: 100%;
                        }
                    }
                    .data{
                        display: inline-block;
                        vertical-align: middle;
                        margin-left: 10px;
                        height: 71px;
                        .course-title{
                            font-weight: bold;
                            font-size: 14px;
                            color:#333
                        }
                        .b{
                            margin-top:35px;
                            P{
                                display: inline-block;
                                vertical-align: middle;
                                color:#999;
                                font-size: 12px;
                                margin-right: 20px;
                            }
                        }
                    }
                }
                .right{
                    float: right;
                    height: 71px;
                    .period-num{
                        color:rgb(190, 178, 178);
                        font-size: 12px;
                        margin-top:54px;
                        color:#999;
                    }
                    /deep/ .el-button{
                        padding: 0!important;
                        float: right;
                    }
                }
            }
            .search-area{
                font-size: 0;
                margin:20px 0;
                >div{
                    display: inline-block;
                    vertical-align: middle;
                }
                .keyword-box{
                    width: 208px;
                }
                .select-box{
                    margin:0 20px;
                    /deep/ .el-input{
                    width: 92px;
                    }
                }
                .search-btn{
                    padding: 8px 9px;
                    display: inline-block;
                    vertical-align: middle;
                    color:#666;
                    font-size: 14px;
                    border-radius: 6px;
                }
                .add-btn{
                    padding: 8px 13px;
                    display: inline-block;
                    vertical-align: middle;
                    font-size: 14px;
                    color:#fff;
                    margin-left: 390px;
                    border-radius: 6px;
                }
            }
            .empty{
                background: #fcfcfc;
                padding: 0 20px;
                border-radius: 6px;
                border:1px solid #e5e5e5;
                height:100px;
                line-height: 100px;
                text-align: center;
                font-size: 14px;
            }
            .edit-from{
                margin-top:20px;
            }
            .form-box{
                /deep/ .el-form{
                    
                    .el-input__inner{
                        width: 442px;
                        background: #fcfcfc;
                    }
                    .el-input{
                        width:auto!important;
                    }
                    .el-form-item__label{
                        position: relative;
                        text-align-last: justify;
                        font-weight: bold;
                        padding-left:12px;
                        padding-right: 0;
                        &::before{
                            position: absolute;
                            top:2px;
                            left: 0px;
                        }
                    }
                    .el-form-item__content{
                        margin-left: 100px!important;
                    }
                    .edit-period{
                        height: 38px;
                        p{
                            line-height: 38px;
                            border-radius: 6px;
                            background: #fcfcfc;
                            position: absolute;
                            left: -100px;
                            top:0;
                            width: calc(100% + 100px);
                            padding: 0 20px;
                            margin-bottom:20px;
                            border:1px solid #e5e5e5;
                            font-weight: bold;
                        }
                    }
                    .num{
                        display: inline-block;
                        vertical-align: middle;
                        color:#666666;
                        margin:0 20px 0 10px;
                    }
                    .add-box{
                        width: 286px;
                        height: 123px;
                        background: #FCFCFC;
                        border-radius: 6px;
                        border: 1px solid #E5E5E5;
                        text-align: center;
                        line-height: 123px;
                        cursor: pointer;
                        i{
                            font-weight: bold;
                        }
                    }
                    .el-button{
                        padding:12px 35px;
                    }
                    .el-button+.el-button{
                        margin-left:20px;
                    }
                }
            }
            .period-list{
                .period-item{
                    margin-bottom:20px;
                    .period-item-box{
                        height: 38px;
                        line-height: 38px;
                        border-radius: 6px;
                        background: #fcfcfc;
                        padding: 0 20px;
                        border:1px solid #e5e5e5;
                        transition: all 0.3s;
                        &:hover{
                            box-shadow: 0 0 5px #dfdfdf;
                        }
                    }   
                    .l{
                        float: left;
                        font-weight: bold;
                        color:#333;
                        font-size: 14px;
                    }
                    .r{
                        float: right;
                        /deep/ .el-button{
                            position: relative;
                            bottom:1px;
                            color:#333;
                            font-size: 13px;
                            margin-left:20px;
                            i{
                                font-size: 14px;
                            }
                            &.xiajia-btn,&.shangjia-btn{
                                color:#C30D23;
                            }
                            &.del-btn{
                                color:#C30D23;
                                i{
                                    font-size: 14px;
                                }
                            }
                            &.up-btn{
                                i{
                                    display: inline-block;
                                    vertical-align: top;
                                    transform: rotate(180deg);
                                    width: 14px;
                                    height: 14px;
                                    background: url('../../../../assets/image/xiayi.png')no-repeat 50% 50% / cover;
                                }
                            }
                            &.down-btn{
                                i{
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 14px;
                                    height: 14px;
                                    background: url('../../../../assets/image/xiayi.png')no-repeat 50% 50% / cover;
                                }
                            }
                            &.xiajia-btn{
                                i{
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 14px;
                                    height: 14px;
                                    background: url('../../../../assets/image/xiajia.png')no-repeat 50% 50% / cover;
                                }
                            }
                            &.shangjia-btn{
                                i{
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 14px;
                                    height: 14px;
                                    transform: rotate(180deg);
                                    background: url('../../../../assets/image/xiajia.png')no-repeat 50% 50% / cover;
                                }
                            }
                            &.charu-btn{
                                i{
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 14px;
                                    height: 14px;
                                    background: url('../../../../assets/image/charu.png')no-repeat 50% 50% / cover;
                                }
                            }
                        }
                    }
                }
            }
            .btns{
                margin-top:20px;
                float: right;
                /deep/ .el-button{
                    padding: 13px 55px!important;
                }
            }
        }
        /deep/ .resource-list-dialog{
            margin:0!important;
            position: absolute!important;
            top:50%;
            left: 50%;
            transform: translate(-50%,-50%);
            .el-dialog__header{
                p{
                    text-align: left;
                }
            }
            .el-dialog__body{
                .search-area{
                    /deep/ .el-input__inner{
                        width: 610px;
                    }
                    .keyword-box{
                        display: inline-block;
                        vertical-align: middle;
                    }
                    .search-btn{
                        margin-left:20px;
                    }
                    .refresh-btn{
                        margin-left:142px;
                    }
                }
                .empty{
                    text-align: center;
                    padding-top:30px;
                }
                .resource-list{
                    font-size: 0;
                    margin-top:20px;
                    .resource-item{
                        width: 296px;
                        height: 108px;
                        border-radius: 6px;
                        border:1px solid #e5e5e5;
                        padding: 22px 20px;
                        font-size: 0;
                        margin-bottom:20px;
                        transition: all 0.3s;
                        position: relative;
                        overflow: hidden;
                        display: inline-block;
                        &:nth-child(3n+2){
                            margin:0 20px 20px 20px;
                        }
                        &.active{
                            border:1px solid #C30D20;
                            .check{
                                opacity: 1;
                            }
                        }
                        .icon{
                            width: 62px;
                            height: 64px;
                            display: inline-block;
                            vertical-align: middle;
                            margin-right: 10px;
                            background: url('../../../../assets/image/video_icon.png')no-repeat 50% 50% / cover;
                        }
                        .info{
                            display: inline-block;
                            vertical-align: top;
                            height: 64px;
                            position: relative;
                            width: calc(100% - 72px);
                            .title{
                                line-height: 16px;
                                font-size: 14px;
                                color:#333;
                                display: -webkit-box;
                                -webkit-box-orient: vertical;
                                -webkit-line-clamp: 3;
                                overflow: hidden;
                            }
                            .clearfix{
                                font-size: 12px;
                                color:#999;
                                line-height: 16px;
                                position: absolute;
                                bottom:0;
                                left:0;
                                width: 100%;
                                .size{
                                    float: left;
                                }
                                .duration{
                                    float: right;
                                }
                            }
                        }
                        .check{
                            position: absolute;
                            right: 0;
                            top:0;
                            width:0;
                            height:0;
                            border-top:32px solid #C30D20;
                            border-left:32px solid transparent;
                            opacity: 0;
                            transition: all 0.3s;
                            i{
                                font-size: 14px;
                                position: absolute;
                                left: -17px;
                                top: -29px;
                                color: #fff;
                            }
                        }
                    }
                }
                .page-container{
                    padding: 20px 0 0 0;
                }
            }
            .el-dialog__footer{
                .dialog-footer{
                    /deep/ .el-button{
                        margin:-20px 0 20px 0;
                        padding: 13px 65px;
                    }
                }
            }
        }
        .fade-show-enter-active, .fade-show-leave-active {
            transition: opacity .3s;
        }
        .fade-show-enter, .fade-show-leave-to /* .fade-leave-active below version 2.1.8 */ {
            opacity: 0;
        }
    }
</style>