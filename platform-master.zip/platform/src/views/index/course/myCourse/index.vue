<template>
    <div class="my-course-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/course/myCourse' }">课程</el-breadcrumb-item>
            <el-breadcrumb-item>我的课程</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入课程标题或描述" v-model="searchContent" clearable></el-input>
                </div>
                <div class="type-select-box">
                    <el-select placeholder="课程类型" clearable v-model="courseType" :popper-append-to-body="false">
                        <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="free-select-box">
                    <el-select placeholder="收费" clearable v-model="isFree" :popper-append-to-body="false">
                        <el-option
                        v-for="item in freeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="people-select-box">
                    <el-select placeholder="人群" clearable v-model="crowdType" :popper-append-to-body="false">
                        <el-option
                        v-for="item in peopleOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="classify-one-select-box">
                    <el-select placeholder="一级分类" clearable v-model="mainClassifyId" @change="getMainClassifyId" :popper-append-to-body="false">
                        <el-option
                        v-for="item in oneClassifyList"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="classify-two-select-box">
                    <el-select placeholder="二级分类" clearable v-model="childrenClassifyId" :popper-append-to-body="false">
                        <el-option
                        v-for="item in twoClassifyList"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="course-status-select-box">
                    <el-select placeholder="课程状态" clearable v-model="courseStatus" :popper-append-to-body="false">
                        <el-option
                        v-for="item in courseStatusOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="auditing-status-select-box">
                    <el-select placeholder="审核状态" clearable v-model="examineStatus" :popper-append-to-body="false">
                        <el-option
                        v-for="item in auditingStatusOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="date-picker-box">
                    <el-date-picker
                        v-model="startTime"
                        type="date"
                        format="yyyy-MM-dd"
                        value-format="yyyy-MM-dd"
                        placeholder="开始时间">
                    </el-date-picker>
                    <p>至</p>
                    <el-date-picker
                        v-model="endTime"
                        type="date"
                        format="yyyy-MM-dd"
                        value-format="yyyy-MM-dd"
                        :picker-options="pickerOptions"
                        placeholder="结束时间">
                    </el-date-picker>
                </div>
                <div class="mechanism-select-box" v-if="userType==1">
                    <el-select placeholder="所属机构" clearable v-model="mechanismId" :popper-append-to-body="false">
                        <el-option
                        v-for="item in mechanismOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <el-button class="search-btn" v-btn-blur type="primary" @click="search">
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <div class="handle-btns">
                    <el-button class="add-btn" v-btn-blur type="primary" @click="$router.push('/index/course/myCourse/update/baseInfo')">
                        <i class="el-icon-plus"></i>
                        发布新课
                    </el-button>
                    <el-button class="auditing-btn" v-btn-blur type="primary" @click="$router.push('/index/course/auditing')">
                        课程审核
                    </el-button>
                </div>
            </div>
            <div class="table-container scroll-table" v-loading="loading">
                <el-table
                :data="tableData"
                style="width: 100%"
                :fit="true"
                border
                header-row-class-name="table-header">
                    <el-table-column
                        prop="sortId"
                        label="序号"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        label="课程名称"
                        align="center"
                        width="300"
                    >
                        <template slot-scope="scope">
                            <div class="surface-box" @click="previewImageEvent(scope.row.surfacePlot)">
                                <img :src="scope.row.surfacePlot"/>
                            </div>
                            <p class="course-title">{{scope.row.title}}</p>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="courseTypeText"
                        label="课程类型"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="planPeriodNum"
                        label="课时数"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="isFreeText"
                        label="是否收费"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="sellingPriceText"
                        label="价格"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="crowdTypeText"
                        label="适合人群"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="classifyText"
                        label="所属分类"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="createdAt"
                        label="发布时间"
                        align="center"
                        width="180"
                    ></el-table-column>
                    <el-table-column
                        prop="courseStatusText"
                        label="课程状态"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="examineStatusText"
                        label="审核状态"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="mechanismName"
                        label="机构"
                        align="center"
                        width="200"
                    ></el-table-column>
                    <el-table-column
                        label="操作"
                        align="center"
                        min-width="200"
                    >
                        <template slot-scope="scope">
                            <el-button type="text" @click="editCourse(scope.row)">
                                <i class="el-icon-edit-outline"></i>编辑
                            </el-button>
                            <el-button type="text" v-if="scope.row.courseStatus==1" @click="delCourseEvent(scope.row)">
                                <i class="el-icon-delete"></i>删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>    
            </div> 
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>     
        </div>   
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage> 
    </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import previewImage from '@/components/PreviewImage.vue'
import {namespace} from 'vuex-class'
const user1Module = namespace('user1')
@Component({
    name:'my-course-index',
    components:{previewImage}
})
export default class Index extends Vue{
    userType = 0
    oneClassifyAllList:any = []
    oneClassifyList:any = []
    oneClassifyListLoading = false
    twoClassifyList = []
    twoClassifyListLoading = false
    searchContent = ''
    courseType = ''
    isFree = ''
    crowdType = ''
    mainClassifyId = ''
    childrenClassifyId = ''
    courseStatus = ''
    examineStatus = ''
    startTime = ''
    endTime = ''
    mechanismId = ''
    pickerOptions = this.endPickerOption()
    typeOptions = [
        {label:'视频',value:1},{label:'音频',value:2},
    ]
    freeOptions = [
        {label:'收费',value:0},{label:'免费',value:1},
    ]
    peopleOptions = [
        {label:'成人',value:1},{label:'少儿',value:2},
    ]
    courseStatusOptions = [
        {label:'上架',value:2},{label:'草稿',value:1},{label:'下架',value:3},
    ]
    auditingStatusOptions = [
        {label:'待审核',value:1},
        {label:'审核中',value:2},
        {label:'编辑中',value:3},
        {label:'拒绝',value:4},
        {label:'上架拒绝',value:5},
        {label:'更新拒绝',value:6},
        {label:'通过',value:7}
    ]
    mechanismOptions:any = []
    pageNo = 1
    pageSize = 20
    total = 20
    pages = 1
    loading = false;
    tableData = []
    showFlag = false;
    srcList:any = []
    @user1Module.State('userInfo') userInfo:any
    @Watch('crowdType')
        onCrowdTypeChanged(cur:number){
            this.mainClassifyId = ''
            this.childrenClassifyId = ''
            if(cur==1){
                this.oneClassifyList = this.oneClassifyAllList.manClassifies.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                });        
            }else{
                this.oneClassifyList = this.oneClassifyAllList.childClassifies.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                });        
            }
        }
    @Watch('pageNo')
        onPageNoChanged(cur:number){
            if(cur>0){
                this.getCourseList()
            }
        }    
    endPickerOption(){
        return {
            disabledDate:(time:any)=>{
            if(this.startTime){
                const startYestoday = new Date(this.startTime).setDate(new Date(this.startTime).getDate() - 1)
                const endYestoday = new Date().setDate(new Date().getDate());
                return time.getTime() < new Date(startYestoday).getTime()||time.getTime()>new Date(endYestoday).getTime()
            }else{
                const endYestoday = new Date().setDate(new Date().getDate());
                return time.getTime()>new Date(endYestoday).getTime()
                }
            }
        }
    }
    created(){
        if(this.userInfo.userId){
            this.userType = this.userInfo.type
            this.mechanismId = this.userInfo.mechanismId>0?this.userInfo.mechanismId:''
        }
        this.getSearchMechanismList()
        this.getOneClassifyList()
        this.getCourseList()
    }
    /**
     * 获取课程列表
     */
    async getCourseList(){
        this.loading = true;
        const query = {
            params:{
                searchContent:this.searchContent,
                courseType:this.courseType==''?-1:this.courseType,
                isFree:this.isFree==''?-1:this.isFree,
                crowdType:this.crowdType==''?-1:this.crowdType,
                mainClassifyId:this.mainClassifyId==''?-1:this.mainClassifyId,
                childrenClassifyId:this.childrenClassifyId==''?-1:this.childrenClassifyId,
                courseStatus:this.courseStatus==''?-1:this.courseStatus,
                examineStatus:this.examineStatus==''?-1:this.examineStatus,
                startTime:this.startTime,
                endTime:this.endTime,
                mechanismId:this.mechanismId,
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        }
        if(query.params.childrenClassifyId!=-1){
            query.params.mainClassifyId = -1
        }
        const res = await this.$http.get(this.$server.coursePage,query);
        this.loading = false;
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.tableData = res.data.list.map((item:any,index:number)=>{
                const temp1:any = this.typeOptions.find((option:any)=>option.value==item.courseType);
                item.courseTypeText = temp1.label;
                const temp2:any = this.freeOptions.find((option:any)=>option.value==item.isFree);
                item.isFreeText = temp2.label;
                item.sellingPriceText = `￥${item.sellingPrice}`;
                const temp3:any = this.peopleOptions.find((option:any)=>option.value==item.crowdType);
                item.crowdTypeText = temp3.label;
                item.classifyText = item.twoClassifyList?`${item.oneClassifyList[0].classifyName}-${item.twoClassifyList[0].classifyName}`:`${item.oneClassifyList[0].classifyName}`
                const temp4:any = this.courseStatusOptions.find((option:any)=>option.value==item.courseStatus);
                item.courseStatusText = temp4.label;
                const temp5:any = this.auditingStatusOptions.find((option:any)=>option.value==item.examineStatus);
                item.examineStatusText = temp5.label;
                item.sortId = (this.pageNo-1)*this.pageSize+index+1;
                return item;
            })
        }
    }
    /**
     * 获取机构列表
     */
    async getSearchMechanismList(){
        const query = {
            params:{
                pageNo:1,
                pageSize:100
            }
        }
        const res = await this.$http.get(this.$server.getSearchMechanismList,query);
        if(res.code==200){
            this.mechanismOptions = res.data.list.map((item:any)=>{
                return {
                    value:item.id,
                    label:item.mechanismName
                }
            })
        }
    }
    /**
     * 获取一级分类
     */
    async getOneClassifyList(){
        this.oneClassifyListLoading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getOneClassifyList,query)
        this.oneClassifyListLoading = false;
        if(res.code==200){
            this.oneClassifyAllList = res.data;
        }
    }
    /**
     * 下拉框获取一级分类的id
     */
    getMainClassifyId(){
        if(this.mainClassifyId){
            this.getTwoClassifyList();
            this.twoClassifyList = [];
            this.childrenClassifyId = ''
        }
    }
    /**
     * 根据一级分类获取二级分类
     */
    async getTwoClassifyList(){
        this.twoClassifyListLoading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(`${this.$server.getTwoClassifyList}/${this.mainClassifyId}`,query)
        this.twoClassifyListLoading = false;
        if(res.code==200){
            if(res.data.length>0){
                this.twoClassifyList = res.data.map((item:any)=>{
                    return {
                        label:item.name,
                        value:item.id
                    }
                })  
            }else{
                this.twoClassifyList = []
            }
        }
    }
    /**
     * 搜索
     */
    search(){
        this.pageNo = 0;
        this.$nextTick(()=>{
            this.pageNo = 1;
        })
    }
    /**
     * 预览图片
     */
    previewImageEvent(url:string){
        this.showFlag = true;
        this.srcList = [url]
    }
    /**
     * 去编辑课程
     */
    editCourse(obj:any){
        this.$router.push({
            path:'/index/course/myCourse/update',
            query:{id:obj.id}
        })
    }
    /**
     * 删除课程
     */
    delCourseEvent(obj:any){
        this.$confirm(`确定删除当前课程`, {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal:false,
            closeOnPressEscape:false,
            center:true
        }).then(() => {
            this.delCourse(obj.id)
        }).catch(()=>{
            //
        })
    }
    /**
     * 删除课程
     */
    async delCourse(id:number){
        this.loading = true;
        const res = await this.$http.post(`${this.$server.courseDel}/${id}`,{});
        this.loading = false;
        if(res.code==200){
            this.$message.success('课程删除成功');
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = 1;
            })
        }
    }
}
</script>
<style lang="scss" scoped>
    .my-course-page{
        background: #fff;
        .search-area{
            font-size: 0;
            >div{
                display: inline-block;
                vertical-align: middle;
            }
            .date-picker-box{
                font-size: 14px;
                margin-top:20px;
                >p{
                    margin:0 10px;
                }
                >p,>div{
                display: inline-block;
                vertical-align: middle;
                }
                /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
                width: 100px;
                }
                /deep/ .el-input__inner{
                width: 100px;
                padding: 0;
                text-align: center;
                }
                /deep/ .el-input__prefix{
                display: none;
                }
            }
            .keyword-box{
                width: 234px;
            }
            .type-select-box{
                margin:0 10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .free-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 64px;
                }
            }
            .people-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 64px;
                }
            }
            .classify-one-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .classify-two-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .course-status-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .auditing-status-select-box{
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .mechanism-select-box{
                margin:20px 0 0 10px;
                /deep/ .el-input{
                    width: 128px;
                }
            }
            .search-btn{
                margin-top:20px;
                margin-left: 10px;
                padding: 8px 9px;
                display: inline-block;
                vertical-align: middle;
                color:#fff;
                font-size: 14px;
            }
            .handle-btns{
                float: right;
                margin:20px 8px 0 0;
                button{
                    padding: 8px 9px;
                    display: inline-block;
                    vertical-align: middle;
                    color:#fff;
                    font-size: 14px;
                }
            }
        }
        .table-container{
            width: 100%;
            margin-top:20px;
            .surface-box{
                width: 118px;
                height: 66px;
                position: relative;
                overflow: hidden;
                display: inline-block;
                border-radius: 6px;
                margin-top:10px;
                img{
                    max-width: 100%;
                    position: absolute;
                    top:50%;
                    left: 50%;
                    transform: translate(-50%,-50%);
                    cursor: pointer;
                }
            }
            .course-title{
                height: 19px;
                color: #666660;
                line-height: 19px;
            }
        }
    }
</style>