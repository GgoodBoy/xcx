<template>
    <div class="auditing-course-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">课程</el-breadcrumb-item>
            <el-breadcrumb-item>课程审核</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入课程标题或描述" clearable></el-input>
                </div>
                <div class="type-select-box">
                    <el-select placeholder="课程类型" clearable>
                        <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="free-select-box">
                    <el-select placeholder="收费" clearable>
                        <el-option
                        v-for="item in freeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="people-select-box">
                    <el-select placeholder="人群" clearable>
                        <el-option
                        v-for="item in peopleOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="classify-one-select-box">
                    <el-select placeholder="一级分类" clearable>
                        <el-option
                        v-for="item in classifyOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="classify-two-select-box">
                    <el-select placeholder="一级分类" clearable>
                        <el-option
                        v-for="item in classifySecondOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="course-status-select-box">
                    <el-select placeholder="课程状态" clearable>
                        <el-option
                        v-for="item in courseStatusOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="auditing-status-select-box">
                    <el-select placeholder="审核状态" clearable>
                        <el-option
                        v-for="item in auditingStatusOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="date-picker-box">
                    <el-date-picker
                        v-model="beginAt"
                        type="date"
                        format="yyyy-MM-dd"
                        value-format="yyyy-MM-dd"
                        placeholder="开始时间">
                    </el-date-picker>
                    <p>至</p>
                    <el-date-picker
                        v-model="endAt"
                        type="date"
                        format="yyyy-MM-dd"
                        value-format="yyyy-MM-dd"
                        placeholder="结束时间">
                    </el-date-picker>
                </div>
                <div class="mechanism-select-box">
                    <el-select placeholder="所属机构" clearable>
                        <el-option
                        v-for="item in mechanismOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <el-button class="search-btn" v-btn-blur type="primary" @click="search">
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <div class="handle-btns">
                    <el-button class="add-btn" v-btn-blur type="primary" >
                        <i class="el-icon-plus"></i>
                        发布新课
                    </el-button>
                    <el-button class="auditing-btn" v-btn-blur type="primary" >
                        课程审核
                    </el-button>
                </div>
            </div>
            <div class="table-container" v-loading="loading">
                <el-table
                :data="tableData"
                style="width: 100%"
                :fit="true"
                border
                header-row-class-name="table-header">
                    <el-table-column
                        prop="sortId"
                        label="序号"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        label="课程名称"
                        align="center"
                        width="160"
                    >
                        <template>
                            <div class="surface-box">
                                <img />
                            </div>
                            <p>课程名称</p>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="type"
                        label="课程类型"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="num"
                        label="课时数"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="freeText"
                        label="是否收费"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="price"
                        label="价格"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="people"
                        label="适合人群"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="classify"
                        label="所属分类"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="time"
                        label="发布时间"
                        align="center"
                        width="180"
                    ></el-table-column>
                    <el-table-column
                        prop="time"
                        label="课程状态"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="auditing"
                        label="审核状态"
                        align="center"
                        width="80"
                    ></el-table-column>
                    <el-table-column
                        prop="jigou"
                        label="机构"
                        align="center"
                        width="160"
                    ></el-table-column>
                </el-table>    
            </div> 
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>     
        </div>    
    </div>
</template>
<script lang="ts">
import { Component,Vue} from 'vue-property-decorator'
@Component({
    name:'auditing-course-index'
})
export default class Index extends Vue{
    typeOptions = [
        {label:'视频',value:1},{label:'音频',value:2},
    ]
    freeOptions = [
        {label:'收费',value:1},{label:'免费',value:2},
    ]
    peopleOptions = [
        {label:'成人',value:1},{label:'少儿',value:2},
    ]
    classifyOptions = []
    classifySecondOptions = []
    courseStatusOptions = []
    auditingStatusOptions = []
    beginAt = ''
    endAt = ''
    pageNo = 1
    pageSize = 20
    total = 20
    pages = 1
}
</script>
<style lang="scss" scoped>
    .auditing-course-page{
        .search-area{
            font-size: 0;
            >div{
                display: inline-block;
                vertical-align: middle;
            }
            .date-picker-box{
                font-size: 14px;
                margin-top:20px;
                >p{
                    margin:0 10px;
                }
                >p,>div{
                display: inline-block;
                vertical-align: middle;
                }
                /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
                width: 100px;
                }
                /deep/ .el-input__inner{
                width: 100px;
                padding: 0;
                text-align: center;
                }
                /deep/ .el-input__prefix{
                display: none;
                }
            }
            .keyword-box{
                width: 208px;
            }
            .type-select-box{
                margin:0 10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .free-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 64px;
                }
            }
            .people-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 64px;
                }
            }
            .classify-one-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .classify-two-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .course-status-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .auditing-status-select-box{
                margin-right:10px;
                /deep/ .el-input{
                    width: 92px;
                }
            }
            .mechanism-select-box{
                margin:20px 10px 0 10px;
                /deep/ .el-input{
                    width: 128px;
                }
            }
            .search-btn{
                margin-top:20px;
                padding: 8px 9px;
                display: inline-block;
                vertical-align: middle;
                color:#fff;
                font-size: 14px;
            }
            .handle-btns{
                margin:20px 0 0 238px;
                button{
                    padding: 8px 9px;
                    display: inline-block;
                    vertical-align: middle;
                    color:#fff;
                    font-size: 14px;
                }
            }
        }
        .table-container{
            width: 100%;
            margin-top:20px;
        }
    }
</style>