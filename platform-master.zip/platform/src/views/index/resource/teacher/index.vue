<template>
  <div class="teahcer-page" v-loading="loading">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index/resource/teacher' }">资源库</el-breadcrumb-item>
      <el-breadcrumb-item>教师库</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="content">
      <div class="search-area">
        <div class="keyword-box">
          <el-input placeholder="请输入教师姓名" v-model="name" clearable></el-input>
        </div>
        <div class="select-box">
          <el-select v-model="mechanismId" placeholder="所属机构" clearable :popper-append-to-body="false">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </div>
        <el-button class="search-btn primary" v-btn-blur @click="search">
          <i class="el-icon-search"></i>
          查询
        </el-button>
        <el-button class="add-btn" type="primary" @click="$router.push('/index/resource/teacher/update')">
          <i class="el-icon-plus"></i>
          添加教师
        </el-button>
      </div>
      <div class="table-container">
        <el-table
          :data="tableData"
          style="width: 100%"
          :fit="true"
          stripe
          border
          header-row-class-name="table-header">
          <!-- <af-table-column label="序号" align="center" prop="order"></af-table-column>
          <af-table-column label="真实姓名" align="center" prop="name"></af-table-column>
          <af-table-column label="职称" align="center" prop="job"></af-table-column>
          <af-table-column label="简介" align="center"  prop="intro"></af-table-column>
          <af-table-column label="所属机构" align="center" prop="apartment"></af-table-column> -->
          <el-table-column
            prop="sortId"
            label="序号"
            align="center"
            width="60"
          ></el-table-column>
          <el-table-column
            prop="name"
            label="真实姓名"
            align="center"
          ></el-table-column>
          <el-table-column
            label="头像"
            align="center"
            width="60"
          >
            <template slot-scope="scope">
              <img class="avatar" :src="scope.row.avatar" @click="previewImg(scope.row.avatar)"/>
            </template>
          </el-table-column>
          <el-table-column
            prop="professionalTitle"
            label="职称"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="intro"
            label="简介"
            align="center"
            min-width="200"
          ></el-table-column>
          <el-table-column
            prop="mechanismName"
            label="所属机构"
            align="center"
          ></el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template slot-scope="scope">
              <el-button type="text" @click="editTeacherEvent(scope.row)">
                <i class="el-icon-edit-outline"></i>编辑
              </el-button>
              <el-button type="text" @click="delTeacherEvent(scope.row)">
                <i class="el-icon-delete"></i>删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>  
      </div>
      <div class="page-container">
        <el-pagination
          layout="prev, pager, next"
          :current-page.sync="pageNo"
          :page-size="pageSize"
          :total="total">
        </el-pagination>
        <p class="pagesize">共{{pages}}页</p>
      </div>  
    </div>
    <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>      
  </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import previewImage from '@/components/PreviewImage.vue'
@Component({
  name:'teahcer',
  components:{
    previewImage
  }
})
export default class MyComponent extends Vue {
  name = '';
  mechanismId:number|string = '';
  options:any = []
  pageNo = 1;
  pageSize = 10;
  total = 10;
  pages = 1;
  loading = false;
  tableData = []
  showFlag = false
  srcList:any = []
  @Watch('pageNo')
    onPageNoChanged(cur:number){
      if(cur>0){
        this.getList();
      }
    }
  created(){
    this.getList()
    this.getSearchMechanismList()
  }
  /**
   * 获取老师列表
   */
  async getList(){
    this.loading = true;
    const query = {
      params:{
        name:this.name,
        mechanismId:this.mechanismId,
        pageNo:this.pageNo,
        pageSize:this.pageSize
      }
    }
    const res = await this.$http.get(this.$server.teacherList,query)
    this.loading = false;
    if(res.code==200){
      this.total = res.data.total;
      this.pages = res.data.pages;
      this.tableData = res.data.list;
      this.tableData.forEach((item:any,index)=>{
        item.sortId = (this.pageNo-1)*this.pageSize+index+1;
      })
    }
  }
  search(){
    this.pageNo = 0;
    this.$nextTick(()=>{
      this.pageNo = 1;
    })
  }
  /**
   * 获取机构列表
   */
  async getSearchMechanismList(){
    const query = {
      params:{
        pageNo:1,
        pageSize:100
      }
    }
    const res = await this.$http.get(this.$server.getSearchMechanismList,query);
    if(res.code==200){
      this.options = res.data.list.map((item:any)=>{
        return {
          value:item.id,
          label:item.mechanismName
        }
      })
    }
  }
  /**
   * 删除老师
   */
  delTeacherEvent(obj:any){
    this.$confirm('确定删除当前教师信息', '', {
      confirmButtonText: '通过',
      cancelButtonText: '取消',
      type: 'error',
      center:true
    }).then(() => {
      this.delTeacher(obj)
    }).catch(() => {
      //do something  
    });
  }
  /**
   * 执行删除老师
   */
  async delTeacher(obj:any){
    const res = await this.$http.post(`${this.$server.deleteTeacher}/${obj.id}`,{})
    if(res.code==200){
      this.$message.success('教师删除成功')
      this.pageNo = 0;
      this.$nextTick(()=>{
        this.pageNo = 1;
      })
    }
  }
  /**
   * 去编辑教师信息
   */
  editTeacherEvent(obj:any){
    this.$router.push({
      path:'/index/resource/teacher/update',
      query:{
        id:obj.id
      }
    })
  }
  /**
   * 预览视频封面图
   */
  previewImg(img:string|null){
    const srcList = []
    srcList.push(img)
    this.srcList = srcList;
    this.showFlag = true;
  }
}
</script>
<style lang="scss" scoped>
  .teahcer-page{
    background: #fff;
    .search-area{
      font-size: 0;
      >div{
        display: inline-block;
        vertical-align: middle;
      }
      .keyword-box{
        width: 208px;
      }
      .select-box{
        margin:0 20px;
        /deep/ .el-input{
          width: 128px;
        }
      }
      .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
      }
      .add-btn{
        padding: 8px 13px;
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        color:#fff;
        margin-left: 355px;
      }
    }
    .table-container{
      width: 100%;
      overflow-y:hidden;
      overflow-x:auto;
      margin-top:20px;
      .avatar{
        width: 34px;
        height: 34px;
        border-radius: 50%;
        cursor: pointer;
      }
      /deep/ .el-button--text{
        color:#666;
        i{
          color:#C30D23;
        }
      }
    }
  }
</style>
