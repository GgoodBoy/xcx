<template>
    <div class="teacher-update-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">资源库</el-breadcrumb-item>
            <el-breadcrumb-item>添加教师</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content clearfix" v-loading="loading2">
            <div class="form-box">
                <el-form ref="form" :model="form"  label-width="68px" :rules="rules" >
                    <el-form-item label="真实姓名" class="form-name" prop="name">
                        <el-input placeholder="请输入员工真实姓名" v-model.trim="form.name" maxlength="10" @focus="resetRules"></el-input>
                        <p class="num">{{form.name.length}}/10</p>
                    </el-form-item>
                    <el-form-item label="岗位" class="form-job" label-width="68px">
                        <p>教师</p>
                    </el-form-item>
                    <el-form-item label="职称" class="form-professional" prop="professionalTitle">
                        <el-input placeholder="请输入职称描述" v-model.trim="form.professionalTitle" maxlength="16" @focus="resetRules"></el-input>
                        <p class="num">{{form.professionalTitle.length}}/16</p>
                    </el-form-item>
                    <el-form-item label="简介" class="form-intro" >
                        <el-input type="textarea" v-model.trim="form.intro" resize="none" :autosize="{ minRows: 9}" maxlength="200"></el-input>
                        <p class="num">{{form.intro.length}}/200</p>
                    </el-form-item>
                </el-form>
                <div class="btns clearfix">
                    <el-button class="cancel" @click="$router.go(-1)">取消</el-button>
                    <el-button type="primary" class="save" @click="saveEvent">保存</el-button>
                </div>
            </div>
            <div class="upload-box">
                <div class="avatar-box" @click="form.avatar.length>0?preview():uploadFile()" v-loading="loading1">
                    <template v-if="form.avatar.length>0">
                        <img :src="form.avatar" class="avatar"/>
                    </template>
                </div>
                <p class="edit" v-show="form.avatar.length>0" @click="uploadFile">
                    <i class="el-icon-edit"></i>
                    修改
                </p>
                <p class="tips">图片尺寸为500*500px 大小不超过1MB</p>
                <input type="file" name="file" class="file-upload" ref="uploadInput" @change="getFile($event)" @click="emptyFile($event)"/>
            </div>
        </div>
        <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
import previewImage from '@/components/PreviewImage.vue'
@Component({
  name:'teahcerUpdate',
  components:{previewImage}
})
export default class MyComponent extends Vue {
    showFlag = false;
    srcList:any = []
    form = {
        name:'',
        professionalTitle:'',
        intro:'',
        avatar:''
    }
    rules = {
        name:[
            { required: true, message: '姓名不能为空', trigger: 'blur' },
            { min: 1, max: 10, message: '姓名限10个字以内', trigger: 'blur' }
        ],
        professionalTitle:[
            { required: true, message: '请输入教师职称', trigger: 'blur' },
            { min: 1, max: 16, message: '请输入教师职称', trigger: 'blur' }
        ],
    }
    loading1 = false;
    loading2 = false;
    created(){
        if(this.$route.query&&this.$route.query.id){
            this.teacherDetails()
        }
    }
    /**
     * 获取老师信息
     */
    async teacherDetails(){
        this.loading2 = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(`${this.$server.teacherDetails}/${this.$route.query.id}`,query)
        this.loading2 = false;
        if(res.code==200){
            const {name,professionalTitle,intro,avatar} = res.data;
            this.form = {
                name,professionalTitle,intro,avatar
            }
            const srcList = [];
            srcList.push(res.data.resourceUrl);
            this.srcList = srcList;
        }
    }
    /**
     * 预览图片
     */
    preview(){
        this.showFlag = true;
    }
    /**
     * 上传事件
     */
    uploadFile(){
        if(this.loading1) return;
        const dom = this.$refs.uploadInput as HTMLElement;
        dom.click()
    }
    emptyFile(e:any){
        e.target.value = ''
    }
    /**
     * 获取文件并上传
     */
    getFile(e:any){
        const files = e.target.files || e.dataTransfer.files;
        const fileData = files[0];
        if (!/(\.png|\.jpg|\.jpeg)$/.test(fileData.name.toLowerCase())) {
            this.$message.error('图片格式有误，请上传JPEG或PNG格式');
            return;
        }
        if(fileData.size>1024*1024){
            this.$message.error('图片大小不能超过1M');
            return;
        }
        const reader = new FileReader();
        reader.readAsDataURL(fileData);
        reader.onload =(e:any)=>{
            const data = e.target.result;
            const image = new Image();
            image.onload = ()=>{
                const width = image.width;
                const height = image.height;
                if(width!=500||height!=500){
                    this.$message.error('请上传500*500的图片');
                    return;
                }
                this.loading1 = true;
                const params = new FormData();
                params.append('file',fileData)
                const config = {
                    headers: {'Content-Type': 'multipart/form-data'}
                }
                this.$http.post(this.$server.uploadPic,params,config).then((res:any)=>{
                    if(res.code==200){
                        this.form.avatar = res.data.resourceUrl;
                        const srcList = [];
                        srcList.push(res.data.resourceUrl);
                        this.srcList = srcList;
                    }
                }).finally(()=>{
                    this.loading1 = false;
                })
            }
            image.src= data;
        }
    }
    /**
     * 清空验证
     */
    resetRules(){
        const form:any = this.$refs.form as HTMLElement;
        form.clearValidate();
    }
    /**
     * 保存
     */
    saveEvent(){
        const form:any = this.$refs.form as HTMLElement;
        form.validate((valid:any) => {
            if (valid) {
                if(this.form.avatar.length==0){
                    this.$message.error('请上传头像');
                    return;
                }
                if(this.$route.query.id){
                    this.editTeacher()
                }else{
                    this.addTeacher()
                }
            } else {
                return false;
            }
        });
    }
    /**
     * 添加教师
     */
    async addTeacher(){
        this.loading2 = true;
        const query = Object.assign({},this.form)
        const res = await this.$http.post(this.$server.addTeacher,query);
        this.loading2 = false;
        if(res.code==200){
            this.$message.success('老师添加成功');
            this.$router.push('/index/resource/teacher')
        }
    }
    /**
     * 编辑
     */
    async editTeacher(){
        this.loading2 = true;
        const query = Object.assign({},this.form,{id:this.$route.query.id})
        const res = await this.$http.post(this.$server.updateTeacher,query);
        this.loading2 = false;
        if(res.code==200){
            this.$message.success('老师信息修改成功');
            this.$router.push('/index/resource/teacher')
        }
    }
}
</script>
<style lang="scss" scoped>
    .teacher-update-page{
        background: #fff;
        .content{
            margin-top:10px;
            .form-box{
                float: left;
                width: calc(100% - 302px);
                margin-left: 12px;
                /deep/ .el-form-item__label{
                    font-weight: bold;
                    text-align: justify;
                    text-align-last: justify;
                    margin-right: 10px;
                    color:#333;
                }
                .form-name,.form-professional,.form-intro{
                    .num{
                        display: inline-block;
                        vertical-align: middle;
                        color:#666666;
                        margin:0 10px 0 10px;
                    }
                }
                .form-intro{
                    .num{
                        position: relative;
                        top:10px;
                    }
                }
                /deep/ .el-input{
                    width: 442px;
                    display: inline-block;
                    vertical-align: middle;
                    .el-input__inner{
                        width: 442px;
                        padding: 0 10px;
                        background: #FCFCFC;
                    }
                }
                /deep/ .el-form-item{
                    margin-bottom:20px;
                    .el-form-item__error{
                        padding: 4px 12px;
                    }
                }
                /deep/ .el-form-item__content{
                    margin-left: 78px!important;
                    .el-textarea__inner,.el-textarea{
                        width: 442px;
                        background: #FCFCFC;
                        &.el-textarea__inner{
                            padding: 5px 10px;
                        }
                    }
                }
                /deep/ .el-form-item__label{
                    position: relative;
                    &::before{
                        position: absolute;
                        left:-13px;
                        top:3px;
                    }
                }
                .btns{
                    margin:40px 0;
                    /deep/ .el-button{
                        padding: 13px 37px;
                        float: right;
                    }
                    .cancel{
                        margin:0 78px 0 20px;
                    }
                }
            }
            .upload-box{
                float: left;
                width: 290px;
                .avatar-box{
                    height: 100px;
                    width: 100px;
                    border-radius: 50%;
                    overflow: hidden;
                    box-shadow: 0 0 5px #eee;
                    margin:0 auto;
                    cursor: pointer;
                    .avatar{
                        width: 100%;
                        height: 100%;
                    }
                }
                .edit{
                    margin:15px auto 0;
                    text-align: center;
                    color:#333;
                    font-size: 14px;
                    cursor: pointer;
                }
                .tips{
                    color:#999;
                    font-size: 12px;
                    width: 124px;
                    margin:15px auto;
                    text-align: center;
                }
                .file-upload{
                    opacity: 0;
                    position: absolute;
                    right: 10000px;
                }
            }
        }
    }
</style>