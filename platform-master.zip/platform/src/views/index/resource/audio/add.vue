<template>
    <div class="audio-add-page">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">资源库</el-breadcrumb-item>
        <el-breadcrumb-item>音频库</el-breadcrumb-item>
        <el-breadcrumb-item>添加音频</el-breadcrumb-item>
      </el-breadcrumb>
      <div class="content">
        <div class="tabs" :class="{'next':!done}">
          <div class="tab1 active">
            选择音频
          </div>
          <div class="tab2">
            上传音频
          </div>
        </div>
        <div class="list">
          <div class="list-header">
            <p class="h-name">音频名称</p>
            <p class="h-duration">音频大小</p>
            <p class="h-handle">操作</p>
          </div>
          <UploadMedia :fileType="'audio'" :videoType="'1'" :done.sync="done"></UploadMedia>
        </div>
      </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import UploadMedia from '@/components/UploadMedia.vue'
Component.registerHooks([
  'beforeRouteLeave','beforeDestroy'
]);
@Component({
  name:'videoAddPage',
  components:{UploadMedia}
})
export default class MyComponent extends Vue {
  done = true;
  changed = false;
  @Watch('done')
    onDoneChanged(cur:boolean){
      if(cur){
        window.removeEventListener('beforeunload',this.beforeunloadHandler,false)
      }else{
        if(this.changed) return;
        this.changed = true;
        window.addEventListener('beforeunload', this.beforeunloadHandler, false);
        console.log('绑定事件')
      }
    }
  beforeRouteLeave (to:any,from:any,next:any){
    if(this.done){
      next()
    }else{
      this.$confirm(`音频还未保存到音频库中，是否要离开`, {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        closeOnClickModal:false,
        closeOnPressEscape:false,
        center:true
      }).then(() => {
        next()
      }).catch(()=>{
        next(false)
      }) 
    }
    next(false)
  }
  beforeunloadHandler (e:any) {
    e = e || window.event
    if (e) {
      e.returnValue = '您的数据还没有保存，确定要离开吗'
    }
    return '您的数据还没有保存，确定要离开吗'
  }
  beforeDestroy() {
    window.removeEventListener('beforeunload',this.beforeunloadHandler,false) 
  }
}
</script>
<style lang="scss" scoped>
  .audio-add-page{
    padding-bottom:20px!important;
    background: #fff;
    .content{
      .tabs{
        font-size: 0;
        height: 40px;
        position: relative;
        &.next{
          .tab1{
            color:#333!important;
            background: url('../../../../assets/image/step_1_1.png')no-repeat 50% 50%!important;
            background-size: 100%!important;
          }  
          .tab2{
            color:#fff!important;
            background: url('../../../../assets/image/step_2_0.png')no-repeat 50% 50%!important;
            background-size: 100%!important;
          }      
        }
        .tab1,.tab2{
          height: 40px;
          line-height: 40px;
          position: absolute;
          width: 458px;
          text-align: center;
          top:0;
          &.tab1{
            background: url('../../../../assets/image/step_1_0.png')no-repeat 50% 50%;
            background-size: 100%;
            color:#fff;
            left:0;
          }
          &.tab2{
            background: url('../../../../assets/image/step_2_1.png')no-repeat 50% 50%;
            background-size: 100%;
            right: 0;
          }
        }
      }
      .list{
        .list-header{
          height: 40px;
          line-height:40px;  
          background: #E5E5E5;
          border-radius: 6px 6px 0px 0px;
          font-size: 0;
          margin-top:20px;
          p{
            display: inline-block;
            vertical-align: middle;
            font-size: 14px;
            color:#333;
            width: 25%;
            font-weight: bold;
            text-align: center;
            &.h-name{
              width:50%;
              text-align: left;
              padding-left: 5%;
            }
            &.h-handle{
              text-align: right;
              padding-right:6%;
            }
          }
        }
      }
    }
  }
</style>
