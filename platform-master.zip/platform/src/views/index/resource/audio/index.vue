<template>
  <div class="audio-page" v-loading="loading">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index/resource/audio' }">资源库</el-breadcrumb-item>
      <el-breadcrumb-item>音频库</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="content">
      <div class="search-area">
        <div class="keyword-box">
          <el-input placeholder="请输入音频名称" v-model="title" clearable></el-input>
        </div>
        <div class="date-picker-box">
          <el-date-picker
            v-model="beginAt"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="开始时间">
          </el-date-picker>
          <p>至</p>
          <el-date-picker
            v-model="endAt"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="结束时间">
          </el-date-picker>
        </div>
        <div class="select-box">
          <el-select v-model="mechanismId" placeholder="所属机构" clearable>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </div>
        <el-button class="search-btn primary" v-btn-blur @click="search">
          <i class="el-icon-search" ></i>
          查询
        </el-button>
        <el-button class="add-btn" type="primary" @click="$router.push('/index/resource/audio/add')">
          <i class="el-icon-plus"></i>
          添加音频
        </el-button>
      </div>
      <div class="table-container" >
        <el-table
          :data="tableData"
          style="width: 100%"
          :fit="true"
          border
          header-row-class-name="table-header">
          <el-table-column
            prop="sortId"
            label="序号"
            align="center"
            width="60"
          ></el-table-column>
          <el-table-column
            prop="title"
            label="音频名称"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="fileSize"
            label="大小"
            align="center"
            width="88"
          ></el-table-column>
          <el-table-column
            prop="durationTemp"
            label="时长"
            align="center"
            width="80"
          ></el-table-column>
          <el-table-column
            prop="createdAt"
            label="发布时间"
            align="center"
            width="180"
          ></el-table-column>
          <el-table-column
            prop="mechanismName"
            label="所属机构"
            align="center"
          ></el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template slot-scope="scope">
              <el-button type="text" @click="tryListen(scope.row)">
                <i class="el-icon-headset"></i>试听
              </el-button>
              <el-button type="text" @click="delAudioEvent(scope.row)">
                <i class="el-icon-delete"></i>删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>  
      </div>
      <div class="page-container">
        <el-pagination
          layout="prev, pager, next"
          :current-page.sync="pageNo"
          :page-size="pageSize"
          :total="total">
        </el-pagination>
        <p class="pagesize">共{{pages}}页</p>
      </div>  
    </div>
    <el-dialog
      :visible.sync="dialogVisible"
      top="30vh"
      width="612.5px"
      custom-class="audio-dialog"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      center
    >   
      <div class="audio-player-box">
        <p class="audio-title">{{targetTitle}}</p>
        <div id="player-con"></div>
        <template v-if="audioLoading">
          <span class="loading" v-loading="audioLoading" @click="pausePlayer"></span>
        </template>
      </div>  
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { Component,Vue,Watch } from 'vue-property-decorator'
const formatTime = (time:any)=>{
  let h:any = '',m:any = '',s:any = '';
  const timeTemp = Math.abs(time)
  if(timeTemp>=3600){
    h = Math.floor(timeTemp / 3600) < 10 ? '0'+Math.floor(timeTemp / 3600) : Math.floor(timeTemp / 3600);
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${h}:${m}'${s}''`:`${h}:${m}'${s}''`
  }else if(timeTemp<3600&&timeTemp>=60){
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${m}'${s}''`:`${m}'${s}''`
  }else{
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${s}''`:`${s}''`
  }
}
@Component({
  name:'audioPage'
})
export default class MyComponent extends Vue {
  title = '';
  beginAt = '';
  endAt = '';
  mechanismId = '';
  loading = false;
  pageNo = 1;
  pageSize = 20;
  total = 20;
  pages = 1;
  options = []
  tableData = []
  dialogVisible = false;
  targetId = -1
  targetTitle = ''
  source = ''
  player:any = ''
  audioLoading = false;
  @Watch('pageNo')
    onPageNoChanged(cur:number){
      if(cur>0){
        this.getAudioList()
      }
    }
  @Watch('targetId')
    ontargetIdChanged(cur:number){
      if(cur>=0){
        this.getResoursePlayUrl()
      }
    }  
  @Watch('dialogVisible')
    onDialogVisibleChanged(cur:boolean){
      if(!cur){
        this.targetId = -1
        this.player.dispose()
        this.player = ''
        this.audioLoading = false;
      }  
    }      
  created(){
    this.getAudioList();
    this.getSearchMechanismList();
  }
  /**
   * 获取机构列表
   */
  async getSearchMechanismList(){
    const query = {
      params:{
        pageNo:1,
        pageSize:100
      }
    }
    const res = await this.$http.get(this.$server.getSearchMechanismList,query);
    if(res.code==200){
      this.options = res.data.list.map((item:any)=>{
        return {
          value:item.id,
          label:item.mechanismName
        }
      })
    }
  }
  /**
   * 获取音频列表
   */
  async getAudioList(){
    this.loading = true;
    const query = {
      params:{
        title:this.title,
        beginAt:this.beginAt,
        endAt:this.endAt,
        mechanismId:this.mechanismId,
        pageNo:this.pageNo,
        pageSize:this.pageSize
      }
    }
    const res = await this.$http.get(this.$server.getAudioList,query);
    this.loading = false;
    if(res.code==200){
      this.total = res.data.total;
      this.pages = res.data.pages;
      this.tableData = res.data.list;
      this.tableData.forEach((item:any,index:number)=>{
        item.durationTemp = formatTime(item.duration);
        item.sortId = (this.pageNo-1)*this.pageSize+index+1;
      })
    }
  }
  /**
   * 搜索
   */
  search(){
    this.pageNo = 0;
    this.$nextTick(()=>{
      this.pageNo = 1;
    })
  }
  /**
   * 删除音频事件
   */
  delAudioEvent(obj:any){
    this.$confirm('确定删除当前音频文件', '', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'error',
      center:true
    }).then(() => {
      this.delAudio(obj.id)
    }).catch(() => {
      //do something  
    });
  }
  /**
   * 删除
   */
  async delAudio(id:number){
    this.loading = true;
    const res = await this.$http.post(`${this.$server.deleteAudio}/${id}`,{});
    this.loading = false;
    if(res.code==200){
      this.$message.success('音频删除成功')
      this.pageNo = 0;
      this.$nextTick(()=>{
        this.pageNo = 1;
      })
    }
  }
  tryListen(obj:any){
    this.targetId = obj.id;
    this.targetTitle = obj.title;
  }
  async getResoursePlayUrl(){
    this.dialogVisible = true;
    const query = {
      courseId:443,
      definitionType:1,
      periodId:1298
    }
    const res = await this.$http.post('/mobileCourses/getResoursePlayUrl',query);
    if(res.status==200){
      this.source = res.content;
      this.$nextTick(()=>{
        this.createPlayer()
      })
    }
  }
  createPlayer(){
    const props = {
      id: 'player-con',
      width: '100%',
      height: '100%',
      preload:true,
      source:this.source,
      mediaType:'video',
      extraInfo:{
        'x5-playsinline':''
      },
      autoplay:true,
      rePlay:true,
      controlBarVisibility:'always',
    }
    const Aliplayer = (window as any).Aliplayer;
    this.player = new Aliplayer(props);
    this.player.on('play',()=>{
      this.audioLoading = false;
    })
    this.player.on('pause',()=>{
      this.audioLoading = false;
    })
    this.player.on('playing',()=>{
      this.audioLoading = false;
    })
    this.player.on('canplay',()=>{
      this.audioLoading = false;
    })
    this.player.on('waiting',()=>{
      this.audioLoading = true;
    })
  }
  pausePlayer(){
    this.player.pause()
  }
}
</script>
<style lang="scss" scoped>
  .audio-page{
    background: #fff;
    .search-area{
      font-size: 0;
      >div{
        display: inline-block;
        vertical-align: middle;
      }
      .keyword-box{
        width: 208px;
      }
      .date-picker-box{
        margin:0 20px;
        >p{
          margin:0 10px;
        }
        >p,>div{
          display: inline-block;
          vertical-align: middle;
        }
        /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
          width: 100px;
        }
        /deep/ .el-input__inner{
          width: 100px;
          padding: 0;
          text-align: center;
        }
        /deep/ .el-input__prefix{
          display: none;
        }
      }
      .select-box{
        margin:0 20px 0 0;
        /deep/ .el-input{
          width: 128px;
        }
      }
      .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
      }
      .add-btn{
        padding: 8px 13px;
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        color:#fff;
        margin-left: 101px;
      }
    }
    .table-container{
      width: 100%;
      margin-top:20px;
      /deep/ .el-button--text{
        color:#666;
        i{
          color:#C30D23;
        }
      }
    }
    /deep/ .audio-player-box{
      width: 562.5px;
      height: 50px;
      .audio-title{
        text-align: center;
        font-size: 16px;
        font-weight: bold;
        width: 80%;
        left:10%;
        top:20px;
        position: absolute;
      }
      video{
        visibility: hidden;
      }
      .prism-big-play-btn{
        display: none!important;
      }
      .prism-controlbar-bg{
        background: rgba(0,0,0,0.7);
      }
      .prism-animation,.prism-player .prism-loading .circle{
        display: none!important;
      }
      .prism-progress{
        width: 66%!important;
      }
      .prism-time-display .duration{
        right: 4%!important;
      }
      .loading{
        width: 28px;
        height: 28px;
        display: block;
        position: absolute;
        left: 33px;
        bottom:37px;
        z-index: 2;
        .el-loading-mask{
          background-color: transparent!important;
        }
      }
    }
  }
</style>
