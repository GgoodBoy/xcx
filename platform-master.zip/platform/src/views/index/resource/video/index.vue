<template>
  <div class="video-page"  v-loading="loading">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index/resource/video' }">资源库</el-breadcrumb-item>
      <el-breadcrumb-item>视频库</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="content">
      <div class="search-area">
        <div class="keyword-box">
          <el-input placeholder="请输入视频名称" v-model="title" clearable></el-input>
        </div>
        <div class="date-picker-box">
          <el-date-picker
            v-model="beginAt"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="开始时间">
          </el-date-picker>
          <p>至</p>
          <el-date-picker
            v-model="endAt"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="结束时间">
          </el-date-picker>
        </div>
        <div class="select-box">
          <el-select v-model="mechanismId" placeholder="所属机构" clearable>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </div>
        <el-button class="search-btn primary" v-btn-blur @click="search">
          <i class="el-icon-search"></i>
          查询
        </el-button>
        <el-button class="add-btn" type="primary" @click="$router.push('/index/resource/video/add')">
          <i class="el-icon-plus"></i>
          添加视频
        </el-button>
      </div>
      <p class="empty" v-if="list.length==0&&finished">暂无任何视频文件~</p>
      <div class="list clearfix" v-if="list.length>0&&finished">
        <div class="item" v-for="(item,index) in list" :key="item.id" :class="{'odd':index%2!=0}">
          <div class="t">
            <div class="surface" @click="previewImg(item.videoImage)">
              <img :src="item.videoImage"/>
            </div>
            <div class="info">
              <el-tooltip effect="dark" :content="item.title" placement="top-start">
                <p class="video-name text-overflow">{{item.title}}</p>
              </el-tooltip>  
              <p class="user-name">某某机构</p>
              <div class="data">
                <p class="create-time">{{item.createdAt}}</p>
                <p class="video-file-info">
                  <span class="duration">{{item.durationTemp}}</span>
                  <span>/</span>
                  <span class="size">{{item.fileSize}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="b clearfix">
            <div class="btns">
              <div class="preview" @click="targetId=item.id">
                <i class="el-icon-view"></i>
                预览
              </div>
              <div class="delete" @click="delVideoEvent(item)">
                <i class="el-icon-delete"></i>
                删除
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="page-container">
        <el-pagination
          layout="prev, pager, next"
          :current-page.sync="pageNo"
          :page-size="pageSize"
          :total="total">
        </el-pagination>
        <p class="pagesize">共{{pages}}页</p>
      </div>
    </div>
    <el-dialog
      :visible.sync="dialogVisible"
      top="30vh"
      width="612.5px"
      custom-class="video-dialog"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      center
    >   
      <div class="video-player-box">
        <div id="player-con"></div>
        <div class="speed-area">
          <p class="cur-speed" @click="speedFlag=!speedFlag">{{curSpeed.speed==1?'正常':curSpeed.speed+'x'}}</p>
          <div class="speed-list" :class="speedFlag?'open':'close'">
            <div class="speed-item" v-for="(item,index) in speedList" :class="{'active':item.active}" :key="index" @click="chooseSpeed(item)">
                <p>{{item.speed+'x'}}</p>
            </div>
          </div>
        </div>
      </div>  
    </el-dialog>
    <previewImage v-if="showFlag" :showFlag.sync="showFlag" :srcList="srcList"></previewImage>
  </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import previewImage from '@/components/PreviewImage.vue'
declare const window: Window;
const formatTime = (time:any)=>{
  let h:any = '',m:any = '',s:any = '';
  const timeTemp = Math.abs(time)
  if(timeTemp>=3600){
    h = Math.floor(timeTemp / 3600) < 10 ? '0'+Math.floor(timeTemp / 3600) : Math.floor(timeTemp / 3600);
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${h}:${m}'${s}''`:`${h}:${m}'${s}''`
  }else if(timeTemp<3600&&timeTemp>=60){
    m = Math.floor((timeTemp / 60 % 60)) < 10 ? '0' + Math.floor((timeTemp / 60 % 60)) : Math.floor((timeTemp / 60 % 60));
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${m}'${s}''`:`${m}'${s}''`
  }else{
    s = Math.floor((timeTemp % 60)) < 10 ? '0' + Math.floor((timeTemp % 60)) : Math.floor((timeTemp % 60));
    return time<0?`-${s}''`:`${s}''`
  }
}
@Component({
  name:'videoPage',
  components:{previewImage}
})
export default class MyComponent extends Vue {
  title = '';
  beginAt = '';
  endAt = '';
  mechanismId = '';
  list:any = [];
  finished = false;
  pageNo = 1;
  pageSize = 10;
  total = 10;
  pages = 1;
  loading = false;
  showFlag = false;
  srcList:any = [];
  options = []
  dialogVisible = false;
  targetId = -1
  source = ''
  player:any = ''
  speedFlag = false;
  speedList = [
    {speed:0.5,active:false},
    {speed:1,active:true},
    {speed:2,active:false},
    {speed:4,active:false},
  ]
  curSpeed = {speed:1}
  @Watch('pageNo')
    onPageNoChanged(cur:number){
      if(cur>0){
        this.getVideoList()
      }
    }
  @Watch('targetId')
    onTargetIdChanged(cur:number){
      if(cur>=0){
        this.getResoursePlayUrl()
      }
    }
  @Watch('dialogVisible')
    onDialogVisibleChanged(cur:boolean){
      if(!cur){
        this.targetId = -1
        this.player.dispose()
        this.player = ''
        this.speedList.forEach(item=>item.active = false)
        const temp:any = this.speedList.find(item=>item.speed==1)
        temp.active = true;
        this.curSpeed = {speed:1}
      }  
    }    
  created(){
    this.getVideoList()
    this.getSearchMechanismList()
  }
  /**
   * 获取机构列表
   */
  async getSearchMechanismList(){
    const query = {
      params:{
        pageNo:1,
        pageSize:100
      }
    }
    const res = await this.$http.get(this.$server.getSearchMechanismList,query);
    if(res.code==200){
      this.options = res.data.list.map((item:any)=>{
        return {
          value:item.id,
          label:item.mechanismName
        }
      })
    }
  }
  /**
   * 获取列表数据
   */
  async getVideoList(){
    this.loading = true;
    const query = {
      params:{
        title:this.title,
        beginAt:this.beginAt,
        endAt:this.endAt,
        mechanismId:this.mechanismId,
        type:1,
        pageNo:this.pageNo,
        pageSize:this.pageSize
      }
    }
    const res = await this.$http.get(this.$server.getVideoList,query);
    if(res.code==200){
      this.finished = true;
      this.total = res.data.total;
      this.pages = res.data.pages;
      this.list = res.data.list;
      this.list.forEach((item:any)=>{
        item.durationTemp = item.duration==0?`00'00`:formatTime(item.duration)
      })
    }
    this.$nextTick(()=>{
      this.loading = false;
    })
  }
  /**
   * 搜索
   */
  search(){
    this.pageNo = 0;
    this.$nextTick(()=>{
      this.pageNo = 1;
    })
  }
  /**
   * 删除视频
   */
  delVideoEvent(obj:any){
    this.$confirm('确定删除当前视频文件', '', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'error',
      center:true
    }).then(() => {
      this.delVideo(obj.id)
    }).catch(() => {
      //do something  
    });
  }
  /**
   * 删除视频
   */
  async delVideo(id:number){
    this.loading = true;
    const res = await this.$http.post(`${this.$server.deleteVideo}/${id}`,{});
    this.loading = false;
    if(res.code==200){
      this.$message.success('视频删除成功')
      this.pageNo = 0;
      this.$nextTick(()=>{
        this.pageNo = 1;
      })
    }
  }
  /**
   * 预览视频封面图
   */
  previewImg(img:string|null){
    const srcList = []
    srcList.push(img)
    this.srcList = srcList;
    this.showFlag = true;
  }
  /**
   * 获取播放地址
   */
  async getResoursePlayUrl(){
    // const query = {
    //   id:this.targetId,
    //   type:1
    // }
    const query = {
      courseId:443,
      definitionType:1,
      periodId:1298
    }
    const res = await this.$http.post('/mobileCourses/getResoursePlayUrl',query);
    if(res.status==200){
      this.source = res.content;
      this.dialogVisible = true;
      this.$nextTick(()=>{
        this.createPlayer()
      })
    }
  }
  createPlayer(){
    const props = {
      id: 'player-con',
      width: '100%',
      height: '100%',
      preload:true,
      source:this.source,
      mediaType:'video',
      extraInfo:{
        'x5-playsinline':''
      },
      autoplay:true,
      rePlay:true,
      controlBarVisibility:'always',
    }
    const Aliplayer = (window as any).Aliplayer;
    this.player = new Aliplayer(props);
  }
  /**
   * 倍数
   */
  chooseSpeed(obj:any){
    this.curSpeed = {
      speed:obj.speed
    }
    this.speedFlag = false;
    this.speedList.forEach(item=>item.active = false)
    const temp:any = this.speedList.find(item=>item.speed==obj.speed)
    temp.active = true;
    this.player.setSpeed(obj.speed)
  }
}
</script>
<style lang="scss" scoped>
  .video-page{
    background: #fff;
    .search-area{
      font-size: 0;
      >div{
        display: inline-block;
        vertical-align: middle;
      }
      .keyword-box{
        width: 208px;
      }
      .date-picker-box{
        margin:0 20px;
        >p{
          margin:0 10px;
        }
        >p,>div{
          display: inline-block;
          vertical-align: middle;
        }
        /deep/ .el-date-editor.el-input, .el-date-editor.el-input__inner{
          width: 100px;
        }
        /deep/ .el-input__inner{
          width: 100px;
          padding: 0;
          text-align: center;
        }
        /deep/ .el-input__prefix{
          display: none;
        }
      }
      .select-box{
        margin:0 20px 0 0;
        /deep/ .el-input{
          width: 128px;
        }
      }
      .search-btn{
        padding: 8px 9px;
        display: inline-block;
        vertical-align: middle;
        color:#666;
        font-size: 14px;
      }
      .add-btn{
        padding: 8px 13px;
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        color:#fff;
        margin-left: 102px;
      }
    }
    .empty{
      text-align: center;
      padding: 50px 0;
      text-align: center;
    }
    .list{
      min-height: 200px;
      font-size: 0;
      .item{
        display: inline-block;
        vertical-align: middle;
        width: 440px;
        height: 118px;
        border-radius: 6px;
        background: #fff;
        box-shadow: 0 0 10px #ececec;
        margin-top:20px;
        transition: all 0.3s;
        &.odd{
          margin-left: 20px;
        }
        &:hover{
          box-shadow:0px 3px 20px 0px #ddd;
          transform: translateY(-2px);
        }
        .t{
          height: 87px;
          border-bottom:1px solid #E5E5E5;
          padding: 10px;
          overflow: hidden;
          .surface{
            width: 118px;
            height: 66px;
            position: relative;
            overflow: hidden;
            float: left;
            cursor: pointer;
            img{
              width: 118px;
              max-width: 100%;
              position: absolute;
              top:50%;
              left: 50%;
              transform: translate(-50%,-50%);
            }
          }
          .info{
            float: left;
            margin-left: 10px;
            width: calc(100% - 128px);
            .video-name{
              height: 15px;
              line-height: 1;
              font-size: 14px;
              color:#333;
              font-weight: bold;
            }
            .user-name{
              height: 17px;
              line-height: 1;
              font-size: 13px;
              color:#666;
              margin:8px 0 12px 0;
            }
            .data{
              overflow: hidden;
              font-size: 12px;
              color:#999;
              .create-time{
                float: left;
              }
              .video-file-info{
                float: right;
              }
            }
          }
        }
        .b{
          height: 30px;
          line-height: 30px;
          padding:0 10px;
          .btns{
            float: right;
            font-size: 0;
            >div{
              font-size: 12px;
              color:#333;
              display: inline-block;
              vertical-align: middle;
              margin-right: 20px;
              cursor: pointer;
              &:last-child{
                margin-right: 0;
              }
              i{
                color:#C30D20;
                font-size: 14px;
              }
            }
          }
        }
      }
    }
    /deep/ .el-dialog__wrapper{
      .video-dialog{
        display: block;
        /deep/ .el-dialog__header{
          padding: 0;
          .el-dialog__headerbtn{
            top:5px;
            right: 5px;
          }
        }
        .video-player-box{
          width: 562.5px;
          height: 315px;
          background: #000;
          .speed-area{
            position: absolute;
            right: 5%;
            bottom:45px;
            width: 30px;
            text-align: center;
            z-index: 2;
            .cur-speed{
              color:#fff;
              font-size: 12px;
              cursor: pointer;
            }
            .speed-list{
              position: absolute;
              width: 30px;
              bottom:18px;
              left:0;
              height: -20px;
              &.open{
                display: block;
              }
              &.close{
                display: none;
              }
              .speed-item{
                height:18px;
                line-height: 18px;
                font-size: 12px;
                background: rgba(0,0,0,0.7);
                margin:2px 0;
                color:#fff;
                cursor: pointer;
                &.active{
                  color:#C30D20;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
