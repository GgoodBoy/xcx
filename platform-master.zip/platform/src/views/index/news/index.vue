<template>
    <div class="news-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '' }">消息</el-breadcrumb-item>
        </el-breadcrumb>        
        <div class="table-container">
            <el-table
                :data="tableData"
                header-row-class-name="table-header"
                border
                stripe
                :loading='loading'
                style="width: 100%">
                <el-table-column
                    label="序号"
                    align="center"
                    min-width="50">
                            <template slot-scope="scope">
                                <span :class="{ 'active': scope.row.isRead==1?true:false }">{{scope.row.sortId}}</span>                                                    
                            </template>                    
                </el-table-column>
                <el-table-column
                    label="消息内容"
                    min-width="300"
                    align="center"
                    show-overflow-tooltip>
                            <template slot-scope="scope">
                                <span :class="{ 'active': scope.row.isRead==1?true:false }">{{scope.row.content}}</span>                                                    
                            </template>                     
                </el-table-column>
                <el-table-column
                    label="时间"
                    min-width="150"
                    align="center">
                            <template slot-scope="scope">
                                <span :class="{ 'active': scope.row.isRead==1?true:false }">{{scope.row.createdAt}}</span>                                                    
                            </template>                      
                </el-table-column>             
                </el-table>   
                <div class="page-container">
                    <el-pagination
                        layout="prev, pager, next"
                        @current-change="childPageValue"
                        :current-page.sync="pageAtion.paginationPage"
                        :total="pageAtion.pageTotal">
                    </el-pagination>
                    <p class="pagesize">共{{pages}}页</p>
                </div>                         
        </div>        
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'news'
})
export default class NewsComponent extends Vue {
    tableData:any= [];
    pageNo:number=1;
    pageSize:number=50;
    pages = 1;
    isActive:boolean = true;
    loading:boolean=false;
    pageAtion:any={
        pageTotal:0,
        paginationPage:1
    };    
    created(){
        this.getNewsList(1);
    } 
    childPageValue(num:number){
        this.getNewsList(num)
    }
    // //获取没有看过消息的id
    // setTableId(list:any){
    //     const idArray:any = [];
    //     list.forEach((element:any) => {
    //         if(!element.seeType){
    //             idArray.push(element.id);
    //         }
    //         this.setFilterId(idArray);
    //     });
    // }
    // //保存表单没观看信息数据id
    // async setFilterId(list:any){
    //     try {
    //         const query = {
    //             params:{
    //                 ids:list.toString()
    //             }
    //         }                    
    //         const res = await this.$http.get(this.$server.logout,query)
    //         if(res.code==200){
    //             // this.tableData = res;
    //             console.log('保存消息id成功');
    //         }                    
    //     } catch (err) {
    //         console.log(err);
    //     }
    // }    
    //获取表单数据
    async getNewsList(n:number){
        try {
            if(n>1){
                this.pageNo = n;
            }
            const query = {
                params:{
                    pageNo:this.pageNo,
                    pageSize:this.pageSize
                }
            }                    
            this.loading = true; 
            const res = await this.$http.get(this.$server.getMessageList,query)
            if(res.code==200){
                   let listIds = [];
                   const contentdate = res.data;
                   const nextPage = contentdate.nextPage;
                   const prePage = contentdate.prePage;
                   if(contentdate.list.length){
                        if(!prePage&&!nextPage){
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-index;
                                return element;
                            });
                        }else{
                            listIds = contentdate.list.map(function(element:any,index:number){
                                element.sortId = contentdate.total-prePage*10-index;
                                return element;
                            });                            
                        } 
                    } 
                    this.tableData = listIds;
                    this.pageAtion.pageTotal = contentdate.total;
                    this.pages = contentdate.pages;
                    this.pageAtion.paginationPage = n;
                    this.loading = false; 
                    console.log('进来了');
            }                    
        } catch (err) {
            this.loading = false; 
            console.log(err);
        }
    }


}
</script>
<style lang="scss" scoped>
.news-page{
    background: #fff;
    .block{
            text-align: center;
            padding: 40px 0 40px 0;
            background: #fff;
    }
}
.active{
    font-weight: 700;
}
</style>
