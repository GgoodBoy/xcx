<template>
    <div class="index-container">
        <div class="index-header clearfix" role="header">
            <p class="logo">学国学网机构平台</p>
            <div class="index-header-r">
                <el-badge :value="20" :max="99" class="msg">
                   <i class="el-icon-chat-line-square"></i>
                </el-badge>
                <img class="avatar" :src="avatar"/>
                <div class="name">
                    <p>{{name}}</p>
                    <i class="el-icon-caret-bottom"></i>
                    <div class="header-menu">
                        <p @click="logoutEvent">
                            <i></i>退出
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="index-content" role="main">
            <div class="nav-container">
                <el-menu
                    ref="menuContainer"
                    class="el-menu-box"
                    style="height:100%"
                    :default-active="defaultActive"
                    :unique-opened='false'
                    @select="selectMenu"
                    >
                    <div class="item" v-for="(item,index) in allRoutes.filter(obj=>obj.meta.role=='menu')" :key="index">
                        <template v-if="item.meta.child">
                            <el-submenu ref="menu" :index="`${String(index)}`" :data-index="`${String(index)}`" :path="item.path" v-if="item.meta.child.length>1">
                                <template slot="title">
                                    <div class="menu-event-box"> 
                                        <i class="menu-icon" :class="item.meta.iconClassName?item.meta.iconClassName:''"></i>
                                        <span class="first-menu-title menu-title">
                                            {{item.meta.name}}
                                        </span>
                                    </div>
                                </template>
                                <el-menu-item ref="menu" class="second-menu" :index="`${String(index)}-${String(i)}`" :data-index="`${String(index)}-${String(i)}`" :path="option.path" v-for="(option,i) in item.meta.child" :key="option.path">
                                    <div class="menu-event-box" @click="chooseMenu($event)">
                                        <span class="second-menu-title menu-title">
                                            {{option.name}}
                                        </span>
                                    </div>
                                </el-menu-item>
                            </el-submenu>
                            <el-menu-item v-else ref="menu" class="first-menu" :index="`${String(index)}`" :data-index="`${String(index)}`" :path="item.meta.child[0].path">
                                <div class="menu-event-box" @click="chooseMenu($event)">
                                    <i class="menu-icon" :class="item.meta.iconClassName?item.meta.iconClassName:''"></i>
                                    <span slot="title" class="first-menu-title menu-title">
                                    {{item.meta.child[0].name}}
                                    </span>
                                </div>
                            </el-menu-item>
                        </template>
                    </div>
                </el-menu>    
            </div>
            <div class="content-container">
                <transition name="slide-fade">
                    <router-view v-if="isRouterAlive" :key="$route.fullPath"></router-view>
                </transition>
            </div>  
        </div>
  </div>
</template>
<script lang="ts">
import { Component,Vue,Provide,Watch} from 'vue-property-decorator'
@Component({
    name:'index'
})
export default class Index extends Vue {
    name = ''
    avatar = ''
    isRouterAlive:boolean = true;
    allRoutes:any = [];
    defaultActive = '0';
    @Provide('viewReload')
        viewReload = this.reload
    @Watch('$route')
        onRouteChanged(){
            this.routeRefresh()
            if(this.name == ''){
                const user = this.$utils.getUser()
                if(user){
                    this.name = JSON.parse(user).username;
                    this.avatar = JSON.parse(user).headImg;
                }
            }
        }    
    created(){
        const options:any = this.$router;
        const allRoutes = options.options.routes.find((item:any)=>{
            return item.name=='index'
        }).children;
        this.allRoutes = [...allRoutes];
        const user = this.$utils.getUser()
        if(user){
            this.name = JSON.parse(user).username;
            this.avatar = JSON.parse(user).headImg;
        }
    }
    mounted(){
        this.routeRefresh()  
    }
    routeRefresh(){
        const path = this.$route.fullPath
        const menuArr = this.allRoutes.filter((obj:any)=>obj.meta.role=='menu');
        for(let i=0;i<menuArr.length;i++){
            const index = menuArr[i].meta.child.findIndex((option:any)=>path.includes(option.path));
            if(index>=0){
                const activeDoms:any = document.querySelectorAll('.el-menu-box .is-active');
                for(const item of activeDoms){
                    const className:any = item.getAttribute('class');
                    item.setAttribute('class',className.replace(/is-active/g,''))
                }
                if(menuArr[i].meta.child.length>1){
                    const refs:any = this.$refs;
                    refs.menuContainer.open(i);
                    const target = document.querySelectorAll('.el-menu-box .item')[i].querySelector('.el-submenu') as HTMLElement;
                    setTimeout(() => {
                        const className:any = target.getAttribute('class')
                        target.setAttribute('class',className.concat(' is-active'));
                        const childDom = document.querySelectorAll('.el-menu-box .item')[i].querySelectorAll('.second-menu')[index] as HTMLElement;
                        const classNameTemp:any = childDom.getAttribute('class')
                        childDom.setAttribute('class',classNameTemp.concat(' is-active'))
                    }, 0);
                }else{
                    const target = document.querySelectorAll('.el-menu-box .item')[i].querySelector('.first-menu') as HTMLElement;
                    const className:any = target.getAttribute('class')
                    target.setAttribute('class',className.concat(' is-active'));
                }
                break;
            }
        }
    }
    /**
     * view刷新
     */
    reload(){
        this.isRouterAlive = false;
        this.$nextTick(()=>{
            this.isRouterAlive = true;
        })
    }
    /**
     * 选中菜单
     */
    selectMenu(key:string){
      this.routerGo(key)
    }
    /**
     * 进入路径详情
     */
    routerGo(key:string){
        const refs:any = this.$refs;
        for(const item of refs.menu){
            const tempKey = item.$el.getAttribute('data-index');
            if(key == tempKey){
                const path = item.$el.getAttribute('path');
                if(this.$route.path == path){
                    //reload?
                }else{
                    this.$router.push(path)
                }
                break;
            }
        }
    }
    /**
     * 选中变红
     */
    chooseMenu(e:any){
        return;
        console.log(111)
        const activeDoms:any = document.querySelectorAll('.el-menu-box .is-active');
        for(const item of activeDoms){
            const className:any = item.getAttribute('class');
            item.setAttribute('class',className.replace('is-active',''))
        }
        if(e.target.className=='menu-event-box'){
            const temp:any = e.target.parentNode.getAttribute('class');
            e.target.parentNode.setAttribute('class',temp.concat('is-active'))
            const className = e.target.parentNode.getAttribute('class');
            if(className.includes('second-menu')){
                const temp:any = e.target.parentNode.parentNode.parentNode.getAttribute('class');
                e.target.parentNode.parentNode.parentNode.setAttribute('class',temp.concat('is-active'))
            }
        }else if(e.target.parentNode.className=='menu-event-box'){
            const temp:any = e.target.parentNode.parentNode.getAttribute('class');
            e.target.parentNode.parentNode.setAttribute('class',temp.concat('is-active'))
            const className = e.target.parentNode.parentNode.getAttribute('class');
            if(className.includes('second-menu')){
                const temp:any = e.target.parentNode.parentNode.parentNode.parentNode.getAttribute('class');
                e.target.parentNode.parentNode.parentNode.parentNode.setAttribute('class',temp.concat('is-active'))
            }
        }else{
            //do something
        }
    }
    /**
     * 退出
     */
    logoutEvent(){
      this.$confirm('是否退出登录?', '', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'error',
          center:true
      }).then(() => {
          this.logout()
      }).catch(() => {
          //do something  
      });
    }
    async logout(){
        const res = await this.$http.post(this.$server.logout,{})
        if(res.code==200){
            this.$utils.quitUser()
            this.$router.push('/login')
            this.$message({
                type: 'success',
                message: '您已退出登录'
            });
      }
    }
}
</script>
<style lang="scss" scoped>
    .index-container{
        width:1200px;
        height: 100%;
        margin:0 auto;
        .index-header{
            position: fixed;
            width: 1200px;
            height: 80px;
            background: #C30D23;
            line-height: 80px;
            border-radius: 6px;
            padding:0 20px;
            // z-index: 7;
            z-index: 9;
            .logo{
                font-size: 26px;
                color:#fff;
                line-break: 80px;
                font-weight: bold;
                float: left;
            }
            .index-header-r{
                float: right;
                font-size: 0;
                .msg{
                    height: 30px;
                    line-height:30px;
                    display: inline-block;
                    vertical-align: middle;
                    /deep/ .el-badge__content{              
                        background: linear-gradient(90deg, #D11229 0%, #FB6371 100%);
                    }
                    i{
                        color:#fff;
                        font-size: 30px;
                    }
                }
                .avatar{
                    height: 36px;
                    width: 36px;
                    border-radius: 50%;
                    margin:0 10px 0 40px;
                    display: inline-block;
                    vertical-align: middle;
                    overflow: hidden;
                }
                .name{
                    display: inline-block;
                    vertical-align: middle;
                    font-size: 16px;
                    color:#fff;
                    position: relative;
                    &:hover{
                        .el-icon-caret-bottom{
                            transform: rotate(180deg);
                        }
                        .header-menu{
                            display:block;
                        }
                    }
                    p{
                        display: inline-block;
                    }
                    i{
                        margin-left: 5px;
                        transition: all 0.3s;
                    }
                    .header-menu{
                        background: #fff;
                        border-radius: 6px;
                        position: absolute;
                        top:50px;
                        right:0;
                        text-align: center;
                        width: 66px;
                        box-shadow: 0 0 10px #dfdfdf;
                        display:none;
                        height: 28px;
                        line-height: 28px;
                        p{
                            color:#333;
                            font-size: 13px;
                            cursor: pointer;
                            i{
                                display: inline-block;
                                vertical-align: sub;
                                width: 16px;
                                height: 16px;
                                margin-right: 2px;
                                background: url('../../assets/image/logout_icon.png')no-repeat 50% 50% /cover;
                            }
                        }
                    }
                }
            }
        }
        .index-content{
            width: 100%;
            min-height: 100vh;
            padding-top:97px;
            border-radius: 6px;
            overflow: hidden;
            position: relative;
            .nav-container{
                width: 240px;
                border-radius: 6px;
                height: calc(100vh - 97px);
                overflow-y: auto;
                position: fixed;
                top:97px;
                z-index: 2;
                background: #fff;
                padding: 15px 0;
                &::-webkit-scrollbar{
                    width: 0;
                    height: 0;
                }
                /deep/ .el-menu{
                    border:none!important;
                }
                .el-submenu{
                    &.is-opened{
                        /deep/ .el-submenu__icon-arrow{
                            transform: rotate(0deg);
                        }
                    }
                    /deep/ .el-submenu__icon-arrow{
                        transform: rotate(-90deg);
                        top:57%;
                        font-size: 14px;
                    }
                }
                .first-menu.is-active{
                    background: #F9E6E8;
                    a{
                        color:#C30D23;
                    }
                }
                .second-menu.is-active{
                    background: #F9E6E8;
                }
                .second-menu-title{
                    color:#666;
                }
                .el-submenu.is-active{
                    .first-menu-title{
                        color:#C30D23;
                    }
                }
                .menu-icon{
                    height: 20px;
                    width: 20px;
                    display: inline-block;
                    vertical-align: middle;
                    margin-right: 10px;
                }
                .first-menu-title{
                    font-weight: bold;
                    font-size: 16px;
                }
                .second-menu-title{
                    margin-left: 16px;
                }
            }
            .content-container{
                position: relative;
                width: calc(100% - 260px);
                margin-left: 260px;
                min-height: calc(100vh - 97px);
                color:#333;
                border-radius: 6px;
                >div{
                    padding: 0px 20px;
                    border-radius: 6px;
                }
            }
        }
    }
    .slide-fade-enter-active {
        transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
    }
    .slide-fade-leave-active {
        transition: none;
    }
    .slide-fade-enter{
        transform: translateX(-10px);
        opacity: 0;
    }
    .slide-fade-leave-to{
        opacity: 0;
    }
    .menu-event-box{
        position: absolute;
        top:0;
        left: 0;
        width: 100%;
        height: 100%;
    }
    .first-menu,.el-submenu{
        .menu-event-box{
            padding: 0 20px;
        }
    }
    .second-menu{
        .menu-event-box{
            padding: 0 40px;
        }
    }
</style>
