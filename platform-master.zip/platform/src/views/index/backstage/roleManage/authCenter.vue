<template>
    <div class="role-auth-page">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/backstage/role' }">后台</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/index/backstage/role' }">角色管理</el-breadcrumb-item>
            <el-breadcrumb-item>添加权限</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content" v-loading="loading">
            <div class="box">
                <el-tree
                    :data="permissionList"
                    node-key="id"
                    show-checkbox
                    ref="tree"
                    @check-change="handleCheckChange"
                    >
                </el-tree>
            </div>
            <div class="btns-area">
                <el-button type="primary" @click="addAuth">确定</el-button>               
                <el-button class="cancel" @click="$router.go(-1)">取消</el-button>
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import { Component,Vue} from 'vue-property-decorator'
@Component({
    
})
export default class MyComponent extends Vue{
    loading = false;
    checkedKeys:any = [];
    permissionList:any = []
    created(){
        this.getPermission()
    }
    async getPermission(){
        this.loading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getPermission,query);
        this.loading = false;
        if(res.code==200){
            this.permissionList = this.getroleTree(res.data);
            const treeDom:any = this.$refs.tree;
            setTimeout(()=>{
                treeDom.setCheckedKeys(this.checkedKeys)
            },1)
        }
    }
    /**
     * 递归组合数据
     */
    getroleTree(data:object){
        if(typeof data == 'object' && Array.isArray(data)){
            data.forEach((item:any)=>{
                item.label = item.title;
                if(item.childrenList.length>0){
                    item.children = this.getroleTree(item.childrenList)
                }else{
                    if(item.has == 1){
                        this.checkedKeys.push(item.id)
                    }
                }
            })
            return data;
        }
    }
    handleCheckChange(){
        console.log(1)
    }
    addAuth(){
        console.log(2)
    }
}
</script>
<style lang="scss" scoped>
    .role-auth-page{
        text-align: center;
        .box{
            margin-top:20px;
            min-height: 100px;
        }
        .btns-area{
            margin:40px 0;
            display: inline-block;
            /deep/ .el-button{
                padding: 9px 35px;
            }
        }
        /deep/ .el-tree-node__content{
            height: 60px;
            .el-tree-node__expand-icon{
                font-size: 25px!important;
            }
            .el-checkbox__inner{
                width: 20px;
                height: 20px;
                margin-top:6px;
            }
            .el-checkbox__inner::after{
                height: 11px;
                left: 7px;
            }
            .el-checkbox__input.is-indeterminate .el-checkbox__inner::before{
                top:8px;
            }
        }
    }
</style>