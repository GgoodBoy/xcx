<template>
    <div class="role-manage-page"  v-loading="loading">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/backstage/role' }">后台</el-breadcrumb-item>
            <el-breadcrumb-item>角色管理</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <el-button type="primary" class="add-role-btn" v-btn-blur @click="dialogVisible=true">
                <!-- <i class="el-icon-plus"></i> -->
                添加角色
            </el-button>
            <div class="table-container">
                <el-table
                    :data="tableData"
                    style="width: 100%"
                    :fit="true"
                    stripe
                    border
                    header-row-class-name="table-header">
                    <el-table-column
                        prop="sortId"
                        label="序号"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        prop="title"
                        label="角色"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        prop="createdAt"
                        label="创建时间"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        label="操作"
                        align="center"
                    >
                        <template slot-scope="scope">
                            <el-button type="text" @click="$router.push('/index/backstage/role/auth')">添加普通权限</el-button>
                            <el-button type="text" @click="viewRoleEvent(scope.row)">查看</el-button>
                            <el-button type="text" @click="delEvent(scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>        
        </div>
        <el-dialog
            :visible.sync="dialogVisible"
            top="30vh"
            width="480px"
            custom-class="role-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >   <el-form ref="form" :model="form" label-width="80px" :rules="rules" >
                <el-form-item label="角色名称" prop="title">
                    <el-input placeholder="" clearable v-model="form.title"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible=false">取 消</el-button>
                <el-button type="primary" @click="submitData('form')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog 
            :visible.sync="dialogVisible1"
            top="30vh"
            width="480px"
            custom-class="role-view-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >
            <div>
                <div v-show="userList.length>0">
                    <p class="label">用户名称 :</p>
                    <div class="role-list">
                        <div v-for="(item,index) in userList" :key="index" class="role-item">
                            <p>{{item.username}}</p>
                            <i class="el-icon-circle-close" @click="deleteUserEvent(item)"></i>
                        </div>
                    </div>
                </div>
                <div class="permission-list-box">
                    <p class="label">角色权限 :</p>
                    <div class="permission-list">
                        <one-tree v-for="(item,index) in permissionList" :key="index" :permission="item"></one-tree>
                    </div>
                </div>
            </div>
        </el-dialog>
    </div>    
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';

Vue.component(CollapseTransition.name, CollapseTransition)
const oneTree = Vue.extend({
    template:`<div class="one-tree-warp">
                    <div class="header" @click="changeStatus">
                        <span class="icon-warp">
                            <i class="el-icon-minus" v-show="checkBoxStatus"></i>
                            <i class="el-icon-plus" v-show="!checkBoxStatus"></i>
                        </span>
                        <span>{{permission.title}}</span>
                    </div>
                    <el-collapse-transition>
                        <div class="content" v-show="checkBoxStatus">
                            <el-checkbox v-for="(item,index) in permission.childrenList" :key="index" :checked="item.has?true:null" :label="item.title" disabled></el-checkbox>
                        </div>
                    </el-collapse-transition>
                </div>`,
    data:()=>{
        return {
            checkBoxStatus:true
        }
    },
    props:['permission'],
    created(){
        this.checkBoxStatus = this.permission.childrenList.length>0?true:false
    },
    methods:{
        changeStatus(){
            this.checkBoxStatus = !this.checkBoxStatus;
        }
    },        
});
@Component({
    components:{
        'one-tree':oneTree
    }
})
export default class MyComponent extends Vue{
    tableData = []
    loading = false;
    dialogVisible = false;
    form = {
        title:''
    }
    rules = {
        title:[
            { required: true, message: '角色名称不能为空', trigger: 'blur' },
        ]
    }
    userList = [];
    permissionList = [];
    dialogVisible1 = false;
    @Watch('dialogVisible')
        onDialogVisibleChanged(cur:boolean){
            if(!cur){
                const form:any = this.$refs.form as HTMLElement;
                form.clearValidate();
                this.form = {
                    title:''
                }
            }
        }
    created(){
        this.getRoleList();
        this.getPermission()
    }
    /**
     * 获取所有角色
     */
    async getRoleList(){
        this.loading = true;
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getRoleList,query);
        this.loading = false;
        if(res.code==200){
            this.tableData = res.data.map((item:any,index:number)=>{
                item.sortId = index+1;
                return item;
            })
        }
    }
    /**
     * 添加角色事件
     */
    submitData(formName:string){
        const form:any = this.$refs[formName] as HTMLElement;
        form.validate((valid:any) => {
            if (valid) {
                this.addRole()
            } else {
                return false;
            }
        });
    }
    /**
     * 添加角色
     */
    async addRole(){
        const loadingInstance = this.$loading({
            target:document.querySelector('.role-dialog') as HTMLElement
        });
        const query = Object.assign({},this.form)
        const res = await this.$http.post(this.$server.addRole,query)
        loadingInstance.close()
        if(res.code==200){
            this.dialogVisible = false;
            this.$message.success('角色添加成功');
            this.getRoleList()
        }
    }
    /**
     * 删除角色弹窗
     */
    delEvent(obj:any){
        this.$confirm('确定要删除这个角色吗？', '', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'error',
            center:true,
        }).then(() => {
            this.deleteRole(obj.id)
        }).catch(() => {
            //do something  
        });
    }
    /**
     * 删除角色
     */
    async deleteRole(id:number){
        this.loading = true;
        const res = await this.$http.post(`${this.$server.deleteRole}/${id}`,{});
        this.loading = false;
        if(res.code==200){
            this.$message.success('角色删除成功');
            this.getRoleList()
        }
    }
    async viewRoleEvent(obj:any){
        this.dialogVisible1 = true;
        const loadingInstance = this.$loading({
            target:document.querySelector('.role-view-dialog') as HTMLElement
        });
        const res = await this.$http.get(`${this.$server.viewRole}/${obj.id}`,{})
        loadingInstance.close()
        if(res.code==200){
            this.userList = res.data.userList;
            this.permissionList = res.data.permissionList;
        }
    }
    async getPermission(){
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getPermission,query)
        if(res.code==200){
            console.log(res.data)
        }
    }
    /**
     * 删除角色下用户事件
     */
    deleteUserEvent(obj:any){
        this.$confirm('是否删除此用户？', '', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'error',
            center:true,
        }).then(() => {
            this.deleteUser(obj)
        }).catch(() => {
            //do something  
        });
    }
    async deleteUser(obj:any){
        const loadingInstance = this.$loading({
            target:document.querySelector('.role-view-dialog') as HTMLElement
        });
        const query = {
            roleId:obj.roleId,
            userId:obj.id
        }
        const res = await this.$http.post(`${this.$server.deleteUser}/${obj.roleId}`,query);
        loadingInstance.close()
        if(res.code==200){
            this.dialogVisible1 = false;
            this.$message.success('用户删除成功');
            this.getRoleList()
        }
    }
}
</script>
<style lang="scss" scoped>
    .role-manage-page{
        background: #fff;
        padding-bottom: 30px!important;
        .content{
            position: relative;
            .add-role-btn{
                position: relative;
                left:811px;
            }
            .table-container{
                margin-top:20px;
            }
        }
        /deep/ .el-dialog__wrapper{
            .el-dialog{
                &.role-view-dialog{
                    .label,.role-list,.permission-list{
                        display: inline-block;
                        vertical-align: top;
                        &.label{
                            line-height: 24px;
                        }
                        &.role-list{
                            max-width: 80%;
                        }
                    }
                    .permission-list-box{
                        margin-top:10px;
                    }
                    .role-item{
                        display: inline-block;
                        vertical-align: middle;
                        margin:0 10px;
                        position: relative;
                        p{
                            line-height: 24px;
                        }
                        i{
                            position: absolute;
                            right: -14px;
                            top:-4px;
                            color:#C30D23;
                            cursor: pointer;
                            display: none;
                        }
                        &:hover{
                            i{
                                display: block;
                            }
                        }
                    }
                    .one-tree-warp{
                        padding: 0 10px;
                        .header{
                            cursor:pointer;
                            margin-bottom:20px;
                        .icon-warp{
                            height: 20px;
                            width: 20px;
                            background: #848484;
                            line-height: 20px;
                            margin-right: 10px;
                            text-align: center;
                        }
                        span{
                            color:#6A6A6A;
                            display: inline-block;
                            font-size: 16px;
                        }
                        .el-icon-minus,.el-icon-plus{
                            color:#fff;
                        }
                    }
                    .content{
                            .el-checkbox{
                                margin-bottom:20px;
                            }
                            .el-checkbox{
                                margin-left: 0;
                                margin-right: 30px;
                            }
                            .el-checkbox__inner{
                                box-sizing: content-box;
                                padding: 2px;
                            }
                            .el-checkbox__inner::after{
                                height: 10px;
                                width: 6px;
                                left: 6px;
                            }
                            .el-checkbox__input.is-disabled+span.el-checkbox__label{
                                color:#6A6A6A;
                            }
                            .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner{
                                background: #C30D23;
                                border-color:#C30D23;
                            }
                            .el-checkbox__label{
                                font-size: 16px;
                            }
                        }
                    }
                }
            }
        }
        
    }
</style>