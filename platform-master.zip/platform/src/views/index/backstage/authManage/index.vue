<template>
    <div class="auth-manage-page"  v-loading="loading">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/backstage/auth' }">后台</el-breadcrumb-item>
            <el-breadcrumb-item>权限管理</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入权限名称查询" v-model="name" clearable></el-input>
                </div>
                <el-button class="search-btn primary" v-btn-blur @click="search">
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <el-button class="add-btn" type="primary" @click="dialogVisible=true">
                    <!-- <i class="el-icon-plus"></i> -->
                    添加权限
                </el-button>
            </div>
            <div class="table-container">
                <el-table
                    :data="tableData"
                    style="width: 100%"
                    :fit="true"
                    stripe
                    border
                    header-row-class-name="table-header">
                    <el-table-column
                        prop="sortId"
                        label="序号"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        prop="title"
                        label="权限名称"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        prop="code"
                        label="code"
                        align="center"
                    ></el-table-column>
                    <el-table-column
                        prop="parentName"
                        label="父级"
                        align="center"
                    ></el-table-column>
                </el-table>
            </div>
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>  
        </div>
        <el-dialog
            :visible.sync="dialogVisible"
            top="30vh"
            width="480px"
            custom-class="auth-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >
            <el-form ref="form" :model="form"  label-width="80px" class="auth-form" :rules="rules">
                <el-form-item label="权限名称" class="form-name" prop="name">
                    <el-input v-model.trim="form.name" maxlength="20" show-word-limit clearable @keyup.enter.native="submitData('form')"></el-input>
                </el-form-item>
                <el-form-item label="codeID" class="form-code" prop="code">
                    <el-input v-model.trim="form.code" maxlength="32" show-word-limit clearable @keyup.enter.native="submitData('form')"></el-input>
                </el-form-item>
                <el-form-item label="父级" class="form-parent" prop="parent">
                    <el-cascader
                        v-model="form.parent"
                        :options="options"
                        :props="{ checkStrictly: true }"
                        clearable
                        >
                    </el-cascader>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible=false">取 消</el-button>
                <el-button type="primary" @click="submitData('form')">确 定</el-button>
            </span>
        </el-dialog>
    </div>    
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
@Component({
  name:'videoPage'
})
export default class MyComponent extends Vue{
    name = '';
    tableData = [];
    loading = false;
    pageNo = 1;
    pageSize = 10;
    total = 10;
    pages = 1;
    dialogVisible = false;
    form = {
        name:'',
        code:'',
        parent:[]
    }
    rules = {
        name:[
            { required: true, message: '权限名称不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^[A-Za-z0-9\u4e00-\u9fa5]+$/
                if(!regExp.test(value)){
                    return callback(new Error('只能输入汉字、字母、数字'));
                }
                callback();
            }, trigger: 'blur' }
        ],
        code:[
            { required: true, message: 'code不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^[A-Za-z\:]+$/
                if(!regExp.test(value)){
                    return callback(new Error('只能输入英文字母或者字母+冒号的组合'));
                }
                callback();
            }, trigger: 'blur' }
        ],
        parent:[
            { required: true, message: '请选择父级', trigger: 'change' },
        ]
    }
    options:any = []
    @Watch('pageNo')
        onPageNoChanged(cur:number){
            if(cur>0){
                this.selectAuthPage()
            }
        }
    @Watch('dialogVisible')
        onDialogVisibleChanged(cur:boolean){
            if(!cur){
                const form:any = this.$refs.form as HTMLElement;
                form.clearValidate();
                this.form = {
                    name:'',
                    code:'',
                    parent:[]
                }
            }
        }     
    created(){
        this.selectAuthPage()
        this.selectAuthList()
    }
    /**
     * 获取列表数据
     */
    async selectAuthPage(){
        this.loading = true;
        const query = {
            params:{
                name:this.name,
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        }
        const res = await this.$http.get(this.$server.selectAuthPage,query);
        this.loading = false;
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.tableData = res.data.list.map((item:any,index:number)=>{
                item.sortId = index+1;
                return item;
            })
        }
    }
    /**
     * 搜索
     */
    search(){
        this.pageNo = 0;
        this.$nextTick(()=>{
            this.pageNo = 1;
        })
    }
    /**
     * 获取所有权限
     */
    async selectAuthList(){
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.selectAuthList,query);
        if(res.code==200){
            this.options = this.getAuthMenu(res.data)
        }
    }
    getAuthMenu(data:any){
        if(typeof data == 'object' && Array.isArray(data)){
            data.forEach(item=>{
                item.label = item.title;
                item.value = item.id;
                if(item.childrenList.length>0){
                    item.children = this.getAuthMenu(item.childrenList)
                }
            })
            return data;
        }
    }
    /**
     * 添加权限提交
     */
    submitData(formName:string){
        const form:any = this.$refs[formName] as HTMLElement;
        form.validate((valid:any) => {
            console.log(valid)
            if (valid) {
                this.addAuth()
            } else {
                return false;
            }
        });
    }
    /**
     * 添加权限
     */
    async addAuth(){
        const loadingInstance = this.$loading({
            target:document.querySelector('.auth-dialog') as HTMLElement
        });
        const query = {
            name:this.form.name,
            code:this.form.code,
            parentId:Number(this.form.parent.splice(this.form.parent.length-1,this.form.parent.length).join(''))
        }
        const res = await this.$http.post(this.$server.addAuth,query);
        loadingInstance.close();
        if(res.code==200){
            this.$message.success('添加成功');
            this.dialogVisible = false;
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = 1;
                this.selectAuthList()
            })
        }
    }
}
</script>
<style lang="scss" scoped>
    .auth-manage-page{
        background: #fff;
        .search-area{
            font-size: 0;
            >div{
                display: inline-block;
                vertical-align: middle;
            }
            .keyword-box{
                width: 208px;
            }
            .search-btn{
                padding: 8px 9px;
                display: inline-block;
                vertical-align: middle;
                color:#666;
                font-size: 14px;
                margin-left: 20px;
            }
            .add-btn{
                padding: 8px 13px;
                display: inline-block;
                vertical-align: middle;
                font-size: 14px;
                color:#fff;
                margin-left: 521px;
            }
        }
        .table-container{
            margin-top:20px;
        }
        .auth-form{
            /deep/ .el-cascader{
                width: 100%;
            }
        }
    }
</style>