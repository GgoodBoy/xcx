<template>
    <div class="account-manage-page"  v-loading="loading">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/index/backstage/account' }">后台</el-breadcrumb-item>
            <el-breadcrumb-item>后台账户管理</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content">
            <div class="search-area">
                <div class="keyword-box">
                    <el-input placeholder="请输入用户名查询" v-model="username" clearable></el-input>
                </div>
                <el-button class="search-btn primary" v-btn-blur @click="search">
                    <i class="el-icon-search"></i>
                    查询
                </el-button>
                <el-button class="add-btn" type="primary" v-btn-blur @click="dialogVisible1=true">
                    <!-- <i class="el-icon-plus"></i> -->
                    创建用户
                </el-button>
            </div>
            <div class="table-container scroll-table">
                <el-table
                    :data="tableData"
                    style="width: 100%"
                    :fit="true"
                    stripe
                    border
                    header-row-class-name="table-header">
                    <el-table-column
                        prop="sortId"
                        label="序号"
                        align="center"
                        width="52"
                    ></el-table-column>
                    <el-table-column
                        prop="username"
                        label="用户名"
                        align="center"
                        width="150"
                    ></el-table-column>
                    <el-table-column
                        prop="nickname"
                        label="姓名"
                        align="center"
                        width="150"
                    ></el-table-column>
                    <el-table-column
                        prop="department"
                        label="部门"
                        align="center"
                        width="150"
                    ></el-table-column>
                    <el-table-column
                        prop="createdAt"
                        label="创建时间"
                        align="center"
                        width="180"
                    ></el-table-column>
                    <el-table-column
                        prop="updatedAt"
                        label="最后登录"
                        align="center"
                        width="180"
                    ></el-table-column>
                    <el-table-column
                        label="操作"
                        align="center"
                        width="200"
                    >
                        <template slot-scope="scope">
                            <el-button type="text" @click="allotRoleEvent(scope.row)">分配角色</el-button>
                            <el-button type="text" @click="resetPwdEvent(scope.row)">重置密码</el-button>
                            <el-button type="text" @click="diyEnableEvent(scope.row)">{{scope.row.status==1?'禁用':'启用'}}</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div class="page-container">
                <el-pagination
                layout="prev, pager, next"
                :current-page.sync="pageNo"
                :page-size="pageSize"
                :total="total">
                </el-pagination>
                <p class="pagesize">共{{pages}}页</p>
            </div>  
        </div>
        <el-dialog
            :visible.sync="dialogVisible1"
            top="30vh"
            width="480px"
            custom-class="account-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >   
            <el-form ref="form1" :model="form1" label-width="68px" :rules="rules1" >
                <el-form-item label="用户名" class="form-username" prop="username">
                    <el-input type="text" placeholder="只支持英文字符" clearable v-model="form1.username" maxlength="20" show-word-limit @focus="resetRules('form1')" @keyup.enter.native="submitData('form1')"></el-input>
                </el-form-item>
                <el-form-item label="姓名" class="form-nickname" prop="nickname">
                    <el-input placeholder="" clearable v-model="form1.nickname" maxlength="10" show-word-limit @focus="resetRules('form1')" @keyup.enter.native="submitData('form1')"></el-input>
                </el-form-item>
                <el-form-item label="部门" class="form-department" prop="department">
                    <el-input placeholder="" clearable v-model="form1.department" maxlength="10" show-word-limit @focus="resetRules('form1')" @keyup.enter.native="submitData('form1')"></el-input>
                </el-form-item>
                <el-form-item label="角色" class="form-role" prop="roleId">
                    <el-select v-model="form1.roleId" placeholder="角色" clearable>
                        <el-option
                        v-for="item in roleOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="密码" class="form-password" prop="password">
                    <el-input type="password" placeholder="" clearable v-model="form1.password" maxlength="10" show-word-limit @focus="resetRules('form1')" @keyup.enter.native="submitData('form1')"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible1=false">取 消</el-button>
                <el-button type="primary" @click="submitData('form1')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog
            :visible.sync="dialogVisible2"
            top="30vh"
            width="480px"
            custom-class="pwd-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >   
            <el-form ref="form2" :model="form2" label-width="68px" :rules="rules2" @submit.native.prevent>
                <el-form-item label="密码" class="form-password" prop="password">
                    <el-input type="password" v-model="form2.password" maxlength="10" show-word-limit @keyup.enter.native="submitData('form2')" @focus="resetRules('form2')"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible2=false">取 消</el-button>
                <el-button type="primary" @click="submitData('form2')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog
            :visible.sync="dialogVisible3"
            top="30vh"
            width="480px"
            custom-class="role-dialog"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            center
        >   <el-form ref="form3" :model="form3" label-width="68px" :rules="rules3" >
                 <el-form-item label="角色" class="form-role" prop="roleId">
                    <el-select v-model="form3.roleId" placeholder="角色" clearable>
                        <el-option
                        v-for="item in roleOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible3=false">取 消</el-button>
                <el-button type="primary" @click="submitData('form3')">确 定</el-button>
            </span>
        </el-dialog>
    </div>    
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
const Base64 = require('js-base64').Base64;  
@Component({
  name:'videoPage'
})
export default class MyComponent extends Vue{
    username = '';
    userId = '';
    tableData = [];
    loading = false;
    pageNo = 1;
    pageSize = 10;
    total = 10;
    pages = 1;
    dialogVisible1 = false;
    roleOptions:any = []
    form1 = {
        username:'',
        password:'',
        nickname:'',
        department:'',
        roleId:''
    }
    rules1 = {
        username:[
            { required: true, message: '用户名不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^[a-zA-Z]+$/
                if(!regExp.test(value)){
                    return callback(new Error('只能是英文字符'));
                }
                callback();
            }, trigger: 'blur' }
        ],
        nickname:[
            { required: true, message: '姓名不能为空', trigger: 'blur' },
        ],
        department:[
            { required: true, message: '部门不能为空', trigger: 'blur' },
        ],
        roleId:[
            { required: true, message: '请选择角色', trigger: 'change' },
        ],
        password:[
            { required: true, message: '密码不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^[a-zA-Z\d]{7,}$/
                if(!regExp.test(value)){
                    return callback(new Error('数字字母组合7位以上'));
                }
                callback();
            }, trigger: 'blur' }
        ]
    }
    dialogVisible2 = false;
    form2 = {
        password:''
    }
    rules2 = {
        password:[
            { required: true, message: '密码不能为空', trigger: 'blur' },
            { validator: (rule:any, value:any, callback:any)=>{
                const regExp = /^[a-zA-Z\d]{7,}$/
                if(!regExp.test(value)){
                    return callback(new Error('数字字母组合7位以上'));
                }
                callback();
            }, trigger: 'blur' }
        ]
    }
    dialogVisible3 = false;
    form3 = {
        roleId:''
    }
    rules3 = {
        roleId:[
            { required: true, message: '请选择角色', trigger: 'change' },
        ]
    }
    @Watch('pageNo')
        onPageNoChanged(cur:number){
            if(cur>0){
                this.accountGetPage()
            }
        }
    @Watch('dialogVisible1')
        ondialogVisible1Changed(cur:boolean){
            if(!cur){
                setTimeout(()=>{
                    this.resetRules('form1')
                    this.form1 = {
                        username:'',
                        password:'',
                        nickname:'',
                        department:'',
                        roleId:''
                    }
                },500)
            }
        }
    @Watch('dialogVisible2')
        ondialogVisible2Changed(cur:boolean){
            if(!cur){
                this.resetRules('form2')
                this.form2 = {
                    password:''
                }
            }
        }        
    @Watch('dialogVisible3')
        ondialogVisible3Changed(cur:boolean){
            if(!cur){
                this.resetRules('form3')
                this.form3 = {
                    roleId:''
                }
            }
        }    
    created(){
        this.accountGetPage()
        this.getRoleList()
    }
    options = []
    /**
     * 获取账户
     */
    async accountGetPage(){
        this.loading = true;
        const query = {
            params:{
                username:this.username,
                pageNo:this.pageNo,
                pageSize:this.pageSize
            }
        } 
        const res = await this.$http.get(this.$server.accountGetPage,query);
        this.loading = false;
        if(res.code==200){
            this.total = res.data.total;
            this.pages = res.data.pages;
            this.tableData = res.data.list;
            this.tableData.forEach((item:any,index:number)=>{
                item.sortId = (this.pageNo-1)*this.pageSize+index+1;
            })
        }
    }
    /**
     * 获取所有角色
     */
    async getRoleList(){
        const query = {
            params:{}
        }
        const res = await this.$http.get(this.$server.getRoleList,query);
        if(res.code==200){
            this.roleOptions = res.data.map((item:any)=>{
                return {
                    label:item.title,
                    value:item.id
                }
            })
        }
    }
    /**
     * 搜索
     */
    search(){
        this.pageNo = 0;
        this.$nextTick(()=>{
            this.pageNo = 1;
        })
    }
    /**
     * 清空验证错误
     */
    resetRules(formName:string){
        const form:any = this.$refs[formName] as HTMLElement;
        form.clearValidate();
    }
    /**
     * 新建账户提交
     */
    submitData(formName:string){
        const form:any = this.$refs[formName] as HTMLElement;
        form.validate((valid:any) => {
            if (valid) {
                if(formName=='form1'){
                    this.addUser()
                }else if(formName=='form2'){
                    this.resetPwd()
                }else{
                    this.allotRole();
                }
            } else {
                return false;
            }
        });
    }
    /**
     * 创建用户
     */
    async addUser(){
        const loadingInstance = this.$loading({
            target:document.querySelector('.account-dialog') as HTMLElement
        });
        const query = Object.assign({},this.form1,{
            username:Base64.encode(this.form1.username),
            password:Base64.encode(this.form1.password)
        })
        const res = await this.$http.post(this.$server.addUser,query)
        loadingInstance.close()
        if(res.code==200){
            this.$message.success('账户创建成功');
            this.dialogVisible1 = false;
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = 1;
            })
        }
    }
    /**
     * 分配角色事件
     */
    allotRoleEvent(obj:any){
        this.userId = obj.id;
        this.form3.roleId = obj.roleId;
        this.dialogVisible3 = true;
    }
    /**
     * 分配角色
     */
    async allotRole(){
        const loadingInstance = this.$loading({
            target:document.querySelector('.role-dialog') as HTMLElement
        });
        const query = {
            userId:this.userId,
            roleId:this.form3.roleId
        }
        const res = await this.$http.post(this.$server.allotRole,query);
        loadingInstance.close();
        if(res.code==200){
            this.$message.success('角色分配成功');
            this.dialogVisible3 = false;
            const tempPageNo = this.pageNo;
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = tempPageNo;
            })
        }
    }
    /**
     * 重置密码事件
     */
    resetPwdEvent(obj:any){
        this.dialogVisible2 = true;
        this.userId = obj.id;
    }   
    /**
     * 重置密码
     */
    async resetPwd(){
        const loadingInstance = this.$loading({
            target:document.querySelector('.role-dialog') as HTMLElement
        });
        const query = {
            userId:this.userId,
            password:Base64.encode(this.form2.password)
        }
        const res = await this.$http.post(this.$server.resetPwd,query);
        loadingInstance.close();
        if(res.code==200){
            this.$message.success('密码重置成功');
            this.dialogVisible2 = false;
            const tempPageNo = this.pageNo;
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = tempPageNo;
            })
        }
    }
    /**
     * 禁用|启用
     */
    diyEnableEvent(obj:any){
        const msg = obj.status==1?'确定要禁用此账户吗？用户禁用后不可登录':'确定要启用此账户吗？'
        this.$confirm(msg, '', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'error',
            center:true
        }).then(() => {
            this.userId = obj.id;
            this.diyEnable(obj.status)
        }).catch(() => {
            //do something  
        });
    }
    async diyEnable(status:number){
        const res = await this.$http.post(`${this.$server.diyEnable}/${this.userId}`,{})
        if(res.code==200){
            const msg = status==1?'账户禁用成功':'账户启用成功'
            this.$message.success(msg);
            const tempPageNo = this.pageNo;
            this.pageNo = 0;
            this.$nextTick(()=>{
                this.pageNo = tempPageNo;
            })
        }
    }
}
</script>
<style lang="scss" scoped>
    .account-manage-page{
        background: #fff;
        .search-area{
            font-size: 0;
            >div{
                display: inline-block;
                vertical-align: middle;
            }
            .keyword-box{
                width: 208px;
            }
            .search-btn{
                padding: 8px 9px;
                display: inline-block;
                vertical-align: middle;
                color:#666;
                font-size: 14px;
                margin-left: 20px;
            }
            .add-btn{
                padding: 8px 21px;
                display: inline-block;
                vertical-align: middle;
                font-size: 14px;
                color:#fff;
                margin-left: 505px;
            }
        }
        .table-container{
            margin-top:20px;
        }
        .account-form{
            /deep/ .el-cascader{
                width: 100%;
            }
        }
        .role-dialog,.account-dialog{
            .form-role{
                /deep/ .el-select{
                    width: 100%;
                }
            }
            
        }
    }
</style>