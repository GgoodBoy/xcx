<template>
  <div class="login-page">
    <div class="login-container">
      <div class="login-box">
        <div class="login-main" v-loading="loading">
          <p class="welcome">欢迎使用</p>
          <p class="platform">学国学网机构平台</p>
          <p class="switch" @click="status=!status">{{status==1?'切换手机号登录':'切换密码登录'}}</p>
          <img :src="require('../../assets/image/logo.png')" class="logo"/>
          <div class="form">
            <template v-if="status==1">
              <div class="item user">
                <div class="item-box">
                  <i class="el-icon-user icon"></i>
                  <el-input type="text" placeholder="请输入你的账号" v-model="username" clearable @focus="userError=''" @keydown.native.enter="login"></el-input>
                </div>
                <p class="error-tips" v-show="userError.length>0">{{userError}}</p>
              </div>
              <div class="item pwd">
                <div class="item-box">
                  <i class="el-icon-lock icon"></i>
                  <el-input :type="pwdShow?'text':'password'" placeholder="请输入密码" v-model="password" clearable @focus="pwdError=''" @keydown.native.enter="login"></el-input>
                  <i class="eye" :class="{'el-icon-view':pwdShow}" @click="pwdShow=!pwdShow"></i>
                </div>
                <p class="error-tips" v-show="pwdError.length>0">{{pwdError}}</p>
              </div>
              <div class="item image">
                <div class="item-box">
                  <i class="image-icon icon"></i>
                  <el-input type="text" placeholder="图形验证码" v-model="imgCode" maxlength="6" @focus="codeError=''" @keydown.native.enter="login" clearable></el-input>
                </div>
                <div class="img-code">
                  <img :src="codeUrl" v-if="codeUrl.length>0"/>
                </div>
                <p class="refresh" @click="refreshCodeUrl">换一张</p>
                <p class="error-tips" v-show="codeError.length>0">{{codeError}}</p>
              </div>
            </template>
            <template v-else>
              <div class="item phone">
                <div class="item-box">
                  <i class="el-icon-user icon"></i>
                  <el-input type="text" placeholder="请输入你的手机号" v-model="cellphone" clearable @focus="cellphoneError=''" @keydown.native.enter="login"></el-input>
                </div>
                <p class="error-tips" v-show="cellphoneError.length>0">{{cellphoneError}}</p>
              </div>
              <div class="item image">
                <div class="item-box">
                  <i class="image-icon icon"></i>
                  <el-input type="text" placeholder="图形验证码" v-model="imgCode" maxlength="6" clearable @focus="codeError=''" @keydown.native.enter="login"></el-input>
                </div>
                <div class="img-code">
                  <img :src="codeUrl" v-if="codeUrl.length>0"/>
                </div>
                <p class="refresh" @click="refreshCodeUrl">换一张</p>
                <div class="code-btn" v-loading="codeLoading" @click="sendSms" :class="{'none':codeText!='发送验证码'}"><p><span>{{codeText}}</span></p></div>
                <p class="error-tips" v-show="codeError.length>0">{{codeError}}</p>
              </div>
              <div class="item code">
                <div class="item-box">
                  <i class="el-icon-lock icon"></i>
                  <el-input  placeholder="请输入您收到的验证码" v-model="code" clearable @focus="smsCodeError=''" @keydown.native.enter="login"></el-input>
                </div>
                <p class="error-tips" v-show="smsCodeError.length>0">{{smsCodeError}}</p>
              </div>
            </template>  
            <div>
              <el-button class="login-btn" type="primary" v-btn-blur @click="login"><span>登</span><span>录</span></el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component,Vue,Watch} from 'vue-property-decorator'
import {namespace} from 'vuex-class'
const Base64 = require('js-base64').Base64;   
const user1Module = namespace('user1')
@Component({
  name:'login'
})
export default class MyComponent extends Vue {
  username = '';
  password = '';
  imgCode = '';
  codeUrl = 'https://ugcapi.youfushuyuan.com/getImgCode';
  pwdShow = false;
  userError = '';
  pwdError = '';
  codeError = '';
  loading = false;
  status = 1;
  cellphone = '';
  cellphoneError = '';
  code = '';
  codeText = '发送验证码'
  timer:any = null
  smsCodeError = '';
  codeLoading = false;
  @user1Module.Action('setUserInfo') setUserInfo:any
  @Watch('status')
    onStatusChanged(cur:number){
      clearInterval(this.timer)
      this.refreshCodeUrl()
      if(cur==1){
        this.cellphone = this.cellphoneError = this.code = this.smsCodeError = ''
      }else{
        this.username = this.password = this.imgCode = this.codeUrl = this.userError = this.pwdError = this.codeError = '';
      }
    }
  mounted(){
    this.renderPage();
    window.addEventListener(
      'resize',this.renderPage,false
    );
  }
  beforeDestroy(){
    window.removeEventListener(
      'resize',this.renderPage,false
    );
  }
  /**
   * 居中
   */
  renderPage(){
    const loginPage = document.querySelector('.login-page') as HTMLElement;
    const loginBox = document.querySelector('.login-box') as HTMLElement;
    loginPage.style.cssText = `padding:calc(calc(100vh - ${loginBox.clientHeight}px)/2) 0`
  }
  refreshCodeUrl(){
    this.codeUrl = ''
    this.$nextTick(()=>{
      this.codeUrl = 'https://ugcapi.youfushuyuan.com/getImgCode'
    })
  }
  async verifyImgCode(callback:any){
    const query = {
      code:this.imgCode
    }
    const res = await this.$http.post(this.$server.verifyImgCode,query)
    if(res.code==200){
      callback()
    }else{
      this.refreshCodeUrl()
    }
  }
  /**
   * 发送短信验证码
   */
  async sendSms(){
    if(this.cellphone==''){
      this.cellphoneError = '请输入手机号';
      return;
    }
    if(this.codeText!='发送验证码') return false;
    this.cellphoneError = '';
    this.codeLoading = true;
    const query = {
      params:{
        cellphone:this.cellphone,
        tokenType:4,
        msgType:3
      }
    }
    const res = await this.$http.get(this.$server.getSmsCode,query)
    this.codeLoading = false;
    if(res.code==200){
      let time = 60;
      this.timer = setInterval(()=>{
        this.codeText = `${time}S`
        if(time<=0){
          this.codeText = '发送验证码';
          clearInterval(this.timer);
          return;
        }
        time--;
      },1000)
    }
  }
  /**
   * 登录
   */
  async login(){
    if(this.status == 1){
      if(this.username==''){
        this.userError = '请输入账号';
        return;
      }
      if(this.password==''){
        this.pwdError = '请输入密码';
        return;
      }
      if(this.imgCode==''){
        this.codeError = '请输入图形验证码';
        return;
      }
    }else{
      if(this.cellphone==''){
        this.cellphoneError = '请输入手机号';
        console.log(this.cellphoneError)
        return;
      }
      if(this.code==''){
        this.smsCodeError = '请输入手机验证码';
        return;
      }
      if(this.imgCode==''){
        this.codeError = '请输入图形验证码';
        return;
      }
    }
    this.verifyImgCode(this.toLogin)
  }
  async toLogin(){
    this.loading = true;
    let query = {};
    if(this.status == 1){
      query = {
        username:Base64.encode(this.username),
        password:Base64.encode(this.password)
      }
    }else{
      query = {
        cellphone:this.cellphone,
        code:this.code,
        tokenType:4,
        msgType:3
      }
    }
    const url = this.status==1?this.$server.login:this.$server.smsLogin;
    const res = await this.$http.post(url,query)
    this.loading = false;
    if(res.code==200){
      const data = Base64.decode(res.data)
      this.$utils.saveUser(data)
      this.setUserInfo(JSON.parse(data))
      this.$message.success('登录成功')
      this.$router.push('/')
    }
  }
}
</script>
<style lang="scss">
  .login-page{
    width: 100%;
    min-width: 1440px;
    height: 100vh;
    background: url('../../assets/image/login_bgd.png')no-repeat 50% 50%;
    background-size:100%;
    background-color: #FF253E;
    position: relative;
    overflow-y:hidden;
    .login-container{
      width: 78%;
      margin:0 auto;
      .login-box{
        padding-top:34%;
        position: relative;
        .login-main{
          position: absolute;
          width: 47.25%;
          height:100%;
          background: #fff;
          border-radius: 6px;
          top:0;
          right: 0;
          padding: 4%;
          color:#333333;
          .logo{
            position: absolute;
            top:34%;
            right: 8.5%;
            width: 17%;
          }
          .welcome{
            font-size: 22px;
            height: 7.2%;
          }
          .platform{
            font-size: 36px;
            font-weight: bold;
            height:12%;
          }
          .switch{
            position: absolute;
            right: 8.5%;
            top:12%;
            text-decoration: underline;
            cursor: pointer;
          }
          .form{
            width: 71%;
            margin-top:6.6%;
            height: 72%;
            .item{
              margin-bottom:9.4%;
              position: relative;
              height: 14.5%;
              &.image{
                margin-bottom:7.2%;
                .item-box{
                  width:41% ;
                  display: inline-block;
                  vertical-align: middle;
                }
                .img-code{
                  display: inline-block;
                  vertical-align: middle;
                  width: 23.5%;
                  height: 100%;
                  margin:0 10px;
                  img{
                    width: 100%;
                    height: 100%;
                  }
                }
                .refresh{
                  display: inline-block;
                  vertical-align: middle;
                  font-size: 14px;
                  color:#666;
                  text-decoration: underline;
                  cursor: pointer;
                }
                .code-btn{
                  position: absolute;
                  font-size: 14px;
                  right: 0;
                  top:10%;
                  color:#fff;
                  background: linear-gradient(90deg, #FB5E6C 0%, #EC2039 100%);
                  width: 25%;
                  height: 80%;
                  border-radius: 25px;
                  margin-left: 2%;
                  cursor: pointer;
                  &.disabled{
                    background: #dfdfdf;
                  }
                  &.none{
                    cursor: not-allowed;
                  }
                  p{
                    display:table;
                    height: 100%;
                    width: 100%;
                    text-align: center;
                  }
                  span{
                    vertical-align:middle;display:table-cell;
                  }
                }
              }
              .item-box{
                position: relative;
                border:1px solid #dfdfdf;
                height: 100%;
                /deep/ .el-input{
                  position: absolute;
                  top:50%;
                  left: 50%;
                  transform: translate(-50%,-50%);
                  .el-input__suffix{
                    position: absolute;
                    right: 10px;
                    top:1px;
                    i{
                      color:#C30D20;
                    }
                  }
                  .el-input__inner{
                    padding:0 20px 0 35px!important;
                    font-size: 14px;
                    border:none;
                    outline: none;
                    background: none;
                  }
                } 
                .icon{
                  position: absolute;
                  top:50%;
                  left:20px;
                  transform: translate(-50%,-50%);
                  z-index: 2;
                  color:#a8a4a4;
                }
                .eye{
                  display: block;
                  position: absolute;
                  top:50%;
                  width: 14px;
                  height: 14px;
                  right: 50px;
                  transform: translate(100%,-50%);
                  background: url('../../assets/image/login_pwd_icon.png')no-repeat 50% 50% / cover;
                  cursor: pointer;
                  color:#999;
                  &.el-icon-view{
                    background: none;
                  }
                }
                .image-icon{
                  position: absolute;
                  display: block;
                  width: 14px;
                  height: 14px;
                  top:50%;
                  left:20px;
                  transform: translate(-50%,-50%);
                  z-index: 2;
                  background: url('../../assets/image/login_code_icon.png')no-repeat 50% 50% / cover;
                }
              }
              .error-tips{
                font-size: 12px;
                color:#C30D20;
                height: 16px;
                line-height:16px;
                margin: 5px 13px;
                position: absolute;
              }
            }
            .login-btn{
              width: 100%;
              padding: 15px;
              font-size: 16px;
              font-weight: bold;
              span{
                margin:0 6px;
              }
            }
          }
        }
      }
    }
    @media only screen and (min-width: 1440px) and (max-width: 1680px){
      .welcome{
        font-size: 20px!important;
        line-height:24px!important;
      }
      .platform{
        font-size: 32px!important;
        line-height:40px!important;
      }
      .login-btn{
        padding: 12px!important;
        font-size: 15px!important;
      }
      .code-btn{
        font-size: 13px!important;
      }
      .refresh{
        font-size: 13px!important;
      }
    }
    @media only screen and (min-width: 1280px) and (max-width: 1439px){
      .welcome{
        font-size: 18px!important;
        line-height:22px!important;
      }
      .platform{
        font-size: 28px!important;
        line-height:34px!important;
      }
      .login-btn{
        padding: 10px!important;
        font-size: 14px!important;
      }
      .code-btn,.refresh{
        font-size: 12px!important;
      }
    }
    @media only screen and (max-width: 1279px){
      .welcome{
        font-size: 16px!important;
        line-height:18px!important;
      }
      .platform{
        font-size: 24px!important;
        line-height:28px!important;
      }
      .login-btn{
        padding: 8px!important;
        font-size: 14px!important;
      }
      .code-btn,.refresh{
        font-size: 12px!important;
      }
    }
  }
</style>
