<template>
    <div class="error-page">
        <h1>404</h1>
    </div>
</template>
<script lang="ts">
import { Component,Vue } from 'vue-property-decorator'
@Component({
  name:'error'
})
export default class MyComponent extends Vue {

}
</script>
<style lang="scss" scoped>

</style>
