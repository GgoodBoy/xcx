import Vue from 'vue'
import Vuex from 'vuex'
import user1 from './modules/user1'
import user2 from './modules/user2'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    user1,
    user2
  }
})
