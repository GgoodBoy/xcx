const user2 = {
    state:{

    },
    mutations:{

    },
    actions:{

    }
}
export default user2;