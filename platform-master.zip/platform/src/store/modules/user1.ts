import dynamicRoutes from '../../router/routes'
const user1 = {
    state:{
        isAddRoutes:false,//是否添加过动态路由
        roleRouterRules:[],//角色权限路由
        userInfo:{}
    },
    mutations:{
        SETISADDROUTES(state:any,data:any){
            state.isAddRoutes = data;
        },
        SETUSERINFO(state:any,data:any){
            state.userInfo = data;
        },
    },
    actions:{
        setIsAddRoutes({commit}:any,data:any){
            commit('SETISADDROUTES',data)
        },
        setUserInfo({commit}:any,data:any){
            commit('SETUSERINFO',data)
        }
    },
    getters:{
        isAddRoutes:(state:any)=>state.isAddRoutes,
        roleRouter:(state:any)=>{
            if(state.roleRouterRules){
                return dynamicRoutes.filter(
                    router => state.roleRouterRules.indexOf(router.name) >= 0,
                );
            }else return null  
        }
    }
}
export default {
    namespaced: true,
    ...user1
};