<template>
  <div class="upload-media-container">
    <div class="upload">
      <div class="btn-area clearfix">
        <input type="file" id="fileUpload" multiple="multiple" @change="fileChange($event)" ref="input">
      </div>
      <div class="empty-files-box" v-if="fileList.length==0" v-loading="loading">
        <p>~暂无{{fileType=='video'?'视频':'音频'}}~</p>
        <el-button type="primary" class="add-btn" @click="chooseFile">
          <i class="el-icon-plus"></i>
          选择{{fileType=='video'?'视频':'音频'}}文件
        </el-button>
        <p class="tips">{{fileType=='video'?'上传文件格式支持mp4、wmv，文件大小不超过1G':'仅支持mp3格式，100M以下的音频文件'}}</p>
      </div>
      <div class="file-list" v-show="fileList.length>0" v-loading="loading">
        <div class="file-item" v-for="(item,index) in fileList" :key="index" :class="{'show':startFlag}">
          <div class="file-base">
            <el-tooltip class="item" effect="dark" :content="item.name" placement="top-start">
              <p class="file-name text-overflow">{{item.name}}</p>
            </el-tooltip>  
            <p class="file-size">{{item.size}}</p>
            <el-button type="text" class="del" @click="delFile(index)">
              <i class="el-icon-circle-close"></i>
              移除
            </el-button>
          </div>
          <div class="file-info" v-show="startFlag">
            <div class="progress">
                <el-progress :text-inside="true" :stroke-width="6" :percentage="item.percentage"></el-progress>
            </div>
            <div class="b clearfix">
              <div class="left">
                <el-button type="text" class="start-btn" :disabled="item.uploadDisabled" @click="authUpload(index)" ref="startBtn">开始上传</el-button>
                <el-button type="text" :disabled="item.pauseDisabled" @click="pauseUpload(index)">暂停</el-button>
                <el-button type="text" :disabled="item.resumeDisabled" @click="resumeUpload(index)">恢复上传</el-button> 
              </div>
              <div class="right">
                <p class="percent">{{item.percentage}}%</p>
                <p class="file-status">文件状态 : {{item.status}}</p>
              </div>   
            </div>
          </div>  
        </div>
      </div>
      <div class="btns">
        <template v-if="fileList.length>0&&!startFlag">
          <el-button type="text" class="go-on" @click="chooseFile" v-if="fileList.length<5">
            <i class="el-icon-plus"></i>
            继续添加{{fileType=='video'?'视频':'音频'}}
          </el-button>
          <el-button type="primary" class="upload" @click="allStartUpload">开始上传</el-button>
          <el-button class="cancel" @click="cancelEvent">取消</el-button>
        </template>
        <template v-if="startFlag">
          <el-button type="primary" :disabled="!saveStatus" class="continue" @click="chooseFile">继续添加{{fileType=='video'?'视频':'音频'}}</el-button>
          <el-button class="save" :disabled="!saveStatus" @click="saveMedia">完成</el-button>
        </template>
      </div>
    </div>
  </div>
</template>
<script>
  function getFileSize(fileByte) {
    const fileSizeByte = fileByte;
    let fileSizeMsg = '';
    if (fileSizeByte < 1048576) fileSizeMsg = (fileSizeByte / 1024).toFixed(2) + 'KB';
    else if (fileSizeByte == 1048576) fileSizeMsg = '1MB';
    else if (fileSizeByte > 1048576 && fileSizeByte < 1073741824) fileSizeMsg = (fileSizeByte / (1024 * 1024)).toFixed(2) + 'MB';
    else if (fileSizeByte > 1048576 && fileSizeByte == 1073741824) fileSizeMsg = '1GB';
    else if (fileSizeByte > 1073741824 && fileSizeByte < 1099511627776) fileSizeMsg = (fileSizeByte / (1024 * 1024 * 1024)).toFixed(2) + 'GB';
    else fileSizeMsg = '文件超过1TB';
    return fileSizeMsg;
   }
  export default {
    data () {
      return {
        timeout: '',
        partSize: '',
        parallel: '',
        retryCount: '',
        retryDuration: '',
        region: 'cn-shanghai',
        userId: '1540507958583619',
        uploaders:[],
        fileList:[],
        saveStatus:false,
        startFlag:false,
        loading:false
      }
    },
    props:['fileType','videoType','done'],
    inject:['viewReload'],
    watch:{
      fileList:{
        handler(cur){
          if(cur.length==0){
            this.startFlag = false;
            this.$emit('update:done',true)
          }
          const index = cur.findIndex(item=>item.transCodeStatus == false)
          this.saveStatus = index<0?true:false
        },
        deep:true
      }
    },
    methods: {
      /**
       * 选择文件
       */
      chooseFile(){
        this.$refs.input.value = ''
        this.$refs.input.click();
      },
      /**
       * 获取文件，并创建阿里云媒体上传对象
       */
      fileChange (e) {
        if(this.fileList.length==0){
          if(e.target.files.length>5){
            this.$message.error('最多上传5个文件');
            this.loading = false;
            return false;
          }
        }else{
          if(this.fileList.length+e.target.files.length>5){
            this.$message.error(`最多上传5个文件，列表中已存在${this.fileList.length}个文件`);
            this.loading = false;
            return false;
          }
        }
        let index = this.fileList.length;
        const startIndex = this.fileList.length;
        const userData = `{"Vod":{}}`;
        for(const file of e.target.files){
          const format = file.name.split('.').pop().toLocaleUpperCase();
          if(this.fileType=='video'){
            if (!(format == 'MP4' || format == 'WMV')) {
              this.$message.error(`文件${file.name}格式有误，请检查格式！`);
              this.loading = false;
              return false;
            }
            if(file.size>1024*1024*1024){
              this.$message.error(`文件${file.name}大小已超过1G，请压缩后上传`);
              this.loading = false;
              return false;
            }
          }else if(this.fileType=='audio'){
            if (!(format == 'MP3')) {
              this.$message.error(`文件${file.name}格式有误，请检查格式！`);
              this.loading = false;
              return false;
            }
            if(file.size>1024*1024*100){
              this.$message.error(`文件${file.name}大小已超过100MB，请压缩后上传`);
              this.loading = false;
              return false;
            }
          }
          if (file.name.length > 200) {
            this.$message.error(`文件${file.name}名字过长，请更改后上传！`);
            this.loading = false;
            return false;
          }
          const obj = this.fileList.find(item=>item.name==file.name)
          if(obj){
            this.$message.error(`文件${obj.name}已存在上传列表中`);
            this.loading = false;
            return false;
          }
          this.loading = true;
          this.uploaders[index] = this.createUploader(index);
          this.uploaders[index].addFile(file, null, null, null, userData)
          const files = this.uploaders[index].listFiles()[0];
          setTimeout(()=>{
            const obj = this.fileList.find(item=>item.fileHash==files.fileHash);
            if(obj){
              this.$message.error(`存在内容相同的文件,文件名是${obj.name}`);
              // this.uploaders.splice(index,1);
            }else{
              const params = {
                name:files.file.name, 
                fileHash:files.fileHash,
                size:getFileSize(files.file.size),
                uploadDisabled:false,
                pauseDisabled:true,
                resumeDisabled:true,
                status:'准备就绪',
                percentage:0,
                transCodeStatus:false
              }
              this.fileList.push(params)
              this.$nextTick(()=>{
                if(startIndex+e.target.files.length==this.fileList.length){
                  this.loading = false;
                }
              })
            }
          },1000)
          index++;
        }
        this.$emit('update:done',false)
      },
      /**
       * 单个开始上传
       */
      authUpload (index) {
        // 然后调用 startUpload 方法, 开始上传
        this.uploaders[index].startUpload()
        this.fileList[index].uploadDisabled = true;
        this.fileList[index].pauseDisabled = false;
      },
      /**
       * 批量开始上传
       */
      allStartUpload(){
        this.startFlag=true
        this.allResumeUplad()
      },
      /**
       * 单个暂停
       */
      pauseUpload (index) {
        this.uploaders[index].stopUpload()
        this.fileList[index].resumeDisabled = false
        this.fileList[index].pauseDisabled = true
      },
      /**
       * 批量暂停
       */
      allPauseUpload(){
        for(let index=0;index<this.fileList.length;index++){
          this.uploaders[index].stopUpload()
          this.fileList[index].resumeDisabled = false
          this.fileList[index].pauseDisabled = true
        }
      },
      /**
       * 单个恢复上传
       */
      resumeUpload (index) {
        this.uploaders[index].startUpload()
        this.fileList[index].resumeDisabled = true
        this.fileList[index].pauseDisabled = false
      },
      /**
       * 批量恢复上传
       */
      allResumeUplad(){
        for(let index=0;index<this.fileList.length;index++){
          this.uploaders[index].startUpload()
          this.fileList[index].resumeDisabled = true
          this.fileList[index].pauseDisabled = false
        }
      },
      /**
       * 删除单个
       */
      delFile(index){
        const fileTypeName = this.fileType=='video'?'视频':'音频'
        this.$confirm(`确定要删除这个${fileTypeName}吗？`, '删除确认', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal:false,
            closeOnPressEscape:false,
            center:true
        }).then(() => {
            this.fileList.splice(index,1);
            this.uploaders.splice(index,1);
        }).catch(()=>{
          //doing something
        }) 
      },  
      saveMedia(){
        const obj = this.fileList.find(item=>item.transCodeStatus == false)
        if(obj){
          this.$message.error(`${obj.name}尚未完成转码，请稍后再试`)
          return;
        }
        const temp = this.fileList.map(item=>{
          return item.videoId
        })
        const query = {
          vid:JSON.stringify(temp),
          type:this.fileType=='audio'?1:2
        }
        this.$http.post(this.$server.saveVideoOrAudio,query).then(res=>{
          if(res.code == 200){
            this.$emit('update:done',true)
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            setTimeout(()=>{
              this.$router.go(-1)
            },1)
          }
        })            
      },
      /**
       * new阿里云上传对象
       */
      createUploader (index) {
        const uploader = new window.AliyunUpload.Vod({
          timeout: this.timeout || 60000,
          partSize: this.partSize || 1048576,
          parallel: this.parallel || 10,
          retryCount: this.retryCount || 3,
          retryDuration: this.retryDuration || 2,
          region: this.region,
          userId: this.userId,
          // 添加文件成功
          addFileSuccess: ()=>{
            //console.log(uploadInfo)
          },
          // 开始上传
          onUploadstarted:(uploadInfo)=>{
            console.log(uploadInfo.videoId)
            if(!uploadInfo.videoId){
              const query = {
                fileType:this.fileType,
                fileName:uploadInfo.file.name,
                fileSize:uploadInfo.file.size
              }
              if(this.videoType){
                query.videoType = this.videoType;
              }  
              this.$http.post(this.$server.getUploadAuth,query).then(res=>{
                if(res.code == 200){
                  const uploadAuth = res.data.uploadAuth
                  const uploadAddress = res.data.uploadAddress
                  const videoId = res.data.videoId
                  uploader.setUploadAuthAndAddress(uploadInfo, uploadAuth, uploadAddress,videoId)   
                }else{
                  this.fileList[index].uploadDisabled = false;
                  this.fileList[index].pauseDisabled = true;
                  this.fileList[index].resumeDisabled = true;
                }
              }).catch(()=>{
                this.fileList[index].uploadDisabled = true;
                this.fileList[index].pauseDisabled = true;
                this.fileList[index].resumeDisabled =true;
              })
            }else{
              const query = {
                videoId:uploadInfo.videoId
              }
              this.$http.post(this.$server.refreshUploadAuth,query).then(res=>{
                if(res.code == 200){
                  const uploadAuth = res.data.uploadAuth
                  const uploadAddress = res.data.uploadAddress
                  const videoId = res.data.videoId
                  uploader.setUploadAuthAndAddress(uploadInfo, uploadAuth, uploadAddress,videoId)   
                }
              })
            }
          },
          // 文件上传成功
          onUploadSucceed: (uploadInfo)=>{
            this.fileList[index].status = '上传成功,转码中...'
            this.fileList[index].uploadDisabled = true;
            this.fileList[index].pauseDisabled = true;
            this.fileList[index].resumeDisabled =true;
            const query = {
              videoId:uploadInfo.videoId,
              fileType:this.fileType,
            }
            if(this.videoType){
              query.videoType = this.videoType
            }
            this.$http.post(this.$server.submitTranscode,query).then(res=>{
              if(res.code == 200){
                this.fileList[index].status = '转码成功'
                this.fileList[index].transCodeStatus = true;
                this.fileList[index].videoId = uploadInfo.videoId;
              }
            });
          },
          // 文件上传失败
          onUploadFailed: (uploadInfo, code, message)=> {
            this.fileList[index].status = '上传失败，请重新上传'
            console.log(uploadInfo,code,message)
          },
          // 取消文件上传
          onUploadCanceled: (uploadInfo, code, message)=> {
            this.fileList[index].status = '文件已暂停上传'
            this.fileList[index].uploadDisabled = true;
            this.fileList[index].pauseDisabled = true;
            this.fileList[index].resumeDisabled = false;
            console.log(uploadInfo,code,message)
          },
          // 文件上传进度
          onUploadProgress: (uploadInfo, totalSize, progress)=> {
            this.fileList[index].percentage = Math.ceil(progress * 100)
            this.fileList[index].status = '文件上传中...'
            this.fileList[index].uploadDisabled = true;
            this.fileList[index].pauseDisabled = false;
            this.fileList[index].resumeDisabled =true;
          },
          // 上传凭证超时
          onUploadTokenExpired: (uploadInfo)=>{
            const query = {
              videoId:uploadInfo.videoId
            }
            this.$http.post(this.$server.refreshUploadAuth,query).then(data=>{
              if(data.status == 200){
                const uploadAuth = data.content.uploadAuth
                const uploadAddress = data.content.uploadAddress
                const videoId = data.content.videoId
                uploader.setUploadAuthAndAddress(uploadInfo, uploadAuth, uploadAddress,videoId)   
              }
            })
          },
          // 全部文件上传结束
          onUploadEnd: ()=> {
            console.log('end')
          }
        })
        return uploader
      },
      cancelEvent(){
        const msg = this.fileType=='video'?'当前视频还未上传完成确定取消上传':'当前音频还未上传完成确定取消上传'
        this.$confirm(msg, '', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          closeOnClickModal:false,
          closeOnPressEscape:false,
          center: true
        }).then(() => {
          this.$emit('update:done',true)
          this.viewReload()
        }).catch(()=>{
          //doing something
        }) 
      }
    }
  }
</script>
<style lang="scss" scoped>
    .upload-media-container{
      .empty-files-box{
          text-align: center;
          padding: 82px 0;
          p{
            font-size: 16px;
            color:#333;
            &.tips{
              color:#999;
            }
          }
          /deep/ .el-button{
            border-radius: 25px!important;
            padding: 15px 20px!important;
            font-size: 14px!important;
            margin:20px 0;
          }
        }
        #fileUpload{
          opacity: 0;
          position: absolute;
          right: -100px;
          top:-100px;
        }
        .btn-area{
          .left{
            float: left;
          }
          .right{
            float: right;
          }
        }
        .file-list{
            padding: 20px 0;
            .file-item{
              margin-bottom:20px;
              &:last-child{
                margin-bottom:0px;
              }
              &.show{
                box-shadow: 0 0 5px #e5e5e5;
                border-radius: 6px;
                .file-base{
                  border:1px solid #fff;
                  background: #fff;
                }
                .file-info{
                  border-top:1px solid #e5e5e5;
                }
              }
                .file-base{
                  height: 38px;
                  line-height: 38px;
                  border: 1px solid #E5E5E5;
                  border-radius: 6px;
                  font-size: 0;
                  background: #FCFCFC;
                  .file-name,.file-size,.del{
                    display: inline-block;
                    vertical-align: middle;
                    width: 25%;
                    font-size: 14px;
                    font-weight: bold;
                    color:#333;
                    &.file-size{
                      text-align: center;
                      font-weight: normal;
                    }
                    &.file-name{
                      width: 50%;
                      padding-left:5%;
                    }
                    &.del{
                      font-size: 13px;
                      color:#C30D20;
                      text-align: right;
                      padding-right: 5%;
                    }
                  }
                }
                .file-info{
                  .progress{
                    padding: 0 5%;
                    margin-top:10px;
                    /deep/ .el-progress-bar__outer{
                      background: #f4f4f4;
                      .el-progress-bar__innerText{
                        display: none;
                      }
                    }
                  }
                  .b{
                    padding: 0 5%;
                    .left{
                      float: left;
                      .start-btn{
                        text-decoration: underline;
                      }
                    }
                    .right{
                      float: right;
                      font-size: 14px;
                      color:#333;
                      .percent{
                        margin-right: 15px;
                        position: relative;
                        top:1px;
                      }
                      p{
                        display: inline-block;
                        vertical-align: middle;
                      }
                    }
                  }
                } 
            }
        }
        .btns{
          text-align: right;
          /deep/ .el-button{
            padding: 0;
            width: 160px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            margin-left: 20px;
            font-size: 14px;
            &.upload{
              margin-left: 0;
            }
            &.go-on{
              color:#C30D20;
            }
          }
        }
    }
</style>