<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script lang="ts">
import { Component,Vue} from 'vue-property-decorator'
import {namespace} from 'vuex-class'
declare const window: any;
const user1Module = namespace('user1')
@Component({
  name:'app'
})
export default class MyComponent extends Vue {
  @user1Module.State('userInfo') userInfo:any
  @user1Module.Action('setUserInfo') setUserInfo:any
  created(){
    const user = this.$utils.getUser();
    if(user){
      this.setUserInfo(JSON.parse(user))
      setTimeout(()=>{
        console.log(this.userInfo)
      },3000)
    }
    // this.$watch('text',(newVal,oldVal)=>{
    //   console.log(oldVal,newVal)
    // })
  }    
}
</script>
<style lang="scss">
  #app{
    min-height: 100vh;
    width: 100%;
    background: #f4f4f4;
    overflow-x: hidden;
    overflow-y:auto;
  }
</style>
