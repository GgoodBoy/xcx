// import Vue from 'vue'
function install(Vue:any){
  Vue.directive('loadmore', {
    inserted(el:any, binding:any) {
      // 获取element-ui定义好的scroll盒子
      const SELECTDOWN_DOM = el.querySelector('.el-select-dropdown .el-select-dropdown__wrap')
      SELECTDOWN_DOM.addEventListener('scroll', function() {
        const CONDITION = SELECTDOWN_DOM.scrollHeight - SELECTDOWN_DOM.scrollTop <= SELECTDOWN_DOM.clientHeight
        if (CONDITION) {
          binding.value()
        }
      })
    }
  })
}
export default install;