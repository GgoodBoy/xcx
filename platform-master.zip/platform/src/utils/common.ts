export default class DataList { 
    formatDate(date:any,type:any){
        if(date){
            date = new Date(date);
            const y:string | number = date.getFullYear();
            let m:string | number = date.getMonth()+1;
            let d:string | number = date.getDate();
            let h:string | number = date.getHours();
            let m1:string | number = date.getMinutes();
            let s:string | number = date.getSeconds();
            m = m<10?('0'+m):m;
            d = d<10?('0'+d):d;
            if(type=='end'){
                h = 23;
                m1 = 59;
                s = 59;                
            }else{
                h = h<10?('0'+h):h;
                m1 = m1<10?('0'+m1):m1;
                s = s < 10 ? ('0' + s) : s;
            }
            return y+'-'+m+'-'+d+' '+h+':'+m1+':'+s;
        }else{
            return '';
        }
    }
}
export function _throttle(fn:any, time:any) {
    let last: number
    let timer: number|undefined
    const interval = time || 200
    return function() {
      const args = arguments
      const now = +new Date()
      if (last && now - last < interval) {
        clearTimeout(timer)
        timer = setTimeout(function() {
          last = now
          //@ts-ignore
          fn.apply(this, args)
        }, interval)
      } else {
        last = now
        //@ts-ignore
        fn.apply(this, args)
      }
    }
}