export default class DataList { 
    formatDate(date,type){
        if(date){
            date = new Date(date);
            const y=date.getFullYear();
            let m=date.getMonth()+1;
            let d=date.getDate();
            let h=date.getHours();
            let m1=date.getMinutes();
            let s=date.getSeconds();
            m = m<10?('0'+m):m;
            d = d<10?('0'+d):d;
            if(type=='end'){
                h = 23;
                m1 = 59;
                s = 59;                
            }else{
                h = h<10?('0'+h):h;
                m1 = m1<10?('0'+m1):m1;
                s = s < 10 ? ('0' + s) : s;
            }
            return y+'-'+m+'-'+d+' '+h+':'+m1+':'+s;
        }else{
            return '';
        }
    }
}