import Vue from 'vue'
/**
 * 处理el-button点击后没有失焦的问题
 */
Vue.directive('btn-blur',{
    bind(el){
        el.addEventListener('click',(e)=>{
            e.stopPropagation();
            el.blur()
        })
    }
})
/**
 * 按钮功能权限
 */
Vue.directive('auth',{
    bind(el,binding){
        if(binding.value!='add'){
        el.style.cssText = 'display:none'
        setTimeout(()=>{
            const parent:any = el.parentNode;
            parent.removeChild(el)
        },0)
        }
    }
})