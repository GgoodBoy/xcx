const secretKey = 'xgxw_jigou_user';
export default{
    /**
     * 保存用户信息到cookie
     * @param user  用户信息
     * @constructor
     */
    saveUser (user:any) {
        const Days = 7; 
        const exp:any = new Date();    
        exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
        let userInfo = JSON.stringify(user);
        userInfo = encodeURI(userInfo);
        document.cookie = 'xgxw_user=' + this.encrypt(userInfo, secretKey) + ';expires=' + exp.toGMTString()+';path=/';
    },
    /**
     * 从cookie获取用户信息
     * @constructor
     */
    getUser () {
        let user = this.getCookie('xgxw_user');
        if(!user) return false;
        const temp:any = this.decrypt(user,secretKey)
        user = decodeURI(temp);
        return JSON.parse(user);
    },
    /**
     * 删除user cookie
     * @constructor
     */
    quitUser () {
        const time:any = new Date(0);
        time.setDate(time.getDate() - 1); 
        document.cookie = 'xgxw_user=;path=/;expires=' + time.toGMTString();
    },
    /**
     * 获取cookie
     * @param name
     * @returns {*}
     */
    getCookie(name:any){
        let arr:any = '';
        const reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)');
        if (document.cookie.match(reg)){
            arr = document.cookie.match(reg)
            return unescape(arr[2]);
        }
        else
            return null;
    },
    /**
     * 加密
     * @param str
     * @param pwd
     * @return {*}
     */
    encrypt(str:any, pwd:string) {
        if (pwd == null || pwd.length <= 0) {
        alert('Please enter a password with which to encrypt the message.');
            return null;
        }
        let prand:any = '';
        for (let i = 0; i < pwd.length; i++) {
            prand += pwd.charCodeAt(i).toString();
        }
        const sPos = Math.floor(prand.length / 5);
        const mult = parseInt(prand.charAt(sPos) + prand.charAt(sPos * 2) + prand.charAt(sPos * 3) + prand.charAt(sPos * 4) + prand.charAt(sPos * 5));
        const incr = Math.ceil(pwd.length / 2);
        const modu = Math.pow(2, 31) - 1;
        if (mult < 2) {
            alert('Algorithm cannot find a suitable hash. Please choose a different password. \nPossible considerations are to choose a more complex or longer password.');
            return null;
        }
        let salt:any = Math.round(Math.random() * 1000000000) % 100000000;
        prand += salt;
        while (prand.length > 10) {
            prand = (parseInt(prand.substring(0, 10)) + parseInt(prand.substring(10, prand.length))).toString();
        }
        prand = (mult * prand + incr) % modu;
        let encChr:any = '';
        let encStr:any = '';
        for (let i = 0; i < str.length; i++) {
            const temp:any = str.charCodeAt(i) ^ Math.floor((prand / modu) * 255);
            encChr = parseInt(temp);
            if (encChr < 16) {
                encStr += '0' + encChr.toString(16);
            } else encStr += encChr.toString(16);
            prand = (mult * prand + incr) % modu;
        }
        salt = salt.toString(16);
        while (salt.length < 8)salt = '0' + salt;
        encStr += salt;
        return encStr;
    },
    /**
     * 解密
     * @param str
     * @param pwd
     * @return {*}
     */
    decrypt(str:string, pwd:string) {
        if (str == null || str.length < 8) {
            alert(`A salt value could not be extracted from the encrypted message because it's length is too short. The message cannot be decrypted.`);
            return;
        }
        if (pwd == null || pwd.length <= 0) {
            alert('Please enter a password with which to decrypt the message.');
            return;
        }
        let prand:any = '';
        for (let i = 0; i < pwd.length; i++) {
            prand += pwd.charCodeAt(i).toString();
        }
        const sPos = Math.floor(prand.length / 5);
        const mult = parseInt(prand.charAt(sPos) + prand.charAt(sPos * 2) + prand.charAt(sPos * 3) + prand.charAt(sPos * 4) + prand.charAt(sPos * 5));
        const incr = Math.round(pwd.length / 2);
        const modu = Math.pow(2, 31) - 1;
        const salt = parseInt(str.substring(str.length - 8, str.length), 16);
        str = str.substring(0, str.length - 8);
        prand += salt;
        while (prand.length > 10) {
            prand = (parseInt(prand.substring(0, 10)) + parseInt(prand.substring(10, prand.length))).toString();
        }
        prand = (mult * prand + incr) % modu;
        let encChr:any = '';
        let encStr = '';
        for (let i = 0; i < str.length; i += 2) {
            const temp:any = parseInt(str.substring(i, i + 2), 16) ^ Math.floor((prand / modu) * 255);
            encChr = parseInt(temp);
            encStr += String.fromCharCode(encChr);
            prand = (mult * prand + incr) % modu;
        }
        return encStr;
    }
}