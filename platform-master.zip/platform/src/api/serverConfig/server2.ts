const ljm= {
    getOrderListOrder: '/order/getOrderList',
    getSearchMechanismList: '/mechanism/getSearchMechanismList',
    getMessageList: '/message/getMessageList',
    //统计
    getStatisticalList: '/statistical/getStatisticalList',
    //认证-查询认证信息
    getMechanismDetail: '/mechanism/detail/',
    //图片上传
    setUploadPic: '/upload/pic',
    //认证-修改个人认证信息
    updatePersonalMechanism: '/mechanism/updatePersonal',
    //认证-修改机构认证信息
    updateOrgMechanism: '/mechanism/updateOrg',
    //1.0046-提现账户-根据类型查询相关提现设置
    getWithdrawalWithdrawal: '/withdrawal/getWithdrawal/',
    //提现账户-添加个人提现
    addPersonalWithdrawal: '/withdrawal/addPersonal',
    //提现账户-获取省市列表
    getListRegion: '/region/getList',
    //提现账户-添加机构提现
    addOrGwithdrawal: '/withdrawal/addOrg',
    //提现账户-审核
    examineWithdrawal: '/withdrawal/examine/',
    //提现账户-管理员查询所有列表
    getWithdrawalList: '/withdrawal/getWithdrawalList',
    //结算-获取结算和结算金额
    getSettlePriceSettle: '/settle/getSettlePrice',
    //提现账户获取用户所有可用账户
    getPassAccountWithdrawal: '/withdrawal/getPassAccount',
    //-提现账户-机构提现提交审核
    getSubmitExamine: '/withdrawal/submitExamine/',
    //账户-2b 用户 更换密码
    setResetPwd: '/account/resetPwd',
    //-账户-管理员获取账户列表
    getAccountListAccount: '/account/getAccountList',
    //-账户-更换管理员（2）
    changeAccountaccount: '/account/changeAccount',
    //账户-更换管理员（1）
    getVerifySmsCodeAccount: '/account/verifySmsCode',
    //通用-获取短信验证码接口
    getSmsCodeCommon:'/common/getSmsCode',
    //结算-查询结算列表
    getSettleOrderList: '/settle/getSettleOrderList',
    //结算-审批
    setExamineTle: '/settle/examine/',

    //-结算-创建结算订单(提现)
    setTleAddOrder: '/settle/addOrder',
    //结算-查询当前用户是企业还是个人用户
    getMechanismTypeSettle: '/settle/getMechanismType',
    //个人认证-提现账户修改数据回填
    getWithdrawalInfo: '/withdrawal/getInfo/',
    //认证-管理员获取认证列表
    getMechanismInfoList: '/mechanism/getMechanismInfoList',
    //-认证-管理员禁用和启用
    setEnabledMechanism: '/mechanism/setEnabled/',
    //认证-管理员平台费
    setPlatformFeeMechanism: '/mechanism/setPlatformFee/',
    //-认证-管理员根据机构ID获取详情
    getMechanismInfo: '/mechanism/getInfo/',
    //
    setExamineMechanism:'/mechanism/examine/'
    
}
const urlObj = 'http://172.16.120.6:8750';
const baseUrl = process.env.NODE_ENV == 'prod'?process.env.BASE_API:urlObj;
const ljmExport = {
    schooleSchooleExport:(objs:any) => { return baseUrl +`/settle/export/settleOrderList?settleOrderId=${objs.settleOrderId}&mechanismId=${objs.mechanismId}&type=${objs.type}&token=${objs.token}` },
}
export default Object.assign({}, ljm,ljmExport)