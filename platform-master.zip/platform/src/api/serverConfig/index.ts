import server1 from './server1'
import server2 from './server2'

const url : any = Object.assign({},server1,server2)

export default url;