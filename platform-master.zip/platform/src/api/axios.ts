import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { Message } from 'element-ui';
import qs from 'qs'
import utils from '../utils' 
const baseURL: string = process.env.VUE_APP_MODE&&process.env.VUE_APP_MODE=='prod'?
'https://biapi.xueguoxue.com':'https://ugcapi.youfushuyuan.com';
interface ResponseData {
    code: number;
    message: string;
    data: any;
}
const service: AxiosInstance | any = axios.create({
  baseURL,
  timeout: 50000,
  headers:{
    'X-Requested-With': 'XMLHttpRequest', 
    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
  },
  transformRequest: [(data, headers) => {
      if (headers['Content-Type']!='multipart/form-data') {
        if (data && !data.transformRequest) {
          data = qs.stringify(data);
        } else if (data && data.transformRequest) {
          data = JSON.stringify(data)
        }
      }
      return data;
  }]
});
// request 拦截器 axios 的一些配置
service.interceptors.request.use(
    (config: AxiosRequestConfig) => {
      const user:string|null = utils.getUser();
      if(user){
        config.headers.token = JSON.parse(user).token;
      }
      // const url:any = config.url
      // if(url.includes('/mobileCourses/getResoursePlayUrl')){
      //   config.baseURL = 'https://courseapi.youfushuyuan.com'
      //   config.headers['Content-Type'] = 'application/json;charset=utf-8'
      //   config.data = JSON.stringify(config.data);  
      // }
      return config;
    },
    (error: any) => {
      Promise.reject(error);
    }
  );
  // respone 拦截器 axios 的一些配置
  service.interceptors.response.use(
    (res: AxiosResponse) => {
      if (res.status === 200) {
        const data: ResponseData = res.data
        // if(data.code==70004){
        //   Message({
        //     message: '登录过期，请重新登录!',
        //     type: 'error'
        //   });
        //   localStorage.removeItem('token');
        //   localStorage.removeItem('userId');
        //   window.location.replace('/login');
        // }
        if(data.code!=200){
          if(data.message.length>0){
            Message({
              message: data.message,
              type: 'error'
            });
          }
        }
        return data;
      }else{
        Message({
          message: res.data.message,
          type: 'error'
        });
        return Promise.reject(new Error(res.data.message || 'Error'));
      }
    },
    (error: any) => {
      if(error.response.data.code==70006||error.response.data.code==70004){
        utils.quitUser();
        Message({
          message: '登录过期，请重新登录!',
          type: 'error'
        });
        window.location.replace('/platform/login')
      }
    }
  );
  
  export default service;
  